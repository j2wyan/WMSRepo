﻿namespace WMS_V1
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempJutyuEntry
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle13 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border13 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle14 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border14 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle15 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border15 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle16 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border16 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle17 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border17 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle18 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border18 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle19 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border19 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle20 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border20 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle21 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border21 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle22 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border22 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle23 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border23 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle24 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border24 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle25 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border25 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border1 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border2 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border3 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border4 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border5 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border6 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle7 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border7 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle8 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border8 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle9 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border9 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle10 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border10 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle11 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border11 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle12 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border12 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle26 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle27 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border26 = new GrapeCity.Win.MultiRow.Border();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.headerCell1 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell2 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell3 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell4 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell5 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell6 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell7 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell8 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell9 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell10 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell11 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell12 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell13 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.rowHeaderCell1 = new GrapeCity.Win.MultiRow.RowHeaderCell();
            this.txtCode = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtName = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell5 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtCost = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell7 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtTax = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtQty = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtUnitsPrice = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtAmount = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtRemark = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtShoinDiachoF = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.txtShoinCode = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtShoinName = new GrapeCity.Win.MultiRow.TextBoxCell();
            // 
            // Row
            // 
            this.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.Row.Cells.Add(this.rowHeaderCell1);
            this.Row.Cells.Add(this.txtCode);
            this.Row.Cells.Add(this.txtName);
            this.Row.Cells.Add(this.gcTextBoxCell5);
            this.Row.Cells.Add(this.txtCost);
            this.Row.Cells.Add(this.gcTextBoxCell7);
            this.Row.Cells.Add(this.txtTax);
            this.Row.Cells.Add(this.txtQty);
            this.Row.Cells.Add(this.txtUnitsPrice);
            this.Row.Cells.Add(this.txtAmount);
            this.Row.Cells.Add(this.txtRemark);
            this.Row.Cells.Add(this.txtShoinDiachoF);
            this.Row.Cells.Add(this.txtShoinCode);
            this.Row.Cells.Add(this.txtShoinName);
            this.Row.Height = 36;
            this.Row.Width = 881;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.headerCell1);
            this.columnHeaderSection1.Cells.Add(this.headerCell2);
            this.columnHeaderSection1.Cells.Add(this.headerCell3);
            this.columnHeaderSection1.Cells.Add(this.headerCell4);
            this.columnHeaderSection1.Cells.Add(this.headerCell5);
            this.columnHeaderSection1.Cells.Add(this.headerCell6);
            this.columnHeaderSection1.Cells.Add(this.headerCell7);
            this.columnHeaderSection1.Cells.Add(this.headerCell8);
            this.columnHeaderSection1.Cells.Add(this.headerCell9);
            this.columnHeaderSection1.Cells.Add(this.headerCell10);
            this.columnHeaderSection1.Cells.Add(this.headerCell11);
            this.columnHeaderSection1.Cells.Add(this.headerCell12);
            this.columnHeaderSection1.Cells.Add(this.headerCell13);
            this.columnHeaderSection1.Height = 30;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 881;
            // 
            // headerCell1
            // 
            this.headerCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell1.Location = new System.Drawing.Point(0, 0);
            this.headerCell1.Name = "headerCell1";
            this.headerCell1.Size = new System.Drawing.Size(26, 30);
            cellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border13.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle13.Border = border13;
            cellStyle13.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle13.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle13.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell1.Style = cellStyle13;
            this.headerCell1.TabIndex = 0;
            this.headerCell1.Value = "No.";
            // 
            // headerCell2
            // 
            this.headerCell2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell2.Location = new System.Drawing.Point(26, 0);
            this.headerCell2.Name = "headerCell2";
            this.headerCell2.Size = new System.Drawing.Size(56, 30);
            cellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border14.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle14.Border = border14;
            cellStyle14.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle14.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle14.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell2.Style = cellStyle14;
            this.headerCell2.TabIndex = 1;
            this.headerCell2.Value = "内訳";
            // 
            // headerCell3
            // 
            this.headerCell3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell3.Location = new System.Drawing.Point(82, 0);
            this.headerCell3.Name = "headerCell3";
            this.headerCell3.Size = new System.Drawing.Size(150, 15);
            cellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border15.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle15.Border = border15;
            cellStyle15.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle15.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle15.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell3.Style = cellStyle15;
            this.headerCell3.TabIndex = 2;
            this.headerCell3.Value = "コード";
            // 
            // headerCell4
            // 
            this.headerCell4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell4.Location = new System.Drawing.Point(82, 15);
            this.headerCell4.Name = "headerCell4";
            this.headerCell4.Size = new System.Drawing.Size(350, 15);
            cellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border16.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle16.Border = border16;
            cellStyle16.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle16.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle16.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell4.Style = cellStyle16;
            this.headerCell4.TabIndex = 3;
            this.headerCell4.Value = "商品名/摘要";
            // 
            // headerCell5
            // 
            this.headerCell5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell5.Location = new System.Drawing.Point(432, 15);
            this.headerCell5.Name = "headerCell5";
            this.headerCell5.Size = new System.Drawing.Size(100, 15);
            cellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border17.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle17.Border = border17;
            cellStyle17.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle17.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle17.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell5.Style = cellStyle17;
            this.headerCell5.TabIndex = 4;
            this.headerCell5.Value = "数量";
            // 
            // headerCell6
            // 
            this.headerCell6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell6.Location = new System.Drawing.Point(432, 0);
            this.headerCell6.Name = "headerCell6";
            this.headerCell6.Size = new System.Drawing.Size(100, 15);
            cellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border18.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle18.Border = border18;
            cellStyle18.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle18.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle18.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell6.Style = cellStyle18;
            this.headerCell6.TabIndex = 5;
            this.headerCell6.Value = "在庫";
            // 
            // headerCell7
            // 
            this.headerCell7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell7.Location = new System.Drawing.Point(232, 0);
            this.headerCell7.Name = "headerCell7";
            this.headerCell7.Size = new System.Drawing.Size(48, 15);
            cellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border19.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border19.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border19.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border19.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle19.Border = border19;
            cellStyle19.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle19.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle19.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell7.Style = cellStyle19;
            this.headerCell7.TabIndex = 6;
            this.headerCell7.Value = "単位";
            // 
            // headerCell8
            // 
            this.headerCell8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell8.Location = new System.Drawing.Point(532, 15);
            this.headerCell8.Name = "headerCell8";
            this.headerCell8.Size = new System.Drawing.Size(100, 15);
            cellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border20.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border20.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border20.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border20.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle20.Border = border20;
            cellStyle20.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle20.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle20.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell8.Style = cellStyle20;
            this.headerCell8.TabIndex = 7;
            this.headerCell8.Value = "単価";
            // 
            // headerCell9
            // 
            this.headerCell9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell9.Location = new System.Drawing.Point(532, 0);
            this.headerCell9.Name = "headerCell9";
            this.headerCell9.Size = new System.Drawing.Size(100, 15);
            cellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border21.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border21.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border21.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border21.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle21.Border = border21;
            cellStyle21.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle21.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle21.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell9.Style = cellStyle21;
            this.headerCell9.TabIndex = 8;
            this.headerCell9.Value = "原単価";
            // 
            // headerCell10
            // 
            this.headerCell10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell10.Location = new System.Drawing.Point(632, 15);
            this.headerCell10.Name = "headerCell10";
            this.headerCell10.Size = new System.Drawing.Size(119, 15);
            cellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border22.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border22.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border22.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border22.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle22.Border = border22;
            cellStyle22.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle22.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle22.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell10.Style = cellStyle22;
            this.headerCell10.TabIndex = 9;
            this.headerCell10.Value = "金額";
            // 
            // headerCell11
            // 
            this.headerCell11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell11.Location = new System.Drawing.Point(632, 0);
            this.headerCell11.Name = "headerCell11";
            this.headerCell11.Size = new System.Drawing.Size(119, 15);
            cellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border23.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border23.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border23.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border23.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle23.Border = border23;
            cellStyle23.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle23.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle23.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell11.Style = cellStyle23;
            this.headerCell11.TabIndex = 10;
            this.headerCell11.Value = "粗利";
            // 
            // headerCell12
            // 
            this.headerCell12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell12.Location = new System.Drawing.Point(751, 15);
            this.headerCell12.Name = "headerCell12";
            this.headerCell12.Size = new System.Drawing.Size(130, 15);
            cellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border24.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border24.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border24.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border24.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle24.Border = border24;
            cellStyle24.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle24.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle24.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell12.Style = cellStyle24;
            this.headerCell12.TabIndex = 11;
            this.headerCell12.Value = "備考";
            // 
            // headerCell13
            // 
            this.headerCell13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell13.Location = new System.Drawing.Point(751, 0);
            this.headerCell13.Name = "headerCell13";
            this.headerCell13.Size = new System.Drawing.Size(130, 15);
            cellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border25.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border25.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border25.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border25.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle25.Border = border25;
            cellStyle25.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle25.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle25.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell13.Style = cellStyle25;
            this.headerCell13.TabIndex = 12;
            this.headerCell13.Value = "課税区分";
            // 
            // rowHeaderCell1
            // 
            this.rowHeaderCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rowHeaderCell1.Location = new System.Drawing.Point(0, 0);
            this.rowHeaderCell1.Name = "rowHeaderCell1";
            this.rowHeaderCell1.Size = new System.Drawing.Size(26, 36);
            border1.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle1.Border = border1;
            this.rowHeaderCell1.Style = cellStyle1;
            this.rowHeaderCell1.TabIndex = 1;
            // 
            // txtCode
            // 
            this.txtCode.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCode.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCode.HighlightText = true;
            this.txtCode.Location = new System.Drawing.Point(82, 0);
            this.txtCode.Name = "txtCode";
            this.txtCode.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtCode.Size = new System.Drawing.Size(150, 18);
            border2.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle2.Border = border2;
            cellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.txtCode.Style = cellStyle2;
            this.txtCode.TabIndex = 4;
            // 
            // txtName
            // 
            this.txtName.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtName.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtName.HighlightText = true;
            this.txtName.Location = new System.Drawing.Point(82, 18);
            this.txtName.Name = "txtName";
            this.txtName.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtName.Size = new System.Drawing.Size(350, 18);
            border3.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle3.Border = border3;
            cellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomLeft;
            this.txtName.Style = cellStyle3;
            this.txtName.TabIndex = 5;
            // 
            // gcTextBoxCell5
            // 
            this.gcTextBoxCell5.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell5.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell5.HighlightText = true;
            this.gcTextBoxCell5.Location = new System.Drawing.Point(432, 0);
            this.gcTextBoxCell5.Name = "gcTextBoxCell5";
            this.gcTextBoxCell5.ReadOnly = true;
            this.gcTextBoxCell5.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell5.Size = new System.Drawing.Size(100, 18);
            border4.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle4.Border = border4;
            cellStyle4.ForeColor = System.Drawing.Color.Navy;
            cellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.gcTextBoxCell5.Style = cellStyle4;
            this.gcTextBoxCell5.TabIndex = 6;
            // 
            // txtCost
            // 
            this.txtCost.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCost.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCost.HighlightText = true;
            this.txtCost.Location = new System.Drawing.Point(532, 0);
            this.txtCost.Name = "txtCost";
            this.txtCost.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtCost.Size = new System.Drawing.Size(100, 18);
            border5.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle5.Border = border5;
            cellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.txtCost.Style = cellStyle5;
            this.txtCost.TabIndex = 7;
            // 
            // gcTextBoxCell7
            // 
            this.gcTextBoxCell7.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell7.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell7.HighlightText = true;
            this.gcTextBoxCell7.Location = new System.Drawing.Point(632, 0);
            this.gcTextBoxCell7.Name = "gcTextBoxCell7";
            this.gcTextBoxCell7.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell7.Size = new System.Drawing.Size(119, 18);
            border6.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle6.Border = border6;
            cellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            cellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle6.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.gcTextBoxCell7.Style = cellStyle6;
            this.gcTextBoxCell7.TabIndex = 8;
            // 
            // txtTax
            // 
            this.txtTax.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTax.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTax.HighlightText = true;
            this.txtTax.Location = new System.Drawing.Point(751, 0);
            this.txtTax.Name = "txtTax";
            this.txtTax.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtTax.Size = new System.Drawing.Size(130, 18);
            border7.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle7.Border = border7;
            cellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            this.txtTax.Style = cellStyle7;
            this.txtTax.TabIndex = 9;
            // 
            // txtQty
            // 
            this.txtQty.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtQty.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtQty.HighlightText = true;
            this.txtQty.Location = new System.Drawing.Point(432, 18);
            this.txtQty.Name = "txtQty";
            this.txtQty.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtQty.Size = new System.Drawing.Size(100, 18);
            border8.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle8.Border = border8;
            cellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle8.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.txtQty.Style = cellStyle8;
            this.txtQty.TabIndex = 10;
            // 
            // txtUnitsPrice
            // 
            this.txtUnitsPrice.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtUnitsPrice.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtUnitsPrice.HighlightText = true;
            this.txtUnitsPrice.Location = new System.Drawing.Point(532, 18);
            this.txtUnitsPrice.Name = "txtUnitsPrice";
            this.txtUnitsPrice.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtUnitsPrice.Size = new System.Drawing.Size(100, 18);
            border9.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle9.Border = border9;
            cellStyle9.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle9.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.txtUnitsPrice.Style = cellStyle9;
            this.txtUnitsPrice.TabIndex = 11;
            // 
            // txtAmount
            // 
            this.txtAmount.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtAmount.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtAmount.HighlightText = true;
            this.txtAmount.Location = new System.Drawing.Point(632, 18);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtAmount.Size = new System.Drawing.Size(119, 18);
            border10.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle10.Border = border10;
            cellStyle10.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle10.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.txtAmount.Style = cellStyle10;
            this.txtAmount.TabIndex = 12;
            // 
            // txtRemark
            // 
            this.txtRemark.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtRemark.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtRemark.HighlightText = true;
            this.txtRemark.Location = new System.Drawing.Point(751, 18);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtRemark.Size = new System.Drawing.Size(130, 18);
            border11.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle11.Border = border11;
            cellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle11.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomLeft;
            this.txtRemark.Style = cellStyle11;
            this.txtRemark.TabIndex = 13;
            // 
            // txtShoinDiachoF
            // 
            this.txtShoinDiachoF.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtShoinDiachoF.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtShoinDiachoF.HighlightText = true;
            this.txtShoinDiachoF.Location = new System.Drawing.Point(232, 0);
            this.txtShoinDiachoF.Name = "txtShoinDiachoF";
            this.txtShoinDiachoF.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.txtShoinDiachoF.Size = new System.Drawing.Size(48, 18);
            border12.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle12.Border = border12;
            cellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            this.txtShoinDiachoF.Style = cellStyle12;
            this.txtShoinDiachoF.TabIndex = 14;
            // 
            // txtShoinCode
            // 
            this.txtShoinCode.Location = new System.Drawing.Point(26, 0);
            this.txtShoinCode.Name = "txtShoinCode";
            this.txtShoinCode.Size = new System.Drawing.Size(56, 18);
            this.txtShoinCode.TabIndex = 15;
            // 
            // txtShoinName
            // 
            this.txtShoinName.Location = new System.Drawing.Point(26, 18);
            this.txtShoinName.Name = "txtShoinName";
            this.txtShoinName.Size = new System.Drawing.Size(56, 18);
            this.txtShoinName.TabIndex = 16;
            // 
            // TempJutyuEntry
            // 
            cellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(228)))));
            this.AlternatingRowsDefaultCellStyle = cellStyle26;
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            cellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            cellStyle27.BackgroundGradientEffect = new GrapeCity.Win.MultiRow.GradientEffect(null, GrapeCity.Win.MultiRow.GradientStyle.None, GrapeCity.Win.MultiRow.GradientDirection.Center);
            border26.Outline = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Silver);
            cellStyle27.Border = border26;
            cellStyle27.DisabledBackColor = System.Drawing.SystemColors.Control;
            cellStyle27.DisabledForeColor = System.Drawing.SystemColors.GrayText;
            cellStyle27.DisabledGradientEffect = new GrapeCity.Win.MultiRow.GradientEffect(null, GrapeCity.Win.MultiRow.GradientStyle.None, GrapeCity.Win.MultiRow.GradientDirection.Center);
            cellStyle27.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            cellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            cellStyle27.Format = "";
            cellStyle27.GradientDirection = GrapeCity.Win.MultiRow.GradientDirection.Center;
            cellStyle27.GradientStyle = GrapeCity.Win.MultiRow.GradientStyle.None;
            cellStyle27.ImageAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            cellStyle27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            cellStyle27.ImeSentenceMode = GrapeCity.Win.MultiRow.ImeSentenceMode.NoControl;
            cellStyle27.InputScope = GrapeCity.Win.MultiRow.InputScopeNameValue.Default;
            cellStyle27.LineAdjustment = GrapeCity.Win.MultiRow.LineAdjustment.None;
            cellStyle27.Margin = new System.Windows.Forms.Padding(0);
            cellStyle27.MouseOverGradientEffect = new GrapeCity.Win.MultiRow.GradientEffect(null, GrapeCity.Win.MultiRow.GradientStyle.None, GrapeCity.Win.MultiRow.GradientDirection.Center);
            cellStyle27.Multiline = GrapeCity.Win.MultiRow.MultiRowTriState.False;
            cellStyle27.Padding = new System.Windows.Forms.Padding(0);
            cellStyle27.PatternColor = System.Drawing.SystemColors.WindowText;
            cellStyle27.PatternStyle = GrapeCity.Win.MultiRow.MultiRowHatchStyle.None;
            cellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            cellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            cellStyle27.SelectionGradientEffect = new GrapeCity.Win.MultiRow.GradientEffect(null, GrapeCity.Win.MultiRow.GradientStyle.None, GrapeCity.Win.MultiRow.GradientDirection.Center);
            cellStyle27.TextAdjustment = GrapeCity.Win.MultiRow.TextAdjustment.Near;
            cellStyle27.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleLeft;
            cellStyle27.TextAngle = 0F;
            cellStyle27.TextEffect = GrapeCity.Win.MultiRow.TextEffect.Flat;
            cellStyle27.TextImageRelation = GrapeCity.Win.MultiRow.MultiRowTextImageRelation.Overlay;
            cellStyle27.TextIndent = 0;
            cellStyle27.TextVertical = GrapeCity.Win.MultiRow.MultiRowTriState.False;
            cellStyle27.UseCompatibleTextRendering = GrapeCity.Win.MultiRow.MultiRowTriState.False;
            cellStyle27.WordWrap = GrapeCity.Win.MultiRow.MultiRowTriState.True;
            this.DefaultCellStyle = cellStyle27;
            this.Height = 66;
            this.Width = 881;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell2;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell3;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell4;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell5;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell6;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell7;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell8;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell9;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell10;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell11;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell12;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell13;
        private GrapeCity.Win.MultiRow.RowHeaderCell rowHeaderCell1;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtCode;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtName;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell5;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtCost;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell7;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtTax;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtQty;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtUnitsPrice;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtAmount;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtRemark;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell txtShoinDiachoF;
        private GrapeCity.Win.MultiRow.TextBoxCell txtShoinCode;
        private GrapeCity.Win.MultiRow.TextBoxCell txtShoinName;
    }
}
