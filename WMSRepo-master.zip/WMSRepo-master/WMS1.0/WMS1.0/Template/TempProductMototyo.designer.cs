﻿namespace WMS_V1.UI
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempProductMototyo
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border1 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border2 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border3 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border4 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border5 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border6 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle7 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border7 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle8 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border8 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle9 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border9 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle10 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border10 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle11 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border11 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle12 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border12 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle13 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border13 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle14 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border14 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle15 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border15 = new GrapeCity.Win.MultiRow.Border();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.headerCell1 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell2 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell3 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell4 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell5 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell6 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell7 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell8 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell9 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell10 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell11 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell12 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell13 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell14 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell15 = new GrapeCity.Win.MultiRow.HeaderCell();
            // 
            // Row
            // 
            this.Row.Height = 21;
            this.Row.Width = 709;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.headerCell1);
            this.columnHeaderSection1.Cells.Add(this.headerCell2);
            this.columnHeaderSection1.Cells.Add(this.headerCell3);
            this.columnHeaderSection1.Cells.Add(this.headerCell4);
            this.columnHeaderSection1.Cells.Add(this.headerCell5);
            this.columnHeaderSection1.Cells.Add(this.headerCell6);
            this.columnHeaderSection1.Cells.Add(this.headerCell7);
            this.columnHeaderSection1.Cells.Add(this.headerCell8);
            this.columnHeaderSection1.Cells.Add(this.headerCell9);
            this.columnHeaderSection1.Cells.Add(this.headerCell10);
            this.columnHeaderSection1.Cells.Add(this.headerCell11);
            this.columnHeaderSection1.Cells.Add(this.headerCell12);
            this.columnHeaderSection1.Cells.Add(this.headerCell13);
            this.columnHeaderSection1.Cells.Add(this.headerCell14);
            this.columnHeaderSection1.Cells.Add(this.headerCell15);
            this.columnHeaderSection1.Height = 30;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 709;
            // 
            // headerCell1
            // 
            this.headerCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell1.Location = new System.Drawing.Point(0, 0);
            this.headerCell1.Name = "headerCell1";
            this.headerCell1.Size = new System.Drawing.Size(100, 15);
            cellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border1.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle1.Border = border1;
            cellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle1.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle1.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell1.Style = cellStyle1;
            this.headerCell1.TabIndex = 0;
            this.headerCell1.Value = "伝票日付";
            // 
            // headerCell2
            // 
            this.headerCell2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell2.Location = new System.Drawing.Point(0, 15);
            this.headerCell2.Name = "headerCell2";
            this.headerCell2.Size = new System.Drawing.Size(100, 15);
            cellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border2.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle2.Border = border2;
            cellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle2.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle2.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell2.Style = cellStyle2;
            this.headerCell2.TabIndex = 1;
            this.headerCell2.Value = "伝票番号";
            // 
            // headerCell3
            // 
            this.headerCell3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell3.Location = new System.Drawing.Point(100, 0);
            this.headerCell3.Name = "headerCell3";
            this.headerCell3.Size = new System.Drawing.Size(100, 15);
            cellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border3.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle3.Border = border3;
            cellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle3.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell3.Style = cellStyle3;
            this.headerCell3.TabIndex = 2;
            this.headerCell3.Value = "得意先コード";
            // 
            // headerCell4
            // 
            this.headerCell4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell4.Location = new System.Drawing.Point(100, 15);
            this.headerCell4.Name = "headerCell4";
            this.headerCell4.Size = new System.Drawing.Size(299, 15);
            cellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border4.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle4.Border = border4;
            cellStyle4.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle4.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle4.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell4.Style = cellStyle4;
            this.headerCell4.TabIndex = 3;
            this.headerCell4.Value = "得意先名称";
            // 
            // headerCell5
            // 
            this.headerCell5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell5.Location = new System.Drawing.Point(200, 0);
            this.headerCell5.Name = "headerCell5";
            this.headerCell5.Size = new System.Drawing.Size(199, 15);
            cellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border5.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle5.Border = border5;
            cellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle5.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell5.Style = cellStyle5;
            this.headerCell5.TabIndex = 4;
            this.headerCell5.Value = "得意先コード";
            // 
            // headerCell6
            // 
            this.headerCell6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell6.Location = new System.Drawing.Point(399, 0);
            this.headerCell6.Name = "headerCell6";
            this.headerCell6.Size = new System.Drawing.Size(62, 15);
            cellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border6.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle6.Border = border6;
            cellStyle6.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle6.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle6.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell6.Style = cellStyle6;
            this.headerCell6.TabIndex = 5;
            this.headerCell6.Value = "原価";
            // 
            // headerCell7
            // 
            this.headerCell7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell7.Location = new System.Drawing.Point(399, 15);
            this.headerCell7.Name = "headerCell7";
            this.headerCell7.Size = new System.Drawing.Size(62, 15);
            cellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border7.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border7.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border7.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border7.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle7.Border = border7;
            cellStyle7.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle7.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle7.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell7.Style = cellStyle7;
            this.headerCell7.TabIndex = 6;
            this.headerCell7.Value = "単価";
            // 
            // headerCell8
            // 
            this.headerCell8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell8.Location = new System.Drawing.Point(461, 0);
            this.headerCell8.Name = "headerCell8";
            this.headerCell8.Size = new System.Drawing.Size(62, 15);
            cellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border8.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle8.Border = border8;
            cellStyle8.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle8.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle8.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell8.Style = cellStyle8;
            this.headerCell8.TabIndex = 7;
            // 
            // headerCell9
            // 
            this.headerCell9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell9.Location = new System.Drawing.Point(461, 15);
            this.headerCell9.Name = "headerCell9";
            this.headerCell9.Size = new System.Drawing.Size(62, 15);
            cellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border9.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle9.Border = border9;
            cellStyle9.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle9.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle9.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell9.Style = cellStyle9;
            this.headerCell9.TabIndex = 8;
            this.headerCell9.Value = "原価";
            // 
            // headerCell10
            // 
            this.headerCell10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell10.Location = new System.Drawing.Point(523, 0);
            this.headerCell10.Name = "headerCell10";
            this.headerCell10.Size = new System.Drawing.Size(62, 15);
            cellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border10.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle10.Border = border10;
            cellStyle10.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle10.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle10.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell10.Style = cellStyle10;
            this.headerCell10.TabIndex = 9;
            // 
            // headerCell11
            // 
            this.headerCell11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell11.Location = new System.Drawing.Point(523, 15);
            this.headerCell11.Name = "headerCell11";
            this.headerCell11.Size = new System.Drawing.Size(62, 15);
            cellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border11.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle11.Border = border11;
            cellStyle11.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle11.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle11.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell11.Style = cellStyle11;
            this.headerCell11.TabIndex = 10;
            this.headerCell11.Value = "入庫";
            // 
            // headerCell12
            // 
            this.headerCell12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell12.Location = new System.Drawing.Point(585, 0);
            this.headerCell12.Name = "headerCell12";
            this.headerCell12.Size = new System.Drawing.Size(62, 15);
            cellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border12.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle12.Border = border12;
            cellStyle12.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle12.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle12.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell12.Style = cellStyle12;
            this.headerCell12.TabIndex = 11;
            // 
            // headerCell13
            // 
            this.headerCell13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell13.Location = new System.Drawing.Point(585, 15);
            this.headerCell13.Name = "headerCell13";
            this.headerCell13.Size = new System.Drawing.Size(62, 15);
            cellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border13.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle13.Border = border13;
            cellStyle13.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle13.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle13.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell13.Style = cellStyle13;
            this.headerCell13.TabIndex = 12;
            this.headerCell13.Value = "出庫";
            // 
            // headerCell14
            // 
            this.headerCell14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell14.Location = new System.Drawing.Point(647, 0);
            this.headerCell14.Name = "headerCell14";
            this.headerCell14.Size = new System.Drawing.Size(62, 15);
            cellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border14.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle14.Border = border14;
            cellStyle14.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle14.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle14.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell14.Style = cellStyle14;
            this.headerCell14.TabIndex = 13;
            // 
            // headerCell15
            // 
            this.headerCell15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell15.Location = new System.Drawing.Point(647, 15);
            this.headerCell15.Name = "headerCell15";
            this.headerCell15.Size = new System.Drawing.Size(62, 15);
            cellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border15.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle15.Border = border15;
            cellStyle15.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle15.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle15.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell15.Style = cellStyle15;
            this.headerCell15.TabIndex = 14;
            this.headerCell15.Value = "在庫";
            // 
            // TempProductMototyo
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 51;
            this.Width = 709;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell2;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell3;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell4;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell5;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell6;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell7;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell8;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell9;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell10;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell11;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell12;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell13;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell14;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell15;
    }
}
