﻿namespace WMS_V1.UI
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempSeisankanri
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle7 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle8 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle9 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle10 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle11 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle12 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle13 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle14 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle15 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle16 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle17 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle18 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle19 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle20 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle21 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle22 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle23 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle24 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle25 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle26 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle27 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle28 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle29 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle30 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle31 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle32 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle33 = new GrapeCity.Win.MultiRow.CellStyle();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.textBoxCell1 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell2 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell3 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell4 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell5 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell6 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell7 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell8 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell9 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell10 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell11 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell12 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell13 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell14 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell15 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell16 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell17 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell18 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell19 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell20 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell21 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell22 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell23 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell24 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell25 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell26 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell27 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell28 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell29 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell30 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell31 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell32 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell33 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell34 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell35 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell36 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell37 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell38 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell39 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell40 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell41 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell42 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell43 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell44 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell45 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell46 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell47 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell48 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell49 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell50 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell51 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell52 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell53 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell54 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell55 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell56 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell57 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell58 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell59 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell60 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell61 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell62 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell63 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell64 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell65 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell66 = new GrapeCity.Win.MultiRow.TextBoxCell();
            // 
            // Row
            // 
            this.Row.Cells.Add(this.textBoxCell34);
            this.Row.Cells.Add(this.textBoxCell35);
            this.Row.Cells.Add(this.textBoxCell36);
            this.Row.Cells.Add(this.textBoxCell37);
            this.Row.Cells.Add(this.textBoxCell38);
            this.Row.Cells.Add(this.textBoxCell39);
            this.Row.Cells.Add(this.textBoxCell40);
            this.Row.Cells.Add(this.textBoxCell41);
            this.Row.Cells.Add(this.textBoxCell42);
            this.Row.Cells.Add(this.textBoxCell43);
            this.Row.Cells.Add(this.textBoxCell44);
            this.Row.Cells.Add(this.textBoxCell45);
            this.Row.Cells.Add(this.textBoxCell46);
            this.Row.Cells.Add(this.textBoxCell47);
            this.Row.Cells.Add(this.textBoxCell48);
            this.Row.Cells.Add(this.textBoxCell49);
            this.Row.Cells.Add(this.textBoxCell50);
            this.Row.Cells.Add(this.textBoxCell51);
            this.Row.Cells.Add(this.textBoxCell52);
            this.Row.Cells.Add(this.textBoxCell53);
            this.Row.Cells.Add(this.textBoxCell54);
            this.Row.Cells.Add(this.textBoxCell55);
            this.Row.Cells.Add(this.textBoxCell56);
            this.Row.Cells.Add(this.textBoxCell57);
            this.Row.Cells.Add(this.textBoxCell58);
            this.Row.Cells.Add(this.textBoxCell59);
            this.Row.Cells.Add(this.textBoxCell60);
            this.Row.Cells.Add(this.textBoxCell61);
            this.Row.Cells.Add(this.textBoxCell62);
            this.Row.Cells.Add(this.textBoxCell63);
            this.Row.Cells.Add(this.textBoxCell64);
            this.Row.Cells.Add(this.textBoxCell65);
            this.Row.Cells.Add(this.textBoxCell66);
            this.Row.Height = 63;
            this.Row.Width = 3700;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.textBoxCell1);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell2);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell3);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell4);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell5);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell6);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell7);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell8);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell9);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell10);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell11);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell12);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell13);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell14);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell15);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell16);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell17);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell18);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell19);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell20);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell21);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell22);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell23);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell24);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell25);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell26);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell27);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell28);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell29);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell30);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell31);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell32);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell33);
            this.columnHeaderSection1.Height = 21;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 3700;
            // 
            // textBoxCell1
            // 
            this.textBoxCell1.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell1.Name = "textBoxCell1";
            this.textBoxCell1.Size = new System.Drawing.Size(60, 21);
            cellStyle1.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle1.ForeColor = System.Drawing.Color.White;
            cellStyle1.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell1.Style = cellStyle1;
            this.textBoxCell1.TabIndex = 0;
            this.textBoxCell1.Value = "会社名";
            // 
            // textBoxCell2
            // 
            this.textBoxCell2.Location = new System.Drawing.Point(60, 0);
            this.textBoxCell2.Name = "textBoxCell2";
            this.textBoxCell2.Size = new System.Drawing.Size(60, 21);
            cellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle2.ForeColor = System.Drawing.Color.White;
            cellStyle2.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell2.Style = cellStyle2;
            this.textBoxCell2.TabIndex = 1;
            this.textBoxCell2.Value = "船積地";
            // 
            // textBoxCell3
            // 
            this.textBoxCell3.Location = new System.Drawing.Point(120, 0);
            this.textBoxCell3.Name = "textBoxCell3";
            this.textBoxCell3.Size = new System.Drawing.Size(60, 21);
            cellStyle3.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle3.ForeColor = System.Drawing.Color.White;
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell3.Style = cellStyle3;
            this.textBoxCell3.TabIndex = 2;
            this.textBoxCell3.Value = "部門";
            // 
            // textBoxCell4
            // 
            this.textBoxCell4.Location = new System.Drawing.Point(180, 0);
            this.textBoxCell4.Name = "textBoxCell4";
            this.textBoxCell4.Size = new System.Drawing.Size(81, 21);
            cellStyle4.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle4.ForeColor = System.Drawing.Color.White;
            cellStyle4.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell4.Style = cellStyle4;
            this.textBoxCell4.TabIndex = 3;
            this.textBoxCell4.Value = "デザイン担当";
            // 
            // textBoxCell5
            // 
            this.textBoxCell5.Location = new System.Drawing.Point(261, 0);
            this.textBoxCell5.Name = "textBoxCell5";
            this.textBoxCell5.Size = new System.Drawing.Size(81, 21);
            cellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle5.ForeColor = System.Drawing.Color.White;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell5.Style = cellStyle5;
            this.textBoxCell5.TabIndex = 4;
            this.textBoxCell5.Value = "交渉担当";
            // 
            // textBoxCell6
            // 
            this.textBoxCell6.Location = new System.Drawing.Point(342, 0);
            this.textBoxCell6.Name = "textBoxCell6";
            this.textBoxCell6.Size = new System.Drawing.Size(81, 21);
            cellStyle6.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle6.ForeColor = System.Drawing.Color.White;
            cellStyle6.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell6.Style = cellStyle6;
            this.textBoxCell6.TabIndex = 5;
            this.textBoxCell6.Value = "発注担当";
            // 
            // textBoxCell7
            // 
            this.textBoxCell7.Location = new System.Drawing.Point(423, 0);
            this.textBoxCell7.Name = "textBoxCell7";
            this.textBoxCell7.Size = new System.Drawing.Size(81, 21);
            cellStyle7.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle7.ForeColor = System.Drawing.Color.White;
            cellStyle7.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell7.Style = cellStyle7;
            this.textBoxCell7.TabIndex = 6;
            this.textBoxCell7.Value = "素材";
            // 
            // textBoxCell8
            // 
            this.textBoxCell8.Location = new System.Drawing.Point(504, 0);
            this.textBoxCell8.Name = "textBoxCell8";
            this.textBoxCell8.Size = new System.Drawing.Size(81, 21);
            cellStyle8.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle8.ForeColor = System.Drawing.Color.White;
            cellStyle8.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell8.Style = cellStyle8;
            this.textBoxCell8.TabIndex = 7;
            this.textBoxCell8.Value = "発注No.";
            // 
            // textBoxCell9
            // 
            this.textBoxCell9.Location = new System.Drawing.Point(585, 0);
            this.textBoxCell9.Name = "textBoxCell9";
            this.textBoxCell9.Size = new System.Drawing.Size(81, 21);
            cellStyle9.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle9.ForeColor = System.Drawing.Color.White;
            cellStyle9.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell9.Style = cellStyle9;
            this.textBoxCell9.TabIndex = 8;
            this.textBoxCell9.Value = "FCNo.";
            // 
            // textBoxCell10
            // 
            this.textBoxCell10.Location = new System.Drawing.Point(666, 0);
            this.textBoxCell10.Name = "textBoxCell10";
            this.textBoxCell10.Size = new System.Drawing.Size(135, 21);
            cellStyle10.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle10.ForeColor = System.Drawing.Color.White;
            cellStyle10.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell10.Style = cellStyle10;
            this.textBoxCell10.TabIndex = 9;
            this.textBoxCell10.Value = "画像";
            // 
            // textBoxCell11
            // 
            this.textBoxCell11.Location = new System.Drawing.Point(801, 0);
            this.textBoxCell11.Name = "textBoxCell11";
            this.textBoxCell11.Size = new System.Drawing.Size(300, 21);
            cellStyle11.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle11.ForeColor = System.Drawing.Color.White;
            cellStyle11.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell11.Style = cellStyle11;
            this.textBoxCell11.TabIndex = 10;
            this.textBoxCell11.Value = "商品名（英語表記）";
            // 
            // textBoxCell12
            // 
            this.textBoxCell12.Location = new System.Drawing.Point(1101, 0);
            this.textBoxCell12.Name = "textBoxCell12";
            this.textBoxCell12.Size = new System.Drawing.Size(300, 21);
            cellStyle12.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle12.ForeColor = System.Drawing.Color.White;
            cellStyle12.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell12.Style = cellStyle12;
            this.textBoxCell12.TabIndex = 11;
            this.textBoxCell12.Value = "商品名（日本語表記）";
            // 
            // textBoxCell13
            // 
            this.textBoxCell13.Location = new System.Drawing.Point(1401, 0);
            this.textBoxCell13.Name = "textBoxCell13";
            this.textBoxCell13.Size = new System.Drawing.Size(98, 21);
            cellStyle13.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle13.ForeColor = System.Drawing.Color.White;
            cellStyle13.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell13.Style = cellStyle13;
            this.textBoxCell13.TabIndex = 12;
            this.textBoxCell13.Value = "サイズ";
            // 
            // textBoxCell14
            // 
            this.textBoxCell14.Location = new System.Drawing.Point(1499, 0);
            this.textBoxCell14.Name = "textBoxCell14";
            this.textBoxCell14.Size = new System.Drawing.Size(98, 21);
            cellStyle14.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle14.ForeColor = System.Drawing.Color.White;
            cellStyle14.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell14.Style = cellStyle14;
            this.textBoxCell14.TabIndex = 13;
            this.textBoxCell14.Value = "発注数";
            // 
            // textBoxCell15
            // 
            this.textBoxCell15.Location = new System.Drawing.Point(1597, 0);
            this.textBoxCell15.Name = "textBoxCell15";
            this.textBoxCell15.Size = new System.Drawing.Size(98, 21);
            cellStyle15.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle15.ForeColor = System.Drawing.Color.White;
            cellStyle15.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell15.Style = cellStyle15;
            this.textBoxCell15.TabIndex = 14;
            this.textBoxCell15.Value = "Unit Price(US$)";
            // 
            // textBoxCell16
            // 
            this.textBoxCell16.Location = new System.Drawing.Point(1695, 0);
            this.textBoxCell16.Name = "textBoxCell16";
            this.textBoxCell16.Size = new System.Drawing.Size(98, 21);
            cellStyle16.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle16.ForeColor = System.Drawing.Color.White;
            cellStyle16.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell16.Style = cellStyle16;
            this.textBoxCell16.TabIndex = 15;
            this.textBoxCell16.Value = "証紙郵送";
            // 
            // textBoxCell17
            // 
            this.textBoxCell17.Location = new System.Drawing.Point(1793, 0);
            this.textBoxCell17.Name = "textBoxCell17";
            this.textBoxCell17.Size = new System.Drawing.Size(98, 21);
            cellStyle17.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle17.ForeColor = System.Drawing.Color.White;
            cellStyle17.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell17.Style = cellStyle17;
            this.textBoxCell17.TabIndex = 16;
            this.textBoxCell17.Value = "上代";
            // 
            // textBoxCell18
            // 
            this.textBoxCell18.Location = new System.Drawing.Point(1891, 0);
            this.textBoxCell18.Name = "textBoxCell18";
            this.textBoxCell18.Size = new System.Drawing.Size(98, 21);
            cellStyle18.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle18.ForeColor = System.Drawing.Color.White;
            cellStyle18.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell18.Style = cellStyle18;
            this.textBoxCell18.TabIndex = 17;
            this.textBoxCell18.Value = "副資材";
            // 
            // textBoxCell19
            // 
            this.textBoxCell19.Location = new System.Drawing.Point(1989, 0);
            this.textBoxCell19.Name = "textBoxCell19";
            this.textBoxCell19.Size = new System.Drawing.Size(98, 21);
            cellStyle19.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle19.ForeColor = System.Drawing.Color.White;
            cellStyle19.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell19.Style = cellStyle19;
            this.textBoxCell19.TabIndex = 18;
            this.textBoxCell19.Value = "カートン";
            // 
            // textBoxCell20
            // 
            this.textBoxCell20.Location = new System.Drawing.Point(2087, 0);
            this.textBoxCell20.Name = "textBoxCell20";
            this.textBoxCell20.Size = new System.Drawing.Size(98, 21);
            cellStyle20.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle20.ForeColor = System.Drawing.Color.White;
            cellStyle20.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell20.Style = cellStyle20;
            this.textBoxCell20.TabIndex = 19;
            this.textBoxCell20.Value = "出荷前サンプル";
            // 
            // textBoxCell21
            // 
            this.textBoxCell21.Location = new System.Drawing.Point(2185, 0);
            this.textBoxCell21.Name = "textBoxCell21";
            this.textBoxCell21.Size = new System.Drawing.Size(98, 21);
            cellStyle21.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle21.ForeColor = System.Drawing.Color.White;
            cellStyle21.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell21.Style = cellStyle21;
            this.textBoxCell21.TabIndex = 20;
            this.textBoxCell21.Value = "カートン入数";
            // 
            // textBoxCell22
            // 
            this.textBoxCell22.Location = new System.Drawing.Point(2283, 0);
            this.textBoxCell22.Name = "textBoxCell22";
            this.textBoxCell22.Size = new System.Drawing.Size(98, 21);
            cellStyle22.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle22.ForeColor = System.Drawing.Color.White;
            cellStyle22.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell22.Style = cellStyle22;
            this.textBoxCell22.TabIndex = 21;
            this.textBoxCell22.Value = "カートンサイズ";
            // 
            // textBoxCell23
            // 
            this.textBoxCell23.Location = new System.Drawing.Point(2381, 0);
            this.textBoxCell23.Name = "textBoxCell23";
            this.textBoxCell23.Size = new System.Drawing.Size(98, 21);
            cellStyle23.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle23.ForeColor = System.Drawing.Color.White;
            cellStyle23.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell23.Style = cellStyle23;
            this.textBoxCell23.TabIndex = 22;
            this.textBoxCell23.Value = "CBM";
            // 
            // textBoxCell24
            // 
            this.textBoxCell24.Location = new System.Drawing.Point(2479, 0);
            this.textBoxCell24.Name = "textBoxCell24";
            this.textBoxCell24.Size = new System.Drawing.Size(98, 21);
            cellStyle24.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle24.ForeColor = System.Drawing.Color.White;
            cellStyle24.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell24.Style = cellStyle24;
            this.textBoxCell24.TabIndex = 23;
            this.textBoxCell24.Value = "ETDB";
            // 
            // textBoxCell25
            // 
            this.textBoxCell25.Location = new System.Drawing.Point(2577, 0);
            this.textBoxCell25.Name = "textBoxCell25";
            this.textBoxCell25.Size = new System.Drawing.Size(98, 21);
            cellStyle25.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle25.ForeColor = System.Drawing.Color.White;
            cellStyle25.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell25.Style = cellStyle25;
            this.textBoxCell25.TabIndex = 24;
            this.textBoxCell25.Value = "ETAB";
            // 
            // textBoxCell26
            // 
            this.textBoxCell26.Location = new System.Drawing.Point(2675, 0);
            this.textBoxCell26.Name = "textBoxCell26";
            this.textBoxCell26.Size = new System.Drawing.Size(98, 21);
            cellStyle26.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle26.ForeColor = System.Drawing.Color.White;
            cellStyle26.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell26.Style = cellStyle26;
            this.textBoxCell26.TabIndex = 25;
            this.textBoxCell26.Value = "納品予定日";
            // 
            // textBoxCell27
            // 
            this.textBoxCell27.Location = new System.Drawing.Point(2773, 0);
            this.textBoxCell27.Name = "textBoxCell27";
            this.textBoxCell27.Size = new System.Drawing.Size(98, 21);
            cellStyle27.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle27.ForeColor = System.Drawing.Color.White;
            cellStyle27.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell27.Style = cellStyle27;
            this.textBoxCell27.TabIndex = 26;
            this.textBoxCell27.Value = "納品予定日";
            // 
            // textBoxCell28
            // 
            this.textBoxCell28.Location = new System.Drawing.Point(2871, 0);
            this.textBoxCell28.Name = "textBoxCell28";
            this.textBoxCell28.Size = new System.Drawing.Size(98, 21);
            cellStyle28.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle28.ForeColor = System.Drawing.Color.White;
            cellStyle28.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell28.Style = cellStyle28;
            this.textBoxCell28.TabIndex = 27;
            this.textBoxCell28.Value = "許可書要不要";
            // 
            // textBoxCell29
            // 
            this.textBoxCell29.Location = new System.Drawing.Point(2969, 0);
            this.textBoxCell29.Name = "textBoxCell29";
            this.textBoxCell29.Size = new System.Drawing.Size(98, 21);
            cellStyle29.BackColor = System.Drawing.Color.Brown;
            cellStyle29.ForeColor = System.Drawing.Color.White;
            cellStyle29.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell29.Style = cellStyle29;
            this.textBoxCell29.TabIndex = 28;
            this.textBoxCell29.Value = "SHIP①";
            // 
            // textBoxCell30
            // 
            this.textBoxCell30.Location = new System.Drawing.Point(3067, 0);
            this.textBoxCell30.Name = "textBoxCell30";
            this.textBoxCell30.Size = new System.Drawing.Size(98, 21);
            cellStyle30.BackColor = System.Drawing.Color.Brown;
            cellStyle30.ForeColor = System.Drawing.Color.White;
            cellStyle30.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell30.Style = cellStyle30;
            this.textBoxCell30.TabIndex = 29;
            this.textBoxCell30.Value = "SHIP②";
            // 
            // textBoxCell31
            // 
            this.textBoxCell31.Location = new System.Drawing.Point(3165, 0);
            this.textBoxCell31.Name = "textBoxCell31";
            this.textBoxCell31.Size = new System.Drawing.Size(98, 21);
            cellStyle31.BackColor = System.Drawing.Color.Brown;
            cellStyle31.ForeColor = System.Drawing.Color.White;
            cellStyle31.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell31.Style = cellStyle31;
            this.textBoxCell31.TabIndex = 30;
            this.textBoxCell31.Value = "SHIP③";
            // 
            // textBoxCell32
            // 
            this.textBoxCell32.Location = new System.Drawing.Point(3263, 0);
            this.textBoxCell32.Name = "textBoxCell32";
            this.textBoxCell32.Size = new System.Drawing.Size(98, 21);
            cellStyle32.BackColor = System.Drawing.Color.Peru;
            cellStyle32.ForeColor = System.Drawing.Color.White;
            cellStyle32.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell32.Style = cellStyle32;
            this.textBoxCell32.TabIndex = 31;
            this.textBoxCell32.Value = "増減";
            // 
            // textBoxCell33
            // 
            this.textBoxCell33.Location = new System.Drawing.Point(3361, 0);
            this.textBoxCell33.Name = "textBoxCell33";
            this.textBoxCell33.Size = new System.Drawing.Size(339, 21);
            cellStyle33.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle33.ForeColor = System.Drawing.Color.White;
            cellStyle33.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell33.Style = cellStyle33;
            this.textBoxCell33.TabIndex = 32;
            this.textBoxCell33.Value = "備考欄";
            // 
            // textBoxCell34
            // 
            this.textBoxCell34.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell34.Name = "textBoxCell34";
            this.textBoxCell34.Size = new System.Drawing.Size(60, 63);
            this.textBoxCell34.TabIndex = 0;
            // 
            // textBoxCell35
            // 
            this.textBoxCell35.Location = new System.Drawing.Point(60, 0);
            this.textBoxCell35.Name = "textBoxCell35";
            this.textBoxCell35.Size = new System.Drawing.Size(60, 63);
            this.textBoxCell35.TabIndex = 1;
            // 
            // textBoxCell36
            // 
            this.textBoxCell36.Location = new System.Drawing.Point(120, 0);
            this.textBoxCell36.Name = "textBoxCell36";
            this.textBoxCell36.Size = new System.Drawing.Size(60, 63);
            this.textBoxCell36.TabIndex = 2;
            // 
            // textBoxCell37
            // 
            this.textBoxCell37.Location = new System.Drawing.Point(180, 0);
            this.textBoxCell37.Name = "textBoxCell37";
            this.textBoxCell37.Size = new System.Drawing.Size(81, 63);
            this.textBoxCell37.TabIndex = 3;
            // 
            // textBoxCell38
            // 
            this.textBoxCell38.Location = new System.Drawing.Point(261, 0);
            this.textBoxCell38.Name = "textBoxCell38";
            this.textBoxCell38.Size = new System.Drawing.Size(81, 63);
            this.textBoxCell38.TabIndex = 4;
            // 
            // textBoxCell39
            // 
            this.textBoxCell39.Location = new System.Drawing.Point(342, 0);
            this.textBoxCell39.Name = "textBoxCell39";
            this.textBoxCell39.Size = new System.Drawing.Size(81, 63);
            this.textBoxCell39.TabIndex = 5;
            // 
            // textBoxCell40
            // 
            this.textBoxCell40.Location = new System.Drawing.Point(423, 0);
            this.textBoxCell40.Name = "textBoxCell40";
            this.textBoxCell40.Size = new System.Drawing.Size(81, 63);
            this.textBoxCell40.TabIndex = 6;
            // 
            // textBoxCell41
            // 
            this.textBoxCell41.Location = new System.Drawing.Point(504, 0);
            this.textBoxCell41.Name = "textBoxCell41";
            this.textBoxCell41.Size = new System.Drawing.Size(81, 63);
            this.textBoxCell41.TabIndex = 7;
            // 
            // textBoxCell42
            // 
            this.textBoxCell42.Location = new System.Drawing.Point(585, 0);
            this.textBoxCell42.Name = "textBoxCell42";
            this.textBoxCell42.Size = new System.Drawing.Size(81, 63);
            this.textBoxCell42.TabIndex = 8;
            // 
            // textBoxCell43
            // 
            this.textBoxCell43.Location = new System.Drawing.Point(666, 0);
            this.textBoxCell43.Name = "textBoxCell43";
            this.textBoxCell43.Size = new System.Drawing.Size(135, 63);
            this.textBoxCell43.TabIndex = 9;
            // 
            // textBoxCell44
            // 
            this.textBoxCell44.Location = new System.Drawing.Point(801, 0);
            this.textBoxCell44.Name = "textBoxCell44";
            this.textBoxCell44.Size = new System.Drawing.Size(300, 63);
            this.textBoxCell44.TabIndex = 10;
            // 
            // textBoxCell45
            // 
            this.textBoxCell45.Location = new System.Drawing.Point(1101, 0);
            this.textBoxCell45.Name = "textBoxCell45";
            this.textBoxCell45.Size = new System.Drawing.Size(300, 63);
            this.textBoxCell45.TabIndex = 11;
            // 
            // textBoxCell46
            // 
            this.textBoxCell46.Location = new System.Drawing.Point(1401, 0);
            this.textBoxCell46.Name = "textBoxCell46";
            this.textBoxCell46.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell46.TabIndex = 12;
            // 
            // textBoxCell47
            // 
            this.textBoxCell47.Location = new System.Drawing.Point(1499, 0);
            this.textBoxCell47.Name = "textBoxCell47";
            this.textBoxCell47.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell47.TabIndex = 13;
            // 
            // textBoxCell48
            // 
            this.textBoxCell48.Location = new System.Drawing.Point(1597, 0);
            this.textBoxCell48.Name = "textBoxCell48";
            this.textBoxCell48.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell48.TabIndex = 14;
            // 
            // textBoxCell49
            // 
            this.textBoxCell49.Location = new System.Drawing.Point(1695, 0);
            this.textBoxCell49.Name = "textBoxCell49";
            this.textBoxCell49.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell49.TabIndex = 15;
            // 
            // textBoxCell50
            // 
            this.textBoxCell50.Location = new System.Drawing.Point(1793, 0);
            this.textBoxCell50.Name = "textBoxCell50";
            this.textBoxCell50.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell50.TabIndex = 16;
            // 
            // textBoxCell51
            // 
            this.textBoxCell51.Location = new System.Drawing.Point(1891, 0);
            this.textBoxCell51.Name = "textBoxCell51";
            this.textBoxCell51.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell51.TabIndex = 17;
            // 
            // textBoxCell52
            // 
            this.textBoxCell52.Location = new System.Drawing.Point(1989, 0);
            this.textBoxCell52.Name = "textBoxCell52";
            this.textBoxCell52.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell52.TabIndex = 18;
            // 
            // textBoxCell53
            // 
            this.textBoxCell53.Location = new System.Drawing.Point(2087, 0);
            this.textBoxCell53.Name = "textBoxCell53";
            this.textBoxCell53.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell53.TabIndex = 19;
            // 
            // textBoxCell54
            // 
            this.textBoxCell54.Location = new System.Drawing.Point(2185, 0);
            this.textBoxCell54.Name = "textBoxCell54";
            this.textBoxCell54.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell54.TabIndex = 20;
            // 
            // textBoxCell55
            // 
            this.textBoxCell55.Location = new System.Drawing.Point(2283, 0);
            this.textBoxCell55.Name = "textBoxCell55";
            this.textBoxCell55.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell55.TabIndex = 21;
            // 
            // textBoxCell56
            // 
            this.textBoxCell56.Location = new System.Drawing.Point(2381, 0);
            this.textBoxCell56.Name = "textBoxCell56";
            this.textBoxCell56.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell56.TabIndex = 22;
            // 
            // textBoxCell57
            // 
            this.textBoxCell57.Location = new System.Drawing.Point(2479, 0);
            this.textBoxCell57.Name = "textBoxCell57";
            this.textBoxCell57.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell57.TabIndex = 23;
            // 
            // textBoxCell58
            // 
            this.textBoxCell58.Location = new System.Drawing.Point(2577, 0);
            this.textBoxCell58.Name = "textBoxCell58";
            this.textBoxCell58.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell58.TabIndex = 24;
            // 
            // textBoxCell59
            // 
            this.textBoxCell59.Location = new System.Drawing.Point(2675, 0);
            this.textBoxCell59.Name = "textBoxCell59";
            this.textBoxCell59.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell59.TabIndex = 25;
            // 
            // textBoxCell60
            // 
            this.textBoxCell60.Location = new System.Drawing.Point(2773, 0);
            this.textBoxCell60.Name = "textBoxCell60";
            this.textBoxCell60.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell60.TabIndex = 26;
            // 
            // textBoxCell61
            // 
            this.textBoxCell61.Location = new System.Drawing.Point(2871, 0);
            this.textBoxCell61.Name = "textBoxCell61";
            this.textBoxCell61.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell61.TabIndex = 27;
            // 
            // textBoxCell62
            // 
            this.textBoxCell62.Location = new System.Drawing.Point(2969, 0);
            this.textBoxCell62.Name = "textBoxCell62";
            this.textBoxCell62.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell62.TabIndex = 28;
            // 
            // textBoxCell63
            // 
            this.textBoxCell63.Location = new System.Drawing.Point(3067, 0);
            this.textBoxCell63.Name = "textBoxCell63";
            this.textBoxCell63.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell63.TabIndex = 29;
            // 
            // textBoxCell64
            // 
            this.textBoxCell64.Location = new System.Drawing.Point(3165, 0);
            this.textBoxCell64.Name = "textBoxCell64";
            this.textBoxCell64.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell64.TabIndex = 30;
            // 
            // textBoxCell65
            // 
            this.textBoxCell65.Location = new System.Drawing.Point(3263, 0);
            this.textBoxCell65.Name = "textBoxCell65";
            this.textBoxCell65.Size = new System.Drawing.Size(98, 63);
            this.textBoxCell65.TabIndex = 31;
            // 
            // textBoxCell66
            // 
            this.textBoxCell66.Location = new System.Drawing.Point(3361, 0);
            this.textBoxCell66.Name = "textBoxCell66";
            this.textBoxCell66.Size = new System.Drawing.Size(339, 63);
            this.textBoxCell66.TabIndex = 32;
            // 
            // TempSeisankanri
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 84;
            this.Width = 3700;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell34;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell35;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell36;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell37;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell38;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell39;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell40;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell41;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell42;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell43;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell44;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell45;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell46;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell47;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell48;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell49;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell50;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell51;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell52;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell53;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell54;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell55;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell56;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell57;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell58;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell59;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell60;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell61;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell62;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell63;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell64;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell65;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell66;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell2;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell3;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell4;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell5;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell6;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell7;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell8;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell9;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell10;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell11;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell12;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell13;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell14;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell15;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell16;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell17;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell18;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell19;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell20;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell21;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell22;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell23;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell24;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell25;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell26;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell27;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell28;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell29;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell30;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell31;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell32;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell33;
    }
}
