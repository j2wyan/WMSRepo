﻿namespace WMS_V1.UI
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempItakPri
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle7 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle8 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle9 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.textBoxCell1 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell2 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell3 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell4 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell5 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell6 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell7 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell8 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell9 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.checkBoxCell1 = new GrapeCity.Win.MultiRow.CheckBoxCell();
            this.textBoxCell10 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell11 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell12 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell13 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell14 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell15 = new GrapeCity.Win.MultiRow.TextBoxCell();
            // 
            // Row
            // 
            this.Row.Cells.Add(this.textBoxCell9);
            this.Row.Cells.Add(this.checkBoxCell1);
            this.Row.Cells.Add(this.textBoxCell10);
            this.Row.Cells.Add(this.textBoxCell11);
            this.Row.Cells.Add(this.textBoxCell12);
            this.Row.Cells.Add(this.textBoxCell13);
            this.Row.Cells.Add(this.textBoxCell14);
            this.Row.Cells.Add(this.textBoxCell15);
            this.Row.Height = 21;
            this.Row.Width = 801;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.textBoxCell1);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell2);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell3);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell4);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell5);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell6);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell7);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell8);
            this.columnHeaderSection1.Height = 21;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 801;
            // 
            // textBoxCell1
            // 
            this.textBoxCell1.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell1.Name = "textBoxCell1";
            this.textBoxCell1.Size = new System.Drawing.Size(38, 21);
            cellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle2.ForeColor = System.Drawing.Color.White;
            cellStyle2.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell1.Style = cellStyle2;
            this.textBoxCell1.TabIndex = 0;
            this.textBoxCell1.Value = "印刷";
            // 
            // textBoxCell2
            // 
            this.textBoxCell2.Location = new System.Drawing.Point(38, 0);
            this.textBoxCell2.Name = "textBoxCell2";
            this.textBoxCell2.Size = new System.Drawing.Size(82, 21);
            cellStyle3.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle3.ForeColor = System.Drawing.Color.White;
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell2.Style = cellStyle3;
            this.textBoxCell2.TabIndex = 1;
            this.textBoxCell2.Value = "日付";
            // 
            // textBoxCell3
            // 
            this.textBoxCell3.Location = new System.Drawing.Point(120, 0);
            this.textBoxCell3.Name = "textBoxCell3";
            this.textBoxCell3.Size = new System.Drawing.Size(101, 21);
            cellStyle4.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle4.ForeColor = System.Drawing.Color.White;
            cellStyle4.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell3.Style = cellStyle4;
            this.textBoxCell3.TabIndex = 2;
            this.textBoxCell3.Value = "伝票番号";
            // 
            // textBoxCell4
            // 
            this.textBoxCell4.Location = new System.Drawing.Point(221, 0);
            this.textBoxCell4.Name = "textBoxCell4";
            this.textBoxCell4.Size = new System.Drawing.Size(82, 21);
            cellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle5.ForeColor = System.Drawing.Color.White;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell4.Style = cellStyle5;
            this.textBoxCell4.TabIndex = 3;
            this.textBoxCell4.Value = "担当者";
            // 
            // textBoxCell5
            // 
            this.textBoxCell5.Location = new System.Drawing.Point(303, 0);
            this.textBoxCell5.Name = "textBoxCell5";
            this.textBoxCell5.Size = new System.Drawing.Size(101, 21);
            cellStyle6.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle6.ForeColor = System.Drawing.Color.White;
            cellStyle6.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell5.Style = cellStyle6;
            this.textBoxCell5.TabIndex = 4;
            this.textBoxCell5.Value = "委託先ｺｰﾄﾞ";
            // 
            // textBoxCell6
            // 
            this.textBoxCell6.Location = new System.Drawing.Point(404, 0);
            this.textBoxCell6.Name = "textBoxCell6";
            this.textBoxCell6.Size = new System.Drawing.Size(198, 21);
            cellStyle7.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle7.ForeColor = System.Drawing.Color.White;
            cellStyle7.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell6.Style = cellStyle7;
            this.textBoxCell6.TabIndex = 5;
            this.textBoxCell6.Value = "委託先名";
            // 
            // textBoxCell7
            // 
            this.textBoxCell7.Location = new System.Drawing.Point(602, 0);
            this.textBoxCell7.Name = "textBoxCell7";
            this.textBoxCell7.Size = new System.Drawing.Size(77, 21);
            cellStyle8.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle8.ForeColor = System.Drawing.Color.White;
            cellStyle8.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell7.Style = cellStyle8;
            this.textBoxCell7.TabIndex = 6;
            this.textBoxCell7.Value = "数量";
            // 
            // textBoxCell8
            // 
            this.textBoxCell8.Location = new System.Drawing.Point(679, 0);
            this.textBoxCell8.Name = "textBoxCell8";
            this.textBoxCell8.Size = new System.Drawing.Size(122, 21);
            cellStyle9.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle9.ForeColor = System.Drawing.Color.White;
            cellStyle9.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell8.Style = cellStyle9;
            this.textBoxCell8.TabIndex = 7;
            this.textBoxCell8.Value = "金額";
            // 
            // textBoxCell9
            // 
            this.textBoxCell9.Location = new System.Drawing.Point(38, 0);
            this.textBoxCell9.Name = "textBoxCell9";
            this.textBoxCell9.TabIndex = 0;
            // 
            // checkBoxCell1
            // 
            this.checkBoxCell1.Location = new System.Drawing.Point(0, 0);
            this.checkBoxCell1.Name = "checkBoxCell1";
            this.checkBoxCell1.Size = new System.Drawing.Size(38, 21);
            cellStyle1.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle1.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.checkBoxCell1.Style = cellStyle1;
            this.checkBoxCell1.TabIndex = 1;
            // 
            // textBoxCell10
            // 
            this.textBoxCell10.Location = new System.Drawing.Point(118, 0);
            this.textBoxCell10.Name = "textBoxCell10";
            this.textBoxCell10.Size = new System.Drawing.Size(103, 21);
            this.textBoxCell10.TabIndex = 2;
            // 
            // textBoxCell11
            // 
            this.textBoxCell11.Location = new System.Drawing.Point(221, 0);
            this.textBoxCell11.Name = "textBoxCell11";
            this.textBoxCell11.Size = new System.Drawing.Size(82, 21);
            this.textBoxCell11.TabIndex = 3;
            // 
            // textBoxCell12
            // 
            this.textBoxCell12.Location = new System.Drawing.Point(303, 0);
            this.textBoxCell12.Name = "textBoxCell12";
            this.textBoxCell12.Size = new System.Drawing.Size(101, 21);
            this.textBoxCell12.TabIndex = 4;
            // 
            // textBoxCell13
            // 
            this.textBoxCell13.Location = new System.Drawing.Point(404, 0);
            this.textBoxCell13.Name = "textBoxCell13";
            this.textBoxCell13.Size = new System.Drawing.Size(198, 21);
            this.textBoxCell13.TabIndex = 5;
            // 
            // textBoxCell14
            // 
            this.textBoxCell14.Location = new System.Drawing.Point(602, 0);
            this.textBoxCell14.Name = "textBoxCell14";
            this.textBoxCell14.Size = new System.Drawing.Size(77, 21);
            this.textBoxCell14.TabIndex = 6;
            // 
            // textBoxCell15
            // 
            this.textBoxCell15.Location = new System.Drawing.Point(679, 0);
            this.textBoxCell15.Name = "textBoxCell15";
            this.textBoxCell15.Size = new System.Drawing.Size(122, 21);
            this.textBoxCell15.TabIndex = 7;
            // 
            // TempItakPri
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 42;
            this.Width = 801;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell9;
        private GrapeCity.Win.MultiRow.CheckBoxCell checkBoxCell1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell10;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell11;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell12;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell13;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell14;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell15;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell2;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell3;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell4;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell5;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell6;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell7;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell8;
    }
}
