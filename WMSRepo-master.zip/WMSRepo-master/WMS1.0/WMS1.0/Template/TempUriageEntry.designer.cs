﻿namespace WMS_V1
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempUriageEntry
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle15 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border15 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle16 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border16 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle17 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border17 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle18 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border18 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle19 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border19 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle20 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border20 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle21 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border21 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle22 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border22 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle23 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border23 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle24 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border24 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle25 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border25 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle26 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border26 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle27 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border27 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border1 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border2 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border3 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border4 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border5 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border6 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle7 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border7 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle8 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border8 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle9 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border9 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle10 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border10 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle11 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border11 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle12 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border12 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle13 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border13 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle14 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border14 = new GrapeCity.Win.MultiRow.Border();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.headerCell1 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell2 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell3 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell4 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell5 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell6 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell7 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell8 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell9 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell10 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell11 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell12 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell13 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.rowHeaderCell1 = new GrapeCity.Win.MultiRow.RowHeaderCell();
            this.gcTextBoxCell1 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell2 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell3 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell4 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell5 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell6 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell7 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell8 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell9 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell10 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell11 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell12 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            this.gcTextBoxCell13 = new GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell(false);
            // 
            // Row
            // 
            this.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.Row.Cells.Add(this.rowHeaderCell1);
            this.Row.Cells.Add(this.gcTextBoxCell1);
            this.Row.Cells.Add(this.gcTextBoxCell2);
            this.Row.Cells.Add(this.gcTextBoxCell3);
            this.Row.Cells.Add(this.gcTextBoxCell4);
            this.Row.Cells.Add(this.gcTextBoxCell5);
            this.Row.Cells.Add(this.gcTextBoxCell6);
            this.Row.Cells.Add(this.gcTextBoxCell7);
            this.Row.Cells.Add(this.gcTextBoxCell8);
            this.Row.Cells.Add(this.gcTextBoxCell9);
            this.Row.Cells.Add(this.gcTextBoxCell10);
            this.Row.Cells.Add(this.gcTextBoxCell11);
            this.Row.Cells.Add(this.gcTextBoxCell12);
            this.Row.Cells.Add(this.gcTextBoxCell13);
            this.Row.Height = 37;
            this.Row.Width = 882;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.headerCell1);
            this.columnHeaderSection1.Cells.Add(this.headerCell2);
            this.columnHeaderSection1.Cells.Add(this.headerCell3);
            this.columnHeaderSection1.Cells.Add(this.headerCell4);
            this.columnHeaderSection1.Cells.Add(this.headerCell5);
            this.columnHeaderSection1.Cells.Add(this.headerCell6);
            this.columnHeaderSection1.Cells.Add(this.headerCell7);
            this.columnHeaderSection1.Cells.Add(this.headerCell8);
            this.columnHeaderSection1.Cells.Add(this.headerCell9);
            this.columnHeaderSection1.Cells.Add(this.headerCell10);
            this.columnHeaderSection1.Cells.Add(this.headerCell11);
            this.columnHeaderSection1.Cells.Add(this.headerCell12);
            this.columnHeaderSection1.Cells.Add(this.headerCell13);
            this.columnHeaderSection1.Height = 31;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 882;
            // 
            // headerCell1
            // 
            this.headerCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell1.Location = new System.Drawing.Point(1, 1);
            this.headerCell1.Name = "headerCell1";
            this.headerCell1.Size = new System.Drawing.Size(26, 30);
            cellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border15.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle15.Border = border15;
            cellStyle15.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle15.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle15.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell1.Style = cellStyle15;
            this.headerCell1.TabIndex = 0;
            this.headerCell1.Value = "No.";
            // 
            // headerCell2
            // 
            this.headerCell2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell2.Location = new System.Drawing.Point(27, 1);
            this.headerCell2.Name = "headerCell2";
            this.headerCell2.Size = new System.Drawing.Size(56, 30);
            cellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border16.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle16.Border = border16;
            cellStyle16.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle16.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle16.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell2.Style = cellStyle16;
            this.headerCell2.TabIndex = 1;
            this.headerCell2.Value = "内訳";
            // 
            // headerCell3
            // 
            this.headerCell3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell3.Location = new System.Drawing.Point(83, 1);
            this.headerCell3.Name = "headerCell3";
            this.headerCell3.Size = new System.Drawing.Size(150, 15);
            cellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border17.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle17.Border = border17;
            cellStyle17.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle17.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle17.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell3.Style = cellStyle17;
            this.headerCell3.TabIndex = 2;
            this.headerCell3.Value = "コード";
            // 
            // headerCell4
            // 
            this.headerCell4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell4.Location = new System.Drawing.Point(83, 16);
            this.headerCell4.Name = "headerCell4";
            this.headerCell4.Size = new System.Drawing.Size(350, 15);
            cellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border18.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle18.Border = border18;
            cellStyle18.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle18.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle18.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell4.Style = cellStyle18;
            this.headerCell4.TabIndex = 3;
            this.headerCell4.Value = "商品名/摘要";
            // 
            // headerCell5
            // 
            this.headerCell5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell5.Location = new System.Drawing.Point(433, 16);
            this.headerCell5.Name = "headerCell5";
            this.headerCell5.Size = new System.Drawing.Size(100, 15);
            cellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border19.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border19.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border19.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border19.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle19.Border = border19;
            cellStyle19.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle19.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle19.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell5.Style = cellStyle19;
            this.headerCell5.TabIndex = 4;
            this.headerCell5.Value = "数量";
            // 
            // headerCell6
            // 
            this.headerCell6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell6.Location = new System.Drawing.Point(433, 1);
            this.headerCell6.Name = "headerCell6";
            this.headerCell6.Size = new System.Drawing.Size(100, 15);
            cellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border20.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border20.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border20.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border20.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle20.Border = border20;
            cellStyle20.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle20.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle20.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell6.Style = cellStyle20;
            this.headerCell6.TabIndex = 5;
            this.headerCell6.Value = "在庫";
            // 
            // headerCell7
            // 
            this.headerCell7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell7.Location = new System.Drawing.Point(233, 1);
            this.headerCell7.Name = "headerCell7";
            this.headerCell7.Size = new System.Drawing.Size(48, 15);
            cellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border21.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border21.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border21.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border21.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle21.Border = border21;
            cellStyle21.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle21.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle21.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell7.Style = cellStyle21;
            this.headerCell7.TabIndex = 6;
            this.headerCell7.Value = "単位";
            // 
            // headerCell8
            // 
            this.headerCell8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell8.Location = new System.Drawing.Point(533, 16);
            this.headerCell8.Name = "headerCell8";
            this.headerCell8.Size = new System.Drawing.Size(100, 15);
            cellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border22.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border22.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border22.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border22.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle22.Border = border22;
            cellStyle22.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle22.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle22.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell8.Style = cellStyle22;
            this.headerCell8.TabIndex = 7;
            this.headerCell8.Value = "単価";
            // 
            // headerCell9
            // 
            this.headerCell9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell9.Location = new System.Drawing.Point(533, 1);
            this.headerCell9.Name = "headerCell9";
            this.headerCell9.Size = new System.Drawing.Size(100, 15);
            cellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border23.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border23.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border23.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border23.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle23.Border = border23;
            cellStyle23.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle23.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle23.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell9.Style = cellStyle23;
            this.headerCell9.TabIndex = 8;
            this.headerCell9.Value = "原単価";
            // 
            // headerCell10
            // 
            this.headerCell10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell10.Location = new System.Drawing.Point(633, 16);
            this.headerCell10.Name = "headerCell10";
            this.headerCell10.Size = new System.Drawing.Size(119, 15);
            cellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border24.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border24.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border24.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border24.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle24.Border = border24;
            cellStyle24.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle24.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle24.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell10.Style = cellStyle24;
            this.headerCell10.TabIndex = 9;
            this.headerCell10.Value = "金額";
            // 
            // headerCell11
            // 
            this.headerCell11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell11.Location = new System.Drawing.Point(633, 1);
            this.headerCell11.Name = "headerCell11";
            this.headerCell11.Size = new System.Drawing.Size(119, 15);
            cellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border25.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border25.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border25.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border25.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle25.Border = border25;
            cellStyle25.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle25.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle25.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell11.Style = cellStyle25;
            this.headerCell11.TabIndex = 10;
            this.headerCell11.Value = "粗利";
            // 
            // headerCell12
            // 
            this.headerCell12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell12.Location = new System.Drawing.Point(752, 16);
            this.headerCell12.Name = "headerCell12";
            this.headerCell12.Size = new System.Drawing.Size(130, 15);
            cellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border26.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border26.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border26.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border26.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle26.Border = border26;
            cellStyle26.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle26.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle26.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell12.Style = cellStyle26;
            this.headerCell12.TabIndex = 11;
            this.headerCell12.Value = "備考";
            // 
            // headerCell13
            // 
            this.headerCell13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell13.Location = new System.Drawing.Point(752, 1);
            this.headerCell13.Name = "headerCell13";
            this.headerCell13.Size = new System.Drawing.Size(130, 15);
            cellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            border27.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border27.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border27.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border27.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle27.Border = border27;
            cellStyle27.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle27.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle27.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell13.Style = cellStyle27;
            this.headerCell13.TabIndex = 12;
            this.headerCell13.Value = "課税区分";
            // 
            // rowHeaderCell1
            // 
            this.rowHeaderCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rowHeaderCell1.Location = new System.Drawing.Point(1, 1);
            this.rowHeaderCell1.Name = "rowHeaderCell1";
            this.rowHeaderCell1.Size = new System.Drawing.Size(26, 36);
            border1.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle1.Border = border1;
            this.rowHeaderCell1.Style = cellStyle1;
            this.rowHeaderCell1.TabIndex = 0;
            // 
            // gcTextBoxCell1
            // 
            this.gcTextBoxCell1.Location = new System.Drawing.Point(27, 1);
            this.gcTextBoxCell1.Name = "gcTextBoxCell1";
            this.gcTextBoxCell1.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell1.Size = new System.Drawing.Size(56, 18);
            border2.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle2.Border = border2;
            cellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gcTextBoxCell1.Style = cellStyle2;
            this.gcTextBoxCell1.TabIndex = 1;
            // 
            // gcTextBoxCell2
            // 
            this.gcTextBoxCell2.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell2.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell2.Location = new System.Drawing.Point(27, 19);
            this.gcTextBoxCell2.Name = "gcTextBoxCell2";
            this.gcTextBoxCell2.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell2.Size = new System.Drawing.Size(56, 18);
            border3.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle3.Border = border3;
            cellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomLeft;
            this.gcTextBoxCell2.Style = cellStyle3;
            this.gcTextBoxCell2.TabIndex = 2;
            // 
            // gcTextBoxCell3
            // 
            this.gcTextBoxCell3.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell3.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell3.HighlightText = true;
            this.gcTextBoxCell3.Location = new System.Drawing.Point(83, 1);
            this.gcTextBoxCell3.Name = "gcTextBoxCell3";
            this.gcTextBoxCell3.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell3.Size = new System.Drawing.Size(150, 18);
            border4.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle4.Border = border4;
            cellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.gcTextBoxCell3.Style = cellStyle4;
            this.gcTextBoxCell3.TabIndex = 3;
            // 
            // gcTextBoxCell4
            // 
            this.gcTextBoxCell4.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell4.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell4.HighlightText = true;
            this.gcTextBoxCell4.Location = new System.Drawing.Point(83, 19);
            this.gcTextBoxCell4.Name = "gcTextBoxCell4";
            this.gcTextBoxCell4.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell4.Size = new System.Drawing.Size(350, 18);
            border5.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle5.Border = border5;
            cellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomLeft;
            this.gcTextBoxCell4.Style = cellStyle5;
            this.gcTextBoxCell4.TabIndex = 4;
            // 
            // gcTextBoxCell5
            // 
            this.gcTextBoxCell5.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell5.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell5.HighlightText = true;
            this.gcTextBoxCell5.Location = new System.Drawing.Point(433, 1);
            this.gcTextBoxCell5.Name = "gcTextBoxCell5";
            this.gcTextBoxCell5.ReadOnly = true;
            this.gcTextBoxCell5.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell5.Size = new System.Drawing.Size(100, 18);
            border6.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle6.Border = border6;
            cellStyle6.ForeColor = System.Drawing.Color.Navy;
            cellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            this.gcTextBoxCell5.Style = cellStyle6;
            this.gcTextBoxCell5.TabIndex = 5;
            // 
            // gcTextBoxCell6
            // 
            this.gcTextBoxCell6.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell6.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell6.HighlightText = true;
            this.gcTextBoxCell6.Location = new System.Drawing.Point(533, 1);
            this.gcTextBoxCell6.Name = "gcTextBoxCell6";
            this.gcTextBoxCell6.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell6.Size = new System.Drawing.Size(100, 18);
            border7.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle7.Border = border7;
            cellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle7.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.gcTextBoxCell6.Style = cellStyle7;
            this.gcTextBoxCell6.TabIndex = 6;
            // 
            // gcTextBoxCell7
            // 
            this.gcTextBoxCell7.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell7.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell7.HighlightText = true;
            this.gcTextBoxCell7.Location = new System.Drawing.Point(633, 1);
            this.gcTextBoxCell7.Name = "gcTextBoxCell7";
            this.gcTextBoxCell7.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell7.Size = new System.Drawing.Size(119, 18);
            border8.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle8.Border = border8;
            cellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            cellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle8.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.gcTextBoxCell7.Style = cellStyle8;
            this.gcTextBoxCell7.TabIndex = 7;
            // 
            // gcTextBoxCell8
            // 
            this.gcTextBoxCell8.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell8.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell8.HighlightText = true;
            this.gcTextBoxCell8.Location = new System.Drawing.Point(752, 1);
            this.gcTextBoxCell8.Name = "gcTextBoxCell8";
            this.gcTextBoxCell8.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell8.Size = new System.Drawing.Size(130, 18);
            border9.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle9.Border = border9;
            cellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            this.gcTextBoxCell8.Style = cellStyle9;
            this.gcTextBoxCell8.TabIndex = 8;
            // 
            // gcTextBoxCell9
            // 
            this.gcTextBoxCell9.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell9.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell9.HighlightText = true;
            this.gcTextBoxCell9.Location = new System.Drawing.Point(433, 19);
            this.gcTextBoxCell9.Name = "gcTextBoxCell9";
            this.gcTextBoxCell9.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell9.Size = new System.Drawing.Size(100, 18);
            border10.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle10.Border = border10;
            cellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle10.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.gcTextBoxCell9.Style = cellStyle10;
            this.gcTextBoxCell9.TabIndex = 9;
            // 
            // gcTextBoxCell10
            // 
            this.gcTextBoxCell10.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell10.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell10.HighlightText = true;
            this.gcTextBoxCell10.Location = new System.Drawing.Point(533, 19);
            this.gcTextBoxCell10.Name = "gcTextBoxCell10";
            this.gcTextBoxCell10.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell10.Size = new System.Drawing.Size(100, 18);
            border11.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle11.Border = border11;
            cellStyle11.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle11.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.gcTextBoxCell10.Style = cellStyle11;
            this.gcTextBoxCell10.TabIndex = 10;
            // 
            // gcTextBoxCell11
            // 
            this.gcTextBoxCell11.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell11.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell11.HighlightText = true;
            this.gcTextBoxCell11.Location = new System.Drawing.Point(633, 19);
            this.gcTextBoxCell11.Name = "gcTextBoxCell11";
            this.gcTextBoxCell11.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell11.Size = new System.Drawing.Size(119, 18);
            border12.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle12.Border = border12;
            cellStyle12.Font = new System.Drawing.Font("MS UI Gothic", 9F);
            cellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle12.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomRight;
            this.gcTextBoxCell11.Style = cellStyle12;
            this.gcTextBoxCell11.TabIndex = 11;
            // 
            // gcTextBoxCell12
            // 
            this.gcTextBoxCell12.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell12.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell12.HighlightText = true;
            this.gcTextBoxCell12.Location = new System.Drawing.Point(752, 19);
            this.gcTextBoxCell12.Name = "gcTextBoxCell12";
            this.gcTextBoxCell12.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell12.Size = new System.Drawing.Size(130, 18);
            border13.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle13.Border = border13;
            cellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            cellStyle13.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.BottomLeft;
            this.gcTextBoxCell12.Style = cellStyle13;
            this.gcTextBoxCell12.TabIndex = 12;
            // 
            // gcTextBoxCell13
            // 
            this.gcTextBoxCell13.AutoComplete.CandidateListItemFont = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell13.AutoComplete.HighlightStyle.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcTextBoxCell13.HighlightText = true;
            this.gcTextBoxCell13.Location = new System.Drawing.Point(233, 1);
            this.gcTextBoxCell13.Name = "gcTextBoxCell13";
            this.gcTextBoxCell13.ShortcutKeys.AddRange(new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry[] {
            new GrapeCity.Win.MultiRow.InputMan.ShortcutDictionaryEntry(System.Windows.Forms.Keys.F2, "ShortcutClear")});
            this.gcTextBoxCell13.Size = new System.Drawing.Size(48, 18);
            border14.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle14.Border = border14;
            cellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            cellStyle14.SelectionForeColor = System.Drawing.Color.Black;
            this.gcTextBoxCell13.Style = cellStyle14;
            this.gcTextBoxCell13.TabIndex = 13;
            // 
            // TempUriageEntry
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 68;
            this.Width = 882;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell2;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell3;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell4;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell5;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell6;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell7;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell8;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell9;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell10;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell11;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell12;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell13;
        private GrapeCity.Win.MultiRow.RowHeaderCell rowHeaderCell1;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell1;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell2;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell3;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell4;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell5;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell6;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell7;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell8;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell9;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell10;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell11;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell12;
        private GrapeCity.Win.MultiRow.InputMan.GcTextBoxCell gcTextBoxCell13;
    }
}
