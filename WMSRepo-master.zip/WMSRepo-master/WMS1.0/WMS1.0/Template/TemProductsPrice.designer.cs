﻿namespace WMS_V1
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TemProductsPrice
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border1 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border2 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border3 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border4 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border5 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border6 = new GrapeCity.Win.MultiRow.Border();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.headerCell1 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell2 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell3 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell4 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell5 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell6 = new GrapeCity.Win.MultiRow.HeaderCell();
            // 
            // Row
            // 
            this.Row.Height = 20;
            this.Row.Width = 789;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.headerCell1);
            this.columnHeaderSection1.Cells.Add(this.headerCell2);
            this.columnHeaderSection1.Cells.Add(this.headerCell3);
            this.columnHeaderSection1.Cells.Add(this.headerCell4);
            this.columnHeaderSection1.Cells.Add(this.headerCell5);
            this.columnHeaderSection1.Cells.Add(this.headerCell6);
            this.columnHeaderSection1.Height = 30;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 789;
            // 
            // headerCell1
            // 
            this.headerCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell1.Location = new System.Drawing.Point(0, 0);
            this.headerCell1.Name = "headerCell1";
            this.headerCell1.Size = new System.Drawing.Size(100, 30);
            cellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border1.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle1.Border = border1;
            cellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle1.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle1.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell1.Style = cellStyle1;
            this.headerCell1.TabIndex = 0;
            this.headerCell1.Value = "商品コード";
            // 
            // headerCell2
            // 
            this.headerCell2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell2.Location = new System.Drawing.Point(100, 0);
            this.headerCell2.Name = "headerCell2";
            this.headerCell2.Size = new System.Drawing.Size(380, 30);
            cellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border2.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle2.Border = border2;
            cellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle2.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle2.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell2.Style = cellStyle2;
            this.headerCell2.TabIndex = 1;
            this.headerCell2.Value = "商品名";
            // 
            // headerCell3
            // 
            this.headerCell3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell3.Location = new System.Drawing.Point(480, 0);
            this.headerCell3.Name = "headerCell3";
            this.headerCell3.Size = new System.Drawing.Size(309, 15);
            cellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border3.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle3.Border = border3;
            cellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle3.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell3.Style = cellStyle3;
            this.headerCell3.TabIndex = 2;
            this.headerCell3.Value = "単価（税抜）";
            // 
            // headerCell4
            // 
            this.headerCell4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell4.Location = new System.Drawing.Point(480, 15);
            this.headerCell4.Name = "headerCell4";
            this.headerCell4.Size = new System.Drawing.Size(100, 15);
            cellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border4.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle4.Border = border4;
            cellStyle4.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle4.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle4.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell4.Style = cellStyle4;
            this.headerCell4.TabIndex = 3;
            this.headerCell4.Value = "上代";
            // 
            // headerCell5
            // 
            this.headerCell5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell5.Location = new System.Drawing.Point(580, 15);
            this.headerCell5.Name = "headerCell5";
            this.headerCell5.Size = new System.Drawing.Size(100, 15);
            cellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border5.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle5.Border = border5;
            cellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle5.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell5.Style = cellStyle5;
            this.headerCell5.TabIndex = 4;
            this.headerCell5.Value = "販売価格";
            // 
            // headerCell6
            // 
            this.headerCell6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell6.Location = new System.Drawing.Point(680, 15);
            this.headerCell6.Name = "headerCell6";
            this.headerCell6.Size = new System.Drawing.Size(109, 15);
            cellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border6.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle6.Border = border6;
            cellStyle6.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle6.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle6.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell6.Style = cellStyle6;
            this.headerCell6.TabIndex = 5;
            this.headerCell6.Value = "単価";
            // 
            // TemProductsPrice
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 50;
            this.Width = 789;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell2;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell3;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell4;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell5;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell6;
    }
}
