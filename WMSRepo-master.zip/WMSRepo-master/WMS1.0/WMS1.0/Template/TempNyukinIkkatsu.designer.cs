﻿namespace WMS_V1.UI
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempNyukinIkkatsu
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle15 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle16 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle17 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle18 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle19 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle12 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle13 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle20 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle14 = new GrapeCity.Win.MultiRow.CellStyle();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.textBoxCell1 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell2 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell3 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell4 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell5 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell6 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell7 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell8 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell9 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell10 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell11 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell12 = new GrapeCity.Win.MultiRow.TextBoxCell();
            // 
            // Row
            // 
            this.Row.Cells.Add(this.textBoxCell6);
            this.Row.Cells.Add(this.textBoxCell7);
            this.Row.Cells.Add(this.textBoxCell8);
            this.Row.Cells.Add(this.textBoxCell9);
            this.Row.Cells.Add(this.textBoxCell10);
            this.Row.Cells.Add(this.textBoxCell12);
            this.Row.Height = 21;
            this.Row.Width = 711;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.textBoxCell1);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell2);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell3);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell4);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell5);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell11);
            this.columnHeaderSection1.Height = 21;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 711;
            // 
            // textBoxCell1
            // 
            this.textBoxCell1.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell1.Name = "textBoxCell1";
            this.textBoxCell1.Size = new System.Drawing.Size(60, 21);
            cellStyle15.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle15.ForeColor = System.Drawing.Color.White;
            cellStyle15.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell1.Style = cellStyle15;
            this.textBoxCell1.TabIndex = 0;
            this.textBoxCell1.Value = "コード";
            // 
            // textBoxCell2
            // 
            this.textBoxCell2.Location = new System.Drawing.Point(60, 0);
            this.textBoxCell2.Name = "textBoxCell2";
            this.textBoxCell2.Size = new System.Drawing.Size(239, 21);
            cellStyle16.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle16.ForeColor = System.Drawing.Color.White;
            cellStyle16.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell2.Style = cellStyle16;
            this.textBoxCell2.TabIndex = 1;
            this.textBoxCell2.Value = "得意先名称";
            // 
            // textBoxCell3
            // 
            this.textBoxCell3.Location = new System.Drawing.Point(299, 0);
            this.textBoxCell3.Name = "textBoxCell3";
            this.textBoxCell3.Size = new System.Drawing.Size(103, 21);
            cellStyle17.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle17.ForeColor = System.Drawing.Color.White;
            cellStyle17.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell3.Style = cellStyle17;
            this.textBoxCell3.TabIndex = 2;
            this.textBoxCell3.Value = "入金日";
            // 
            // textBoxCell4
            // 
            this.textBoxCell4.Location = new System.Drawing.Point(402, 0);
            this.textBoxCell4.Name = "textBoxCell4";
            this.textBoxCell4.Size = new System.Drawing.Size(103, 21);
            cellStyle18.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle18.ForeColor = System.Drawing.Color.White;
            cellStyle18.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell4.Style = cellStyle18;
            this.textBoxCell4.TabIndex = 3;
            this.textBoxCell4.Value = "入金額";
            // 
            // textBoxCell5
            // 
            this.textBoxCell5.Location = new System.Drawing.Point(505, 0);
            this.textBoxCell5.Name = "textBoxCell5";
            this.textBoxCell5.Size = new System.Drawing.Size(103, 21);
            cellStyle19.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle19.ForeColor = System.Drawing.Color.White;
            cellStyle19.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell5.Style = cellStyle19;
            this.textBoxCell5.TabIndex = 4;
            this.textBoxCell5.Value = "振込料";
            // 
            // textBoxCell6
            // 
            this.textBoxCell6.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell6.Name = "textBoxCell6";
            this.textBoxCell6.Size = new System.Drawing.Size(60, 21);
            this.textBoxCell6.TabIndex = 0;
            // 
            // textBoxCell7
            // 
            this.textBoxCell7.Location = new System.Drawing.Point(60, 0);
            this.textBoxCell7.Name = "textBoxCell7";
            this.textBoxCell7.Size = new System.Drawing.Size(239, 21);
            this.textBoxCell7.TabIndex = 1;
            // 
            // textBoxCell8
            // 
            this.textBoxCell8.Location = new System.Drawing.Point(299, 0);
            this.textBoxCell8.Name = "textBoxCell8";
            this.textBoxCell8.Size = new System.Drawing.Size(103, 21);
            this.textBoxCell8.TabIndex = 2;
            // 
            // textBoxCell9
            // 
            this.textBoxCell9.Location = new System.Drawing.Point(402, 0);
            this.textBoxCell9.Name = "textBoxCell9";
            this.textBoxCell9.Size = new System.Drawing.Size(103, 21);
            cellStyle12.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleRight;
            this.textBoxCell9.Style = cellStyle12;
            this.textBoxCell9.TabIndex = 3;
            // 
            // textBoxCell10
            // 
            this.textBoxCell10.Location = new System.Drawing.Point(505, 0);
            this.textBoxCell10.Name = "textBoxCell10";
            this.textBoxCell10.Size = new System.Drawing.Size(103, 21);
            cellStyle13.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleRight;
            this.textBoxCell10.Style = cellStyle13;
            this.textBoxCell10.TabIndex = 4;
            // 
            // textBoxCell11
            // 
            this.textBoxCell11.Location = new System.Drawing.Point(608, 0);
            this.textBoxCell11.Name = "textBoxCell11";
            this.textBoxCell11.Size = new System.Drawing.Size(103, 21);
            cellStyle20.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle20.ForeColor = System.Drawing.Color.White;
            cellStyle20.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell11.Style = cellStyle20;
            this.textBoxCell11.TabIndex = 5;
            this.textBoxCell11.Value = "合計金額";
            // 
            // textBoxCell12
            // 
            this.textBoxCell12.Location = new System.Drawing.Point(608, 0);
            this.textBoxCell12.Name = "textBoxCell12";
            this.textBoxCell12.Size = new System.Drawing.Size(103, 21);
            cellStyle14.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleRight;
            this.textBoxCell12.Style = cellStyle14;
            this.textBoxCell12.TabIndex = 5;
            // 
            // TempNyukinIkkatsu
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 42;
            this.Width = 711;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell6;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell7;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell8;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell9;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell10;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell2;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell3;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell4;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell5;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell12;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell11;
    }
}
