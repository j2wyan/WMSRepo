﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using GrapeCity.Win.MultiRow;

namespace WMS_V1.UI
{
    public sealed partial class TempSeisankanri : Template
    {
        public TempSeisankanri()
        {
            InitializeComponent();
        }
    }
}
