﻿namespace WMS_V1.UI
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class TempZaikosuii
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle46 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle47 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle48 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle49 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle50 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle51 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle52 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle53 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle54 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle55 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle56 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle57 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle58 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle59 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.CellStyle cellStyle60 = new GrapeCity.Win.MultiRow.CellStyle();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.textBoxCell1 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell2 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell3 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell4 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell5 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell6 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell7 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell8 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell9 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell10 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell11 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell12 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell13 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell14 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell15 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell16 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell17 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell18 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell19 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell20 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell21 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell22 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell23 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell24 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell25 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell26 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell27 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell28 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell29 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.textBoxCell30 = new GrapeCity.Win.MultiRow.TextBoxCell();
            // 
            // Row
            // 
            this.Row.Cells.Add(this.textBoxCell16);
            this.Row.Cells.Add(this.textBoxCell17);
            this.Row.Cells.Add(this.textBoxCell18);
            this.Row.Cells.Add(this.textBoxCell19);
            this.Row.Cells.Add(this.textBoxCell20);
            this.Row.Cells.Add(this.textBoxCell21);
            this.Row.Cells.Add(this.textBoxCell22);
            this.Row.Cells.Add(this.textBoxCell23);
            this.Row.Cells.Add(this.textBoxCell24);
            this.Row.Cells.Add(this.textBoxCell25);
            this.Row.Cells.Add(this.textBoxCell26);
            this.Row.Cells.Add(this.textBoxCell27);
            this.Row.Cells.Add(this.textBoxCell28);
            this.Row.Cells.Add(this.textBoxCell29);
            this.Row.Cells.Add(this.textBoxCell30);
            this.Row.Height = 21;
            this.Row.Width = 1501;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.textBoxCell1);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell2);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell3);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell4);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell5);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell6);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell7);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell8);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell9);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell10);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell11);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell12);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell13);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell14);
            this.columnHeaderSection1.Cells.Add(this.textBoxCell15);
            this.columnHeaderSection1.Height = 21;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 1501;
            // 
            // textBoxCell1
            // 
            this.textBoxCell1.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell1.Name = "textBoxCell1";
            this.textBoxCell1.Size = new System.Drawing.Size(302, 21);
            cellStyle46.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle46.ForeColor = System.Drawing.Color.White;
            cellStyle46.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell1.Style = cellStyle46;
            this.textBoxCell1.TabIndex = 0;
            this.textBoxCell1.Value = "商品";
            // 
            // textBoxCell2
            // 
            this.textBoxCell2.Location = new System.Drawing.Point(303, 0);
            this.textBoxCell2.Name = "textBoxCell2";
            this.textBoxCell2.Size = new System.Drawing.Size(158, 21);
            cellStyle47.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle47.ForeColor = System.Drawing.Color.White;
            cellStyle47.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell2.Style = cellStyle47;
            this.textBoxCell2.TabIndex = 1;
            this.textBoxCell2.Value = "JAN";
            // 
            // textBoxCell3
            // 
            this.textBoxCell3.Location = new System.Drawing.Point(462, 0);
            this.textBoxCell3.Name = "textBoxCell3";
            this.textBoxCell3.Size = new System.Drawing.Size(79, 21);
            cellStyle48.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle48.ForeColor = System.Drawing.Color.White;
            cellStyle48.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell3.Style = cellStyle48;
            this.textBoxCell3.TabIndex = 2;
            this.textBoxCell3.Value = "7月";
            // 
            // textBoxCell4
            // 
            this.textBoxCell4.Location = new System.Drawing.Point(542, 0);
            this.textBoxCell4.Name = "textBoxCell4";
            this.textBoxCell4.Size = new System.Drawing.Size(79, 21);
            cellStyle49.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle49.ForeColor = System.Drawing.Color.White;
            cellStyle49.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell4.Style = cellStyle49;
            this.textBoxCell4.TabIndex = 3;
            this.textBoxCell4.Value = "8月";
            // 
            // textBoxCell5
            // 
            this.textBoxCell5.Location = new System.Drawing.Point(622, 0);
            this.textBoxCell5.Name = "textBoxCell5";
            this.textBoxCell5.Size = new System.Drawing.Size(79, 21);
            cellStyle50.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle50.ForeColor = System.Drawing.Color.White;
            cellStyle50.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell5.Style = cellStyle50;
            this.textBoxCell5.TabIndex = 4;
            this.textBoxCell5.Value = "9月";
            // 
            // textBoxCell6
            // 
            this.textBoxCell6.Location = new System.Drawing.Point(702, 0);
            this.textBoxCell6.Name = "textBoxCell6";
            this.textBoxCell6.Size = new System.Drawing.Size(79, 21);
            cellStyle51.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle51.ForeColor = System.Drawing.Color.White;
            cellStyle51.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell6.Style = cellStyle51;
            this.textBoxCell6.TabIndex = 5;
            this.textBoxCell6.Value = "10月";
            // 
            // textBoxCell7
            // 
            this.textBoxCell7.Location = new System.Drawing.Point(782, 0);
            this.textBoxCell7.Name = "textBoxCell7";
            this.textBoxCell7.Size = new System.Drawing.Size(79, 21);
            cellStyle52.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle52.ForeColor = System.Drawing.Color.White;
            cellStyle52.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell7.Style = cellStyle52;
            this.textBoxCell7.TabIndex = 6;
            this.textBoxCell7.Value = "11月";
            // 
            // textBoxCell8
            // 
            this.textBoxCell8.Location = new System.Drawing.Point(862, 0);
            this.textBoxCell8.Name = "textBoxCell8";
            this.textBoxCell8.Size = new System.Drawing.Size(79, 21);
            cellStyle53.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle53.ForeColor = System.Drawing.Color.White;
            cellStyle53.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell8.Style = cellStyle53;
            this.textBoxCell8.TabIndex = 7;
            this.textBoxCell8.Value = "12月";
            // 
            // textBoxCell9
            // 
            this.textBoxCell9.Location = new System.Drawing.Point(942, 0);
            this.textBoxCell9.Name = "textBoxCell9";
            this.textBoxCell9.Size = new System.Drawing.Size(79, 21);
            cellStyle54.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle54.ForeColor = System.Drawing.Color.White;
            cellStyle54.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell9.Style = cellStyle54;
            this.textBoxCell9.TabIndex = 8;
            this.textBoxCell9.Value = "1月";
            // 
            // textBoxCell10
            // 
            this.textBoxCell10.Location = new System.Drawing.Point(1022, 0);
            this.textBoxCell10.Name = "textBoxCell10";
            this.textBoxCell10.Size = new System.Drawing.Size(79, 21);
            cellStyle55.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle55.ForeColor = System.Drawing.Color.White;
            cellStyle55.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell10.Style = cellStyle55;
            this.textBoxCell10.TabIndex = 9;
            this.textBoxCell10.Value = "2月";
            // 
            // textBoxCell11
            // 
            this.textBoxCell11.Location = new System.Drawing.Point(1102, 0);
            this.textBoxCell11.Name = "textBoxCell11";
            this.textBoxCell11.Size = new System.Drawing.Size(79, 21);
            cellStyle56.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle56.ForeColor = System.Drawing.Color.White;
            cellStyle56.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell11.Style = cellStyle56;
            this.textBoxCell11.TabIndex = 10;
            this.textBoxCell11.Value = "3月";
            // 
            // textBoxCell12
            // 
            this.textBoxCell12.Location = new System.Drawing.Point(1182, 0);
            this.textBoxCell12.Name = "textBoxCell12";
            this.textBoxCell12.Size = new System.Drawing.Size(79, 21);
            cellStyle57.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle57.ForeColor = System.Drawing.Color.White;
            cellStyle57.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell12.Style = cellStyle57;
            this.textBoxCell12.TabIndex = 11;
            this.textBoxCell12.Value = "4月";
            // 
            // textBoxCell13
            // 
            this.textBoxCell13.Location = new System.Drawing.Point(1262, 0);
            this.textBoxCell13.Name = "textBoxCell13";
            this.textBoxCell13.Size = new System.Drawing.Size(79, 21);
            cellStyle58.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle58.ForeColor = System.Drawing.Color.White;
            cellStyle58.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell13.Style = cellStyle58;
            this.textBoxCell13.TabIndex = 12;
            this.textBoxCell13.Value = "5月";
            // 
            // textBoxCell14
            // 
            this.textBoxCell14.Location = new System.Drawing.Point(1342, 0);
            this.textBoxCell14.Name = "textBoxCell14";
            this.textBoxCell14.Size = new System.Drawing.Size(79, 21);
            cellStyle59.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle59.ForeColor = System.Drawing.Color.White;
            cellStyle59.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell14.Style = cellStyle59;
            this.textBoxCell14.TabIndex = 13;
            this.textBoxCell14.Value = "6月";
            // 
            // textBoxCell15
            // 
            this.textBoxCell15.Location = new System.Drawing.Point(1422, 0);
            this.textBoxCell15.Name = "textBoxCell15";
            this.textBoxCell15.Size = new System.Drawing.Size(79, 21);
            cellStyle60.BackColor = System.Drawing.Color.SteelBlue;
            cellStyle60.ForeColor = System.Drawing.Color.White;
            cellStyle60.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.textBoxCell15.Style = cellStyle60;
            this.textBoxCell15.TabIndex = 14;
            this.textBoxCell15.Value = "合計";
            // 
            // textBoxCell16
            // 
            this.textBoxCell16.Location = new System.Drawing.Point(0, 0);
            this.textBoxCell16.Name = "textBoxCell16";
            this.textBoxCell16.Size = new System.Drawing.Size(302, 21);
            this.textBoxCell16.TabIndex = 0;
            // 
            // textBoxCell17
            // 
            this.textBoxCell17.Location = new System.Drawing.Point(302, 0);
            this.textBoxCell17.Name = "textBoxCell17";
            this.textBoxCell17.Size = new System.Drawing.Size(159, 21);
            this.textBoxCell17.TabIndex = 1;
            // 
            // textBoxCell18
            // 
            this.textBoxCell18.Location = new System.Drawing.Point(461, 0);
            this.textBoxCell18.Name = "textBoxCell18";
            this.textBoxCell18.TabIndex = 2;
            // 
            // textBoxCell19
            // 
            this.textBoxCell19.Location = new System.Drawing.Point(541, 0);
            this.textBoxCell19.Name = "textBoxCell19";
            this.textBoxCell19.TabIndex = 3;
            // 
            // textBoxCell20
            // 
            this.textBoxCell20.Location = new System.Drawing.Point(622, 0);
            this.textBoxCell20.Name = "textBoxCell20";
            this.textBoxCell20.TabIndex = 4;
            // 
            // textBoxCell21
            // 
            this.textBoxCell21.Location = new System.Drawing.Point(701, 0);
            this.textBoxCell21.Name = "textBoxCell21";
            this.textBoxCell21.TabIndex = 5;
            // 
            // textBoxCell22
            // 
            this.textBoxCell22.Location = new System.Drawing.Point(861, 0);
            this.textBoxCell22.Name = "textBoxCell22";
            this.textBoxCell22.TabIndex = 6;
            // 
            // textBoxCell23
            // 
            this.textBoxCell23.Location = new System.Drawing.Point(942, 0);
            this.textBoxCell23.Name = "textBoxCell23";
            this.textBoxCell23.TabIndex = 7;
            // 
            // textBoxCell24
            // 
            this.textBoxCell24.Location = new System.Drawing.Point(1021, 0);
            this.textBoxCell24.Name = "textBoxCell24";
            this.textBoxCell24.TabIndex = 8;
            // 
            // textBoxCell25
            // 
            this.textBoxCell25.Location = new System.Drawing.Point(1101, 0);
            this.textBoxCell25.Name = "textBoxCell25";
            this.textBoxCell25.TabIndex = 9;
            // 
            // textBoxCell26
            // 
            this.textBoxCell26.Location = new System.Drawing.Point(1182, 0);
            this.textBoxCell26.Name = "textBoxCell26";
            this.textBoxCell26.TabIndex = 10;
            // 
            // textBoxCell27
            // 
            this.textBoxCell27.Location = new System.Drawing.Point(1262, 0);
            this.textBoxCell27.Name = "textBoxCell27";
            this.textBoxCell27.TabIndex = 11;
            // 
            // textBoxCell28
            // 
            this.textBoxCell28.Location = new System.Drawing.Point(1341, 0);
            this.textBoxCell28.Name = "textBoxCell28";
            this.textBoxCell28.TabIndex = 12;
            // 
            // textBoxCell29
            // 
            this.textBoxCell29.Location = new System.Drawing.Point(1421, 0);
            this.textBoxCell29.Name = "textBoxCell29";
            this.textBoxCell29.TabIndex = 13;
            // 
            // textBoxCell30
            // 
            this.textBoxCell30.Location = new System.Drawing.Point(782, 0);
            this.textBoxCell30.Name = "textBoxCell30";
            this.textBoxCell30.TabIndex = 14;
            // 
            // TempZaikosuii
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 42;
            this.Width = 1501;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell1;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell2;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell3;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell4;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell5;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell6;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell7;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell8;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell9;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell10;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell11;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell12;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell13;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell14;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell15;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell16;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell17;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell18;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell19;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell20;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell21;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell22;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell23;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell24;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell25;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell26;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell27;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell28;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell29;
        private GrapeCity.Win.MultiRow.TextBoxCell textBoxCell30;
    }
}
