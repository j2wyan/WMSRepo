﻿namespace WMS_V1.UI
{          
    [System.ComponentModel.ToolboxItem(true)]
    partial class Item_DeatilListTemplate
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region MultiRow Template Designer generated code

		/// <summary> 
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
        private void InitializeComponent()
        {
            GrapeCity.Win.MultiRow.CellStyle cellStyle17 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border17 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle16 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border16 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle15 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border15 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle14 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border14 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle13 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border13 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle12 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border12 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle11 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border11 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle10 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border10 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle9 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border9 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle8 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border8 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle7 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border7 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle6 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border6 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle5 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border5 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle4 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border4 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle3 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border3 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle2 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border2 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle1 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border1 = new GrapeCity.Win.MultiRow.Border();
            GrapeCity.Win.MultiRow.CellStyle cellStyle18 = new GrapeCity.Win.MultiRow.CellStyle();
            GrapeCity.Win.MultiRow.Border border18 = new GrapeCity.Win.MultiRow.Border();
            this.columnHeaderSection1 = new GrapeCity.Win.MultiRow.ColumnHeaderSection();
            this.txtCode = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtCName = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtfurigame = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtQuantity = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtUnit = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtCupon1 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtCupon2 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtCupon3 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtCupon4 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtCupon5 = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtI = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtW = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtX = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtV = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtZ = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAA = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAB = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAC = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAD = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAE = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAF = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAG = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAH = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtAI = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.txtS = new GrapeCity.Win.MultiRow.TextBoxCell();
            this.headerCell18 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell17 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell16 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell15 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell14 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell13 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell12 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell11 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell10 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell9 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell8 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell7 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell6 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell5 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell4 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell2 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell1 = new GrapeCity.Win.MultiRow.HeaderCell();
            this.headerCell3 = new GrapeCity.Win.MultiRow.HeaderCell();
            // 
            // Row
            // 
            this.Row.Cells.Add(this.txtCode);
            this.Row.Cells.Add(this.txtCName);
            this.Row.Cells.Add(this.txtfurigame);
            this.Row.Cells.Add(this.txtQuantity);
            this.Row.Cells.Add(this.txtUnit);
            this.Row.Cells.Add(this.txtCupon1);
            this.Row.Cells.Add(this.txtCupon2);
            this.Row.Cells.Add(this.txtCupon3);
            this.Row.Cells.Add(this.txtCupon4);
            this.Row.Cells.Add(this.txtCupon5);
            this.Row.Cells.Add(this.txtI);
            this.Row.Cells.Add(this.txtW);
            this.Row.Cells.Add(this.txtX);
            this.Row.Cells.Add(this.txtV);
            this.Row.Cells.Add(this.txtZ);
            this.Row.Cells.Add(this.txtAA);
            this.Row.Cells.Add(this.txtAB);
            this.Row.Cells.Add(this.txtAC);
            this.Row.Cells.Add(this.txtAD);
            this.Row.Cells.Add(this.txtAE);
            this.Row.Cells.Add(this.txtAF);
            this.Row.Cells.Add(this.txtAG);
            this.Row.Cells.Add(this.txtAH);
            this.Row.Cells.Add(this.txtAI);
            this.Row.Cells.Add(this.txtS);
            this.Row.Height = 21;
            this.Row.Width = 1951;
            // 
            // columnHeaderSection1
            // 
            this.columnHeaderSection1.Cells.Add(this.headerCell1);
            this.columnHeaderSection1.Cells.Add(this.headerCell2);
            this.columnHeaderSection1.Cells.Add(this.headerCell4);
            this.columnHeaderSection1.Cells.Add(this.headerCell5);
            this.columnHeaderSection1.Cells.Add(this.headerCell6);
            this.columnHeaderSection1.Cells.Add(this.headerCell7);
            this.columnHeaderSection1.Cells.Add(this.headerCell8);
            this.columnHeaderSection1.Cells.Add(this.headerCell9);
            this.columnHeaderSection1.Cells.Add(this.headerCell10);
            this.columnHeaderSection1.Cells.Add(this.headerCell11);
            this.columnHeaderSection1.Cells.Add(this.headerCell12);
            this.columnHeaderSection1.Cells.Add(this.headerCell13);
            this.columnHeaderSection1.Cells.Add(this.headerCell14);
            this.columnHeaderSection1.Cells.Add(this.headerCell15);
            this.columnHeaderSection1.Cells.Add(this.headerCell16);
            this.columnHeaderSection1.Cells.Add(this.headerCell17);
            this.columnHeaderSection1.Cells.Add(this.headerCell18);
            this.columnHeaderSection1.Cells.Add(this.headerCell3);
            this.columnHeaderSection1.Height = 30;
            this.columnHeaderSection1.Name = "columnHeaderSection1";
            this.columnHeaderSection1.Width = 1951;
            // 
            // txtCode
            // 
            this.txtCode.DataField = "B";
            this.txtCode.Location = new System.Drawing.Point(0, 0);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(228, 21);
            this.txtCode.TabIndex = 0;
            // 
            // txtCName
            // 
            this.txtCName.DataField = "C";
            this.txtCName.Location = new System.Drawing.Point(228, 0);
            this.txtCName.Name = "txtCName";
            this.txtCName.Size = new System.Drawing.Size(228, 21);
            this.txtCName.TabIndex = 1;
            // 
            // txtfurigame
            // 
            this.txtfurigame.DataField = "D";
            this.txtfurigame.Location = new System.Drawing.Point(456, 0);
            this.txtfurigame.Name = "txtfurigame";
            this.txtfurigame.Size = new System.Drawing.Size(167, 21);
            this.txtfurigame.TabIndex = 3;
            this.txtfurigame.Visible = false;
            // 
            // txtQuantity
            // 
            this.txtQuantity.DataField = "L";
            this.txtQuantity.Location = new System.Drawing.Point(623, 0);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(76, 21);
            this.txtQuantity.TabIndex = 4;
            this.txtQuantity.Visible = false;
            // 
            // txtUnit
            // 
            this.txtUnit.DataField = "M";
            this.txtUnit.Location = new System.Drawing.Point(788, 0);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.Size = new System.Drawing.Size(52, 21);
            this.txtUnit.TabIndex = 5;
            this.txtUnit.Visible = false;
            // 
            // txtCupon1
            // 
            this.txtCupon1.DataField = "N";
            this.txtCupon1.Location = new System.Drawing.Point(840, 0);
            this.txtCupon1.Name = "txtCupon1";
            this.txtCupon1.Size = new System.Drawing.Size(52, 21);
            this.txtCupon1.TabIndex = 6;
            this.txtCupon1.Visible = false;
            // 
            // txtCupon2
            // 
            this.txtCupon2.DataField = "O";
            this.txtCupon2.Location = new System.Drawing.Point(893, 0);
            this.txtCupon2.Name = "txtCupon2";
            this.txtCupon2.Size = new System.Drawing.Size(52, 21);
            this.txtCupon2.TabIndex = 7;
            this.txtCupon2.Visible = false;
            // 
            // txtCupon3
            // 
            this.txtCupon3.DataField = "P";
            this.txtCupon3.Location = new System.Drawing.Point(946, 0);
            this.txtCupon3.Name = "txtCupon3";
            this.txtCupon3.Size = new System.Drawing.Size(52, 21);
            this.txtCupon3.TabIndex = 8;
            this.txtCupon3.Visible = false;
            // 
            // txtCupon4
            // 
            this.txtCupon4.DataField = "Q";
            this.txtCupon4.Location = new System.Drawing.Point(998, 0);
            this.txtCupon4.Name = "txtCupon4";
            this.txtCupon4.Size = new System.Drawing.Size(52, 21);
            this.txtCupon4.TabIndex = 9;
            this.txtCupon4.Visible = false;
            // 
            // txtCupon5
            // 
            this.txtCupon5.DataField = "R";
            this.txtCupon5.Location = new System.Drawing.Point(1050, 0);
            this.txtCupon5.Name = "txtCupon5";
            this.txtCupon5.Size = new System.Drawing.Size(52, 21);
            this.txtCupon5.TabIndex = 10;
            this.txtCupon5.Visible = false;
            // 
            // txtI
            // 
            this.txtI.DataField = "I";
            this.txtI.Location = new System.Drawing.Point(1102, 0);
            this.txtI.Name = "txtI";
            this.txtI.Size = new System.Drawing.Size(52, 21);
            this.txtI.TabIndex = 11;
            this.txtI.Visible = false;
            // 
            // txtW
            // 
            this.txtW.DataField = "W";
            this.txtW.Location = new System.Drawing.Point(1155, 0);
            this.txtW.Name = "txtW";
            this.txtW.Size = new System.Drawing.Size(52, 21);
            this.txtW.TabIndex = 12;
            this.txtW.Visible = false;
            // 
            // txtX
            // 
            this.txtX.DataField = "X";
            this.txtX.Location = new System.Drawing.Point(1207, 0);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(52, 21);
            this.txtX.TabIndex = 13;
            this.txtX.Visible = false;
            // 
            // txtV
            // 
            this.txtV.Location = new System.Drawing.Point(1259, 0);
            this.txtV.Name = "txtV";
            this.txtV.Size = new System.Drawing.Size(52, 21);
            this.txtV.TabIndex = 14;
            this.txtV.Visible = false;
            // 
            // txtZ
            // 
            this.txtZ.DataField = "Z";
            this.txtZ.Location = new System.Drawing.Point(1311, 0);
            this.txtZ.Name = "txtZ";
            this.txtZ.Size = new System.Drawing.Size(52, 21);
            this.txtZ.TabIndex = 15;
            this.txtZ.Visible = false;
            // 
            // txtAA
            // 
            this.txtAA.DataField = "AA";
            this.txtAA.Location = new System.Drawing.Point(1363, 0);
            this.txtAA.Name = "txtAA";
            this.txtAA.Size = new System.Drawing.Size(52, 21);
            this.txtAA.TabIndex = 16;
            this.txtAA.Visible = false;
            // 
            // txtAB
            // 
            this.txtAB.DataField = "AB";
            this.txtAB.Location = new System.Drawing.Point(1415, 0);
            this.txtAB.Name = "txtAB";
            this.txtAB.Size = new System.Drawing.Size(52, 21);
            this.txtAB.TabIndex = 17;
            this.txtAB.Visible = false;
            // 
            // txtAC
            // 
            this.txtAC.DataField = "AC";
            this.txtAC.Location = new System.Drawing.Point(1467, 0);
            this.txtAC.Name = "txtAC";
            this.txtAC.Size = new System.Drawing.Size(52, 21);
            this.txtAC.TabIndex = 18;
            this.txtAC.Visible = false;
            // 
            // txtAD
            // 
            this.txtAD.DataField = "AD";
            this.txtAD.Location = new System.Drawing.Point(1519, 0);
            this.txtAD.Name = "txtAD";
            this.txtAD.Size = new System.Drawing.Size(52, 21);
            this.txtAD.TabIndex = 19;
            this.txtAD.Visible = false;
            // 
            // txtAE
            // 
            this.txtAE.DataField = "AE";
            this.txtAE.Location = new System.Drawing.Point(1571, 0);
            this.txtAE.Name = "txtAE";
            this.txtAE.Size = new System.Drawing.Size(52, 21);
            this.txtAE.TabIndex = 20;
            this.txtAE.Visible = false;
            // 
            // txtAF
            // 
            this.txtAF.DataField = "AF";
            this.txtAF.Location = new System.Drawing.Point(1623, 0);
            this.txtAF.Name = "txtAF";
            this.txtAF.Size = new System.Drawing.Size(52, 21);
            this.txtAF.TabIndex = 21;
            this.txtAF.Visible = false;
            // 
            // txtAG
            // 
            this.txtAG.DataField = "AG";
            this.txtAG.Location = new System.Drawing.Point(1675, 0);
            this.txtAG.Name = "txtAG";
            this.txtAG.Size = new System.Drawing.Size(52, 21);
            this.txtAG.TabIndex = 22;
            this.txtAG.Visible = false;
            // 
            // txtAH
            // 
            this.txtAH.DataField = "AH";
            this.txtAH.Location = new System.Drawing.Point(1727, 0);
            this.txtAH.Name = "txtAH";
            this.txtAH.Size = new System.Drawing.Size(52, 21);
            this.txtAH.TabIndex = 23;
            this.txtAH.Visible = false;
            // 
            // txtAI
            // 
            this.txtAI.DataField = "AI";
            this.txtAI.Location = new System.Drawing.Point(1779, 0);
            this.txtAI.Name = "txtAI";
            this.txtAI.Size = new System.Drawing.Size(52, 21);
            this.txtAI.TabIndex = 24;
            this.txtAI.Visible = false;
            // 
            // txtS
            // 
            this.txtS.DataField = "S";
            this.txtS.Location = new System.Drawing.Point(1831, 0);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(52, 21);
            this.txtS.TabIndex = 25;
            this.txtS.Visible = false;
            // 
            // headerCell18
            // 
            this.headerCell18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell18.Location = new System.Drawing.Point(1859, 0);
            this.headerCell18.Name = "headerCell18";
            this.headerCell18.Size = new System.Drawing.Size(92, 30);
            cellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border17.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border17.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle17.Border = border17;
            cellStyle17.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle17.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle17.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell18.Style = cellStyle17;
            this.headerCell18.TabIndex = 17;
            this.headerCell18.Value = "商品名";
            // 
            // headerCell17
            // 
            this.headerCell17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell17.Location = new System.Drawing.Point(1767, 0);
            this.headerCell17.Name = "headerCell17";
            this.headerCell17.Size = new System.Drawing.Size(92, 30);
            cellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border16.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border16.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle16.Border = border16;
            cellStyle16.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle16.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle16.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell17.Style = cellStyle16;
            this.headerCell17.TabIndex = 16;
            this.headerCell17.Value = "商品名";
            // 
            // headerCell16
            // 
            this.headerCell16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell16.Location = new System.Drawing.Point(1675, 0);
            this.headerCell16.Name = "headerCell16";
            this.headerCell16.Size = new System.Drawing.Size(92, 30);
            cellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border15.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border15.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle15.Border = border15;
            cellStyle15.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle15.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle15.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell16.Style = cellStyle15;
            this.headerCell16.TabIndex = 15;
            this.headerCell16.Value = "商品名";
            // 
            // headerCell15
            // 
            this.headerCell15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell15.Location = new System.Drawing.Point(1590, 0);
            this.headerCell15.Name = "headerCell15";
            this.headerCell15.Size = new System.Drawing.Size(92, 30);
            cellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border14.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border14.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle14.Border = border14;
            cellStyle14.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle14.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle14.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell15.Style = cellStyle14;
            this.headerCell15.TabIndex = 14;
            this.headerCell15.Value = "商品名";
            // 
            // headerCell14
            // 
            this.headerCell14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell14.Location = new System.Drawing.Point(1498, 0);
            this.headerCell14.Name = "headerCell14";
            this.headerCell14.Size = new System.Drawing.Size(92, 30);
            cellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border13.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border13.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle13.Border = border13;
            cellStyle13.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle13.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle13.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell14.Style = cellStyle13;
            this.headerCell14.TabIndex = 13;
            this.headerCell14.Value = "商品名";
            // 
            // headerCell13
            // 
            this.headerCell13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell13.Location = new System.Drawing.Point(1406, 0);
            this.headerCell13.Name = "headerCell13";
            this.headerCell13.Size = new System.Drawing.Size(92, 30);
            cellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border12.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border12.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle12.Border = border12;
            cellStyle12.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle12.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle12.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell13.Style = cellStyle12;
            this.headerCell13.TabIndex = 12;
            this.headerCell13.Value = "在庫";
            // 
            // headerCell12
            // 
            this.headerCell12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell12.Location = new System.Drawing.Point(1314, 0);
            this.headerCell12.Name = "headerCell12";
            this.headerCell12.Size = new System.Drawing.Size(92, 30);
            cellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border11.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border11.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle11.Border = border11;
            cellStyle11.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle11.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle11.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell12.Style = cellStyle11;
            this.headerCell12.TabIndex = 11;
            this.headerCell12.Value = "在庫";
            // 
            // headerCell11
            // 
            this.headerCell11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell11.Location = new System.Drawing.Point(1222, 0);
            this.headerCell11.Name = "headerCell11";
            this.headerCell11.Size = new System.Drawing.Size(92, 30);
            cellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border10.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border10.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle10.Border = border10;
            cellStyle10.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle10.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle10.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell11.Style = cellStyle10;
            this.headerCell11.TabIndex = 10;
            this.headerCell11.Value = "リード";
            // 
            // headerCell10
            // 
            this.headerCell10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell10.Location = new System.Drawing.Point(1130, 0);
            this.headerCell10.Name = "headerCell10";
            this.headerCell10.Size = new System.Drawing.Size(92, 30);
            cellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border9.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border9.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle9.Border = border9;
            cellStyle9.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle9.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle9.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell10.Style = cellStyle9;
            this.headerCell10.TabIndex = 9;
            // 
            // headerCell9
            // 
            this.headerCell9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell9.Location = new System.Drawing.Point(1038, 0);
            this.headerCell9.Name = "headerCell9";
            this.headerCell9.Size = new System.Drawing.Size(92, 30);
            cellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border8.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border8.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle8.Border = border8;
            cellStyle8.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle8.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle8.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell9.Style = cellStyle8;
            this.headerCell9.TabIndex = 8;
            this.headerCell9.Value = "課説区分";
            // 
            // headerCell8
            // 
            this.headerCell8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell8.Location = new System.Drawing.Point(946, 0);
            this.headerCell8.Name = "headerCell8";
            this.headerCell8.Size = new System.Drawing.Size(92, 30);
            cellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border7.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border7.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border7.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border7.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle7.Border = border7;
            cellStyle7.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle7.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle7.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell8.Style = cellStyle7;
            this.headerCell8.TabIndex = 7;
            this.headerCell8.Value = "在庫管理";
            // 
            // headerCell7
            // 
            this.headerCell7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell7.Location = new System.Drawing.Point(859, 0);
            this.headerCell7.Name = "headerCell7";
            this.headerCell7.Size = new System.Drawing.Size(92, 30);
            cellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border6.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border6.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle6.Border = border6;
            cellStyle6.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle6.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle6.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell7.Style = cellStyle6;
            this.headerCell7.TabIndex = 6;
            this.headerCell7.Value = "単価";
            // 
            // headerCell6
            // 
            this.headerCell6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell6.Location = new System.Drawing.Point(767, 0);
            this.headerCell6.Name = "headerCell6";
            this.headerCell6.Size = new System.Drawing.Size(92, 30);
            cellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border5.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border5.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle5.Border = border5;
            cellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle5.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle5.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell6.Style = cellStyle5;
            this.headerCell6.TabIndex = 5;
            this.headerCell6.Value = "数増";
            // 
            // headerCell5
            // 
            this.headerCell5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell5.Location = new System.Drawing.Point(696, 0);
            this.headerCell5.Name = "headerCell5";
            this.headerCell5.Size = new System.Drawing.Size(71, 30);
            cellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border4.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border4.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle4.Border = border4;
            cellStyle4.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle4.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle4.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell5.Style = cellStyle4;
            this.headerCell5.TabIndex = 4;
            this.headerCell5.Value = "入数";
            // 
            // headerCell4
            // 
            this.headerCell4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell4.Location = new System.Drawing.Point(623, 0);
            this.headerCell4.Name = "headerCell4";
            this.headerCell4.Size = new System.Drawing.Size(76, 30);
            cellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border3.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border3.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle3.Border = border3;
            cellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle3.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle3.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell4.Style = cellStyle3;
            this.headerCell4.TabIndex = 3;
            this.headerCell4.Value = "単位";
            // 
            // headerCell2
            // 
            this.headerCell2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell2.Location = new System.Drawing.Point(228, 0);
            this.headerCell2.Name = "headerCell2";
            this.headerCell2.Size = new System.Drawing.Size(228, 30);
            cellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border2.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border2.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle2.Border = border2;
            cellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle2.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle2.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell2.Style = cellStyle2;
            this.headerCell2.TabIndex = 1;
            this.headerCell2.Value = "商品名";
            // 
            // headerCell1
            // 
            this.headerCell1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell1.Location = new System.Drawing.Point(0, 0);
            this.headerCell1.Name = "headerCell1";
            this.headerCell1.Size = new System.Drawing.Size(228, 30);
            cellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border1.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border1.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle1.Border = border1;
            cellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle1.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle1.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell1.Style = cellStyle1;
            this.headerCell1.TabIndex = 0;
            this.headerCell1.Value = "商品コード";
            // 
            // headerCell3
            // 
            this.headerCell3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headerCell3.Location = new System.Drawing.Point(456, 0);
            this.headerCell3.Name = "headerCell3";
            this.headerCell3.Size = new System.Drawing.Size(165, 30);
            cellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(213)))), ((int)(((byte)(203)))));
            border18.Bottom = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Left = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Right = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            border18.Top = new GrapeCity.Win.MultiRow.Line(GrapeCity.Win.MultiRow.LineStyle.Thin, System.Drawing.Color.Gray);
            cellStyle18.Border = border18;
            cellStyle18.Font = new System.Drawing.Font("MS UI Gothic", 8.25F);
            cellStyle18.ImeMode = System.Windows.Forms.ImeMode.Off;
            cellStyle18.TextAlign = GrapeCity.Win.MultiRow.MultiRowContentAlignment.MiddleCenter;
            this.headerCell3.Style = cellStyle18;
            this.headerCell3.TabIndex = 18;
            this.headerCell3.Value = "商品名";
            // 
            // Item_DeatilListTemplate
            // 
            this.ColumnHeaders.AddRange(new GrapeCity.Win.MultiRow.ColumnHeaderSection[] {
            this.columnHeaderSection1});
            this.Height = 51;
            this.Width = 1951;

        }
        

        #endregion

        private GrapeCity.Win.MultiRow.ColumnHeaderSection columnHeaderSection1;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCode;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCName;
        private GrapeCity.Win.MultiRow.TextBoxCell txtfurigame;
        private GrapeCity.Win.MultiRow.TextBoxCell txtQuantity;
        private GrapeCity.Win.MultiRow.TextBoxCell txtUnit;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCupon1;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCupon2;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCupon3;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCupon4;
        private GrapeCity.Win.MultiRow.TextBoxCell txtCupon5;
        private GrapeCity.Win.MultiRow.TextBoxCell txtI;
        private GrapeCity.Win.MultiRow.TextBoxCell txtW;
        private GrapeCity.Win.MultiRow.TextBoxCell txtX;
        private GrapeCity.Win.MultiRow.TextBoxCell txtV;
        private GrapeCity.Win.MultiRow.TextBoxCell txtZ;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAA;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAB;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAC;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAD;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAE;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAF;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAG;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAH;
        private GrapeCity.Win.MultiRow.TextBoxCell txtAI;
        private GrapeCity.Win.MultiRow.TextBoxCell txtS;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell1;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell2;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell4;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell5;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell6;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell7;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell8;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell9;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell10;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell11;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell12;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell13;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell14;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell15;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell16;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell17;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell18;
        private GrapeCity.Win.MultiRow.HeaderCell headerCell3;
    }
}
