﻿namespace WMS_V1
{
    partial class JutyuEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            GrapeCity.Win.Editors.Fields.DateYearField dateYearField3 = new GrapeCity.Win.Editors.Fields.DateYearField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField13 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateMonthField dateMonthField5 = new GrapeCity.Win.Editors.Fields.DateMonthField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField14 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateDayField dateDayField5 = new GrapeCity.Win.Editors.Fields.DateDayField();
            GrapeCity.Win.Editors.Fields.DateMonthField dateMonthField6 = new GrapeCity.Win.Editors.Fields.DateMonthField();
            GrapeCity.Win.Editors.Fields.DateEraDisplayField dateEraDisplayField3 = new GrapeCity.Win.Editors.Fields.DateEraDisplayField();
            GrapeCity.Win.Editors.Fields.DateLiteralDisplayField dateLiteralDisplayField9 = new GrapeCity.Win.Editors.Fields.DateLiteralDisplayField();
            GrapeCity.Win.Editors.Fields.DateEraYearDisplayField dateEraYearDisplayField3 = new GrapeCity.Win.Editors.Fields.DateEraYearDisplayField();
            GrapeCity.Win.Editors.Fields.DateLiteralDisplayField dateLiteralDisplayField10 = new GrapeCity.Win.Editors.Fields.DateLiteralDisplayField();
            GrapeCity.Win.Editors.Fields.DateMonthDisplayField dateMonthDisplayField3 = new GrapeCity.Win.Editors.Fields.DateMonthDisplayField();
            GrapeCity.Win.Editors.Fields.DateLiteralDisplayField dateLiteralDisplayField11 = new GrapeCity.Win.Editors.Fields.DateLiteralDisplayField();
            GrapeCity.Win.Editors.Fields.DateDayDisplayField dateDayDisplayField3 = new GrapeCity.Win.Editors.Fields.DateDayDisplayField();
            GrapeCity.Win.Editors.Fields.DateLiteralDisplayField dateLiteralDisplayField12 = new GrapeCity.Win.Editors.Fields.DateLiteralDisplayField();
            GrapeCity.Win.Editors.Fields.DateEraField dateEraField3 = new GrapeCity.Win.Editors.Fields.DateEraField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField15 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateEraYearField dateEraYearField3 = new GrapeCity.Win.Editors.Fields.DateEraYearField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField16 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField17 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateDayField dateDayField6 = new GrapeCity.Win.Editors.Fields.DateDayField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField18 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JutyuEntry));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtPDF = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.gcMultiRow1 = new GrapeCity.Win.MultiRow.GcMultiRow();
            this.tempJutyuEntry1 = new WMS_V1.TempJutyuEntry();
            this.gcDate2 = new GrapeCity.Win.Editors.GcDate(this.components);
            this.dropDownButton2 = new GrapeCity.Win.Editors.DropDownButton();
            this.gcDate1 = new GrapeCity.Win.Editors.GcDate(this.components);
            this.dropDownButton1 = new GrapeCity.Win.Editors.DropDownButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.txtSokoName = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.txtTantoName = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.txtPricePercent = new System.Windows.Forms.TextBox();
            this.txtlTaxImpName = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.txtSokoCode = new System.Windows.Forms.TextBox();
            this.txtTantoCode = new System.Windows.Forms.TextBox();
            this.txtTaxImpCode = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.txtUnitsPriceType = new System.Windows.Forms.TextBox();
            this.txtTradeDivName = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.txtTradeDivCode = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.CostTotal = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.AmtTotal = new System.Windows.Forms.TextBox();
            this.AmtCostMinus = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.TaxTotal = new System.Windows.Forms.TextBox();
            this.TaxPercent = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.AllTotal = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.txtlblStatus = new System.Windows.Forms.TextBox();
            this.txtUserCode = new System.Windows.Forms.TextBox();
            this.txtDenpyoBango = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gcShortcut1 = new GrapeCity.Win.Editors.GcShortcut(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.伝票複写ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.払い出しToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.発注複写ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtPDF);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.gcMultiRow1);
            this.panel1.Controls.Add(this.gcDate2);
            this.panel1.Controls.Add(this.gcDate1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtUserName);
            this.panel1.Controls.Add(this.textBox13);
            this.panel1.Controls.Add(this.txtSokoName);
            this.panel1.Controls.Add(this.textBox25);
            this.panel1.Controls.Add(this.textBox16);
            this.panel1.Controls.Add(this.txtTantoName);
            this.panel1.Controls.Add(this.textBox24);
            this.panel1.Controls.Add(this.txtPricePercent);
            this.panel1.Controls.Add(this.txtlTaxImpName);
            this.panel1.Controls.Add(this.textBox10);
            this.panel1.Controls.Add(this.txtSokoCode);
            this.panel1.Controls.Add(this.txtTantoCode);
            this.panel1.Controls.Add(this.txtTaxImpCode);
            this.panel1.Controls.Add(this.textBox23);
            this.panel1.Controls.Add(this.txtUnitsPriceType);
            this.panel1.Controls.Add(this.txtTradeDivName);
            this.panel1.Controls.Add(this.textBox22);
            this.panel1.Controls.Add(this.textBox21);
            this.panel1.Controls.Add(this.txtTradeDivCode);
            this.panel1.Controls.Add(this.textBox20);
            this.panel1.Controls.Add(this.CostTotal);
            this.panel1.Controls.Add(this.textBox19);
            this.panel1.Controls.Add(this.AmtTotal);
            this.panel1.Controls.Add(this.AmtCostMinus);
            this.panel1.Controls.Add(this.textBox18);
            this.panel1.Controls.Add(this.TaxTotal);
            this.panel1.Controls.Add(this.TaxPercent);
            this.panel1.Controls.Add(this.textBox26);
            this.panel1.Controls.Add(this.AllTotal);
            this.panel1.Controls.Add(this.textBox17);
            this.panel1.Controls.Add(this.txtlblStatus);
            this.panel1.Controls.Add(this.txtUserCode);
            this.panel1.Controls.Add(this.txtDenpyoBango);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(928, 726);
            this.panel1.TabIndex = 0;
            // 
            // txtPDF
            // 
            this.txtPDF.Location = new System.Drawing.Point(545, 44);
            this.txtPDF.Name = "txtPDF";
            this.txtPDF.Size = new System.Drawing.Size(315, 20);
            this.txtPDF.TabIndex = 102;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(865, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(49, 26);
            this.button1.TabIndex = 101;
            this.button1.Text = "参照";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(510, 49);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 13);
            this.label27.TabIndex = 100;
            this.label27.Text = "PDF:";
            // 
            // gcMultiRow1
            // 
            this.gcMultiRow1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.gcMultiRow1.BackColor = System.Drawing.Color.White;
            this.gcMultiRow1.Location = new System.Drawing.Point(11, 231);
            this.gcMultiRow1.Name = "gcMultiRow1";
            this.gcMultiRow1.Size = new System.Drawing.Size(904, 444);
            this.gcMultiRow1.TabIndex = 99;
            this.gcMultiRow1.Template = this.tempJutyuEntry1;
            this.gcMultiRow1.Text = "gcMultiRow1";
            // 
            // gcDate2
            // 
            this.gcDate2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            dateLiteralField13.Text = "/";
            dateLiteralField14.Text = "/";
            this.gcDate2.Fields.AddRange(new GrapeCity.Win.Editors.Fields.DateField[] {
            dateYearField3,
            dateLiteralField13,
            dateMonthField5,
            dateLiteralField14,
            dateDayField5});
            this.gcDate2.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcDate2.Location = new System.Drawing.Point(246, 69);
            this.gcDate2.Name = "gcDate2";
            this.gcDate2.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton2});
            this.gcDate2.Size = new System.Drawing.Size(130, 22);
            this.gcDate2.TabIndex = 3;
            this.gcDate2.Value = new System.DateTime(2017, 4, 21, 0, 0, 0, 0);
            // 
            // dropDownButton2
            // 
            this.dropDownButton2.Name = "dropDownButton2";
            // 
            // gcDate1
            // 
            this.gcDate1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.gcDate1.DefaultActiveField = dateMonthField6;
            dateLiteralDisplayField10.Text = "年";
            dateLiteralDisplayField11.Text = "月";
            dateLiteralDisplayField12.Text = "日";
            this.gcDate1.DisplayFields.AddRange(new GrapeCity.Win.Editors.Fields.DateDisplayField[] {
            dateEraDisplayField3,
            dateLiteralDisplayField9,
            dateEraYearDisplayField3,
            dateLiteralDisplayField10,
            dateMonthDisplayField3,
            dateLiteralDisplayField11,
            dateDayDisplayField3,
            dateLiteralDisplayField12});
            this.gcDate1.DropDownCalendar.EnableScrollAnimation = false;
            this.gcDate1.DropDownCalendar.HeaderFormat = "ggg e年 M月";
            this.gcDate1.DropDownCalendar.Lines = new GrapeCity.Win.Editors.Grid(new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.None, System.Drawing.SystemColors.ControlDark), new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.None, System.Drawing.SystemColors.ControlDark), new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.None, System.Drawing.SystemColors.ControlDark), new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.None, System.Drawing.SystemColors.ControlDark), new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.Single, System.Drawing.SystemColors.GrayText), new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.Single, System.Drawing.SystemColors.GrayText), new GrapeCity.Win.Editors.Line(GrapeCity.Win.Editors.LineStyle.None, System.Drawing.SystemColors.ControlDark), GrapeCity.Win.Editors.VerticalFlags.Both);
            this.gcDate1.DropDownCalendar.NavigateOnWheel = false;
            this.gcDate1.DropDownCalendar.NavigatorOrientation = GrapeCity.Win.Editors.NavigatorOrientation.Top;
            this.gcDate1.DropDownCalendar.ScrollTipAlign = GrapeCity.Win.Editors.ScrollTipAlignment.Center;
            this.gcDate1.DropDownCalendar.ShowNavigator = GrapeCity.Win.Editors.CalendarNavigators.Buttons;
            this.gcDate1.DropDownCalendar.ShowScrollTip = false;
            this.gcDate1.DropDownCalendar.UseHeaderFormat = true;
            this.gcDate1.DropDownCalendar.Weekdays = new GrapeCity.Win.Editors.WeekdaysStyle(new GrapeCity.Win.Editors.DayOfWeekStyle("日", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.Color.Red, false, false), ((GrapeCity.Win.Editors.WeekFlags)((((((GrapeCity.Win.Editors.WeekFlags.FirstWeek | GrapeCity.Win.Editors.WeekFlags.SecondWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.ThirdWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.FourthWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.FifthWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.LastWeek)))), new GrapeCity.Win.Editors.DayOfWeekStyle("月", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, false, false), GrapeCity.Win.Editors.WeekFlags.None), new GrapeCity.Win.Editors.DayOfWeekStyle("火", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, false, false), GrapeCity.Win.Editors.WeekFlags.None), new GrapeCity.Win.Editors.DayOfWeekStyle("水", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, false, false), GrapeCity.Win.Editors.WeekFlags.None), new GrapeCity.Win.Editors.DayOfWeekStyle("木", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, false, false), GrapeCity.Win.Editors.WeekFlags.None), new GrapeCity.Win.Editors.DayOfWeekStyle("金", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, false, false), GrapeCity.Win.Editors.WeekFlags.None), new GrapeCity.Win.Editors.DayOfWeekStyle("土", GrapeCity.Win.Editors.ReflectTitle.None, new GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.Color.Blue, false, false), ((GrapeCity.Win.Editors.WeekFlags)((((((GrapeCity.Win.Editors.WeekFlags.FirstWeek | GrapeCity.Win.Editors.WeekFlags.SecondWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.ThirdWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.FourthWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.FifthWeek) 
                    | GrapeCity.Win.Editors.WeekFlags.LastWeek)))));
            dateLiteralField16.Text = "年";
            dateLiteralField17.Text = "月";
            dateLiteralField18.Text = "日";
            this.gcDate1.Fields.AddRange(new GrapeCity.Win.Editors.Fields.DateField[] {
            dateEraField3,
            dateLiteralField15,
            dateEraYearField3,
            dateLiteralField16,
            dateMonthField6,
            dateLiteralField17,
            dateDayField6,
            dateLiteralField18});
            this.gcDate1.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcDate1.HideSelection = false;
            this.gcDate1.HighlightText = GrapeCity.Win.Editors.HighlightText.Field;
            this.gcDate1.Location = new System.Drawing.Point(110, 69);
            this.gcDate1.Name = "gcDate1";
            this.gcDate1.RecommendedValue = new System.DateTime(2017, 4, 1, 0, 0, 0, 0);
            this.gcShortcut1.SetShortcuts(this.gcDate1, new GrapeCity.Win.Editors.ShortcutCollection(new System.Windows.Forms.Keys[] {
                System.Windows.Forms.Keys.F2,
                System.Windows.Forms.Keys.F5,
                ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Return)))}, new object[] {
                ((object)(this.gcDate1)),
                ((object)(this.gcDate1)),
                ((object)(this.gcDate1))}, new string[] {
                "ShortcutClear",
                "SetNow",
                "ApplyRecommendedValue"}));
            this.gcDate1.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton1});
            this.gcDate1.Size = new System.Drawing.Size(130, 22);
            this.gcDate1.TabAction = GrapeCity.Win.Editors.TabAction.Field;
            this.gcDate1.TabIndex = 2;
            this.gcDate1.Value = new System.DateTime(2017, 4, 21, 0, 0, 0, 0);
            // 
            // dropDownButton1
            // 
            this.dropDownButton1.Name = "dropDownButton1";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(246, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 22);
            this.label4.TabIndex = 2;
            this.label4.Text = "出荷予定日";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(110, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "受注日付";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Location = new System.Drawing.Point(11, 203);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 22);
            this.label10.TabIndex = 2;
            this.label10.Text = "摘要";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(11, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 22);
            this.label9.TabIndex = 2;
            this.label9.Text = "倉庫";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Location = new System.Drawing.Point(229, 161);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 22);
            this.label13.TabIndex = 2;
            this.label13.Text = "入力者";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Location = new System.Drawing.Point(11, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 22);
            this.label8.TabIndex = 2;
            this.label8.Text = "担当者";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Location = new System.Drawing.Point(229, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 22);
            this.label12.TabIndex = 2;
            this.label12.Text = "掛率";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Location = new System.Drawing.Point(11, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 22);
            this.label7.TabIndex = 2;
            this.label7.Text = "税転嫁";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Location = new System.Drawing.Point(229, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 22);
            this.label11.TabIndex = 2;
            this.label11.Text = "単価種類";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Location = new System.Drawing.Point(11, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 22);
            this.label6.TabIndex = 2;
            this.label6.Text = "取引区分";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Location = new System.Drawing.Point(546, 203);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 22);
            this.label19.TabIndex = 2;
            this.label19.Text = "FAX";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Location = new System.Drawing.Point(546, 182);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 22);
            this.label18.TabIndex = 2;
            this.label18.Text = "TEL";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Location = new System.Drawing.Point(546, 161);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 22);
            this.label17.TabIndex = 2;
            this.label17.Text = "納入先住所２";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label16.Location = new System.Drawing.Point(546, 141);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 22);
            this.label16.TabIndex = 2;
            this.label16.Text = "納入先住所１";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Location = new System.Drawing.Point(546, 120);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 22);
            this.label15.TabIndex = 2;
            this.label15.Text = "納入先名";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label14.Location = new System.Drawing.Point(546, 100);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 22);
            this.label14.TabIndex = 2;
            this.label14.Text = "納入先";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(11, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 22);
            this.label5.TabIndex = 2;
            this.label5.Text = "得意先";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label26.Location = new System.Drawing.Point(117, 678);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(100, 22);
            this.label26.TabIndex = 2;
            this.label26.Text = "原価";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Location = new System.Drawing.Point(216, 678);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 22);
            this.label25.TabIndex = 2;
            this.label25.Text = "粗利益";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Location = new System.Drawing.Point(617, 678);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 22);
            this.label23.TabIndex = 2;
            this.label23.Text = "税抜額";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.Location = new System.Drawing.Point(315, 678);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 22);
            this.label24.TabIndex = 2;
            this.label24.Text = "粗利益率";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Location = new System.Drawing.Point(716, 678);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 22);
            this.label22.TabIndex = 2;
            this.label22.Text = "消費税額";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Location = new System.Drawing.Point(815, 678);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(100, 22);
            this.label21.TabIndex = 2;
            this.label21.Text = "合計";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Location = new System.Drawing.Point(11, 678);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 22);
            this.label20.TabIndex = 2;
            this.label20.Text = "状態";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(220)))), ((int)(((byte)(200)))));
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Location = new System.Drawing.Point(11, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "受注番号";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserName.Location = new System.Drawing.Point(229, 100);
            this.txtUserName.Multiline = true;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(294, 22);
            this.txtUserName.TabIndex = 5;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.Location = new System.Drawing.Point(143, 203);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(380, 22);
            this.textBox13.TabIndex = 1;
            // 
            // txtSokoName
            // 
            this.txtSokoName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtSokoName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSokoName.Location = new System.Drawing.Point(143, 182);
            this.txtSokoName.Multiline = true;
            this.txtSokoName.Name = "txtSokoName";
            this.txtSokoName.Size = new System.Drawing.Size(380, 22);
            this.txtSokoName.TabIndex = 1;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.SystemColors.Control;
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox25.Location = new System.Drawing.Point(414, 161);
            this.textBox25.Multiline = true;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(109, 22);
            this.textBox25.TabIndex = 1;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Location = new System.Drawing.Point(328, 161);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(87, 22);
            this.textBox16.TabIndex = 1;
            // 
            // txtTantoName
            // 
            this.txtTantoName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtTantoName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTantoName.Location = new System.Drawing.Point(143, 161);
            this.txtTantoName.Multiline = true;
            this.txtTantoName.Name = "txtTantoName";
            this.txtTantoName.Size = new System.Drawing.Size(87, 22);
            this.txtTantoName.TabIndex = 1;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.SystemColors.Control;
            this.textBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox24.Location = new System.Drawing.Point(414, 141);
            this.textBox24.Multiline = true;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(109, 22);
            this.textBox24.TabIndex = 1;
            // 
            // txtPricePercent
            // 
            this.txtPricePercent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtPricePercent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPricePercent.Location = new System.Drawing.Point(328, 141);
            this.txtPricePercent.Multiline = true;
            this.txtPricePercent.Name = "txtPricePercent";
            this.txtPricePercent.Size = new System.Drawing.Size(87, 22);
            this.txtPricePercent.TabIndex = 1;
            // 
            // txtlTaxImpName
            // 
            this.txtlTaxImpName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtlTaxImpName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtlTaxImpName.Location = new System.Drawing.Point(143, 141);
            this.txtlTaxImpName.Multiline = true;
            this.txtlTaxImpName.Name = "txtlTaxImpName";
            this.txtlTaxImpName.Size = new System.Drawing.Size(87, 22);
            this.txtlTaxImpName.TabIndex = 1;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Location = new System.Drawing.Point(110, 203);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(34, 22);
            this.textBox10.TabIndex = 10;
            // 
            // txtSokoCode
            // 
            this.txtSokoCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtSokoCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSokoCode.Location = new System.Drawing.Point(110, 182);
            this.txtSokoCode.Multiline = true;
            this.txtSokoCode.Name = "txtSokoCode";
            this.txtSokoCode.Size = new System.Drawing.Size(34, 22);
            this.txtSokoCode.TabIndex = 9;
            // 
            // txtTantoCode
            // 
            this.txtTantoCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtTantoCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTantoCode.Location = new System.Drawing.Point(110, 161);
            this.txtTantoCode.Multiline = true;
            this.txtTantoCode.Name = "txtTantoCode";
            this.txtTantoCode.Size = new System.Drawing.Size(34, 22);
            this.txtTantoCode.TabIndex = 8;
            // 
            // txtTaxImpCode
            // 
            this.txtTaxImpCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtTaxImpCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTaxImpCode.Location = new System.Drawing.Point(110, 141);
            this.txtTaxImpCode.Multiline = true;
            this.txtTaxImpCode.Name = "txtTaxImpCode";
            this.txtTaxImpCode.Size = new System.Drawing.Size(34, 22);
            this.txtTaxImpCode.TabIndex = 7;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.SystemColors.Control;
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox23.Location = new System.Drawing.Point(414, 120);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(109, 22);
            this.textBox23.TabIndex = 1;
            // 
            // txtUnitsPriceType
            // 
            this.txtUnitsPriceType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtUnitsPriceType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUnitsPriceType.Location = new System.Drawing.Point(328, 120);
            this.txtUnitsPriceType.Multiline = true;
            this.txtUnitsPriceType.Name = "txtUnitsPriceType";
            this.txtUnitsPriceType.Size = new System.Drawing.Size(87, 22);
            this.txtUnitsPriceType.TabIndex = 1;
            // 
            // txtTradeDivName
            // 
            this.txtTradeDivName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtTradeDivName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTradeDivName.Location = new System.Drawing.Point(143, 120);
            this.txtTradeDivName.Multiline = true;
            this.txtTradeDivName.Name = "txtTradeDivName";
            this.txtTradeDivName.Size = new System.Drawing.Size(87, 22);
            this.txtTradeDivName.TabIndex = 1;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox22.Location = new System.Drawing.Point(645, 203);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(270, 22);
            this.textBox22.TabIndex = 11;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox21.Location = new System.Drawing.Point(645, 182);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(270, 22);
            this.textBox21.TabIndex = 11;
            // 
            // txtTradeDivCode
            // 
            this.txtTradeDivCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtTradeDivCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTradeDivCode.Location = new System.Drawing.Point(110, 120);
            this.txtTradeDivCode.Multiline = true;
            this.txtTradeDivCode.Name = "txtTradeDivCode";
            this.txtTradeDivCode.Size = new System.Drawing.Size(34, 22);
            this.txtTradeDivCode.TabIndex = 6;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox20.Location = new System.Drawing.Point(645, 161);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(270, 22);
            this.textBox20.TabIndex = 11;
            // 
            // CostTotal
            // 
            this.CostTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.CostTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.CostTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CostTotal.Location = new System.Drawing.Point(117, 699);
            this.CostTotal.Multiline = true;
            this.CostTotal.Name = "CostTotal";
            this.CostTotal.Size = new System.Drawing.Size(100, 22);
            this.CostTotal.TabIndex = 1;
            this.CostTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox19.Location = new System.Drawing.Point(645, 141);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(270, 22);
            this.textBox19.TabIndex = 11;
            // 
            // AmtTotal
            // 
            this.AmtTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AmtTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.AmtTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AmtTotal.Location = new System.Drawing.Point(617, 699);
            this.AmtTotal.Multiline = true;
            this.AmtTotal.Name = "AmtTotal";
            this.AmtTotal.Size = new System.Drawing.Size(100, 22);
            this.AmtTotal.TabIndex = 1;
            this.AmtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AmtCostMinus
            // 
            this.AmtCostMinus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AmtCostMinus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.AmtCostMinus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AmtCostMinus.Location = new System.Drawing.Point(216, 699);
            this.AmtCostMinus.Multiline = true;
            this.AmtCostMinus.Name = "AmtCostMinus";
            this.AmtCostMinus.Size = new System.Drawing.Size(100, 22);
            this.AmtCostMinus.TabIndex = 1;
            this.AmtCostMinus.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox18.Location = new System.Drawing.Point(645, 120);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(270, 22);
            this.textBox18.TabIndex = 11;
            // 
            // TaxTotal
            // 
            this.TaxTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.TaxTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.TaxTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TaxTotal.Location = new System.Drawing.Point(716, 699);
            this.TaxTotal.Multiline = true;
            this.TaxTotal.Name = "TaxTotal";
            this.TaxTotal.Size = new System.Drawing.Size(100, 22);
            this.TaxTotal.TabIndex = 1;
            this.TaxTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TaxPercent
            // 
            this.TaxPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.TaxPercent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.TaxPercent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TaxPercent.Location = new System.Drawing.Point(315, 699);
            this.TaxPercent.Multiline = true;
            this.TaxPercent.Name = "TaxPercent";
            this.TaxPercent.Size = new System.Drawing.Size(100, 22);
            this.TaxPercent.TabIndex = 1;
            this.TaxPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.Control;
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox26.Location = new System.Drawing.Point(764, 100);
            this.textBox26.Multiline = true;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(151, 22);
            this.textBox26.TabIndex = 1;
            // 
            // AllTotal
            // 
            this.AllTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AllTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.AllTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AllTotal.Location = new System.Drawing.Point(815, 699);
            this.AllTotal.Multiline = true;
            this.AllTotal.Name = "AllTotal";
            this.AllTotal.Size = new System.Drawing.Size(100, 22);
            this.AllTotal.TabIndex = 1;
            this.AllTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox17.Location = new System.Drawing.Point(645, 100);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(120, 22);
            this.textBox17.TabIndex = 11;
            // 
            // txtlblStatus
            // 
            this.txtlblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtlblStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(223)))));
            this.txtlblStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtlblStatus.Location = new System.Drawing.Point(11, 699);
            this.txtlblStatus.Multiline = true;
            this.txtlblStatus.Name = "txtlblStatus";
            this.txtlblStatus.Size = new System.Drawing.Size(100, 22);
            this.txtlblStatus.TabIndex = 1;
            this.txtlblStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUserCode
            // 
            this.txtUserCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtUserCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserCode.Location = new System.Drawing.Point(110, 100);
            this.txtUserCode.Multiline = true;
            this.txtUserCode.Name = "txtUserCode";
            this.txtUserCode.Size = new System.Drawing.Size(120, 22);
            this.txtUserCode.TabIndex = 4;
            // 
            // txtDenpyoBango
            // 
            this.txtDenpyoBango.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.txtDenpyoBango.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDenpyoBango.Location = new System.Drawing.Point(11, 69);
            this.txtDenpyoBango.Multiline = true;
            this.txtDenpyoBango.Name = "txtDenpyoBango";
            this.txtDenpyoBango.Size = new System.Drawing.Size(100, 22);
            this.txtDenpyoBango.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(150)))), ((int)(((byte)(134)))));
            this.label1.Font = new System.Drawing.Font("Meiryo", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(904, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "受注伝票";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripDropDownButton1,
            this.toolStripSeparator3,
            this.toolStripLabel3,
            this.toolStripSeparator4,
            this.toolStripLabel4,
            this.toolStripSeparator5,
            this.toolStripLabel5,
            this.toolStripSeparator6,
            this.toolStripLabel6,
            this.toolStripSeparator7,
            this.toolStripLabel7,
            this.toolStripSeparator8,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(928, 49);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "ヘルプ（F1）";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Image = global::WMS1._0.Properties.Resources.Close;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(105, 46);
            this.toolStripLabel1.Text = "閉じる（ESC）";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Image = global::WMS1._0.Properties.Resources.AddNodefromFile_354;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(91, 46);
            this.toolStripLabel2.Text = "新規（F2）";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.伝票複写ToolStripMenuItem,
            this.払い出しToolStripMenuItem,
            this.発注複写ToolStripMenuItem});
            this.toolStripDropDownButton1.Image = global::WMS1._0.Properties.Resources.good;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(88, 46);
            this.toolStripDropDownButton1.Text = "伝票複写";
            this.toolStripDropDownButton1.ToolTipText = "伝票複写";
            // 
            // 伝票複写ToolStripMenuItem
            // 
            this.伝票複写ToolStripMenuItem.Name = "伝票複写ToolStripMenuItem";
            this.伝票複写ToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.伝票複写ToolStripMenuItem.Text = "複写";
            // 
            // 払い出しToolStripMenuItem
            // 
            this.払い出しToolStripMenuItem.Name = "払い出しToolStripMenuItem";
            this.払い出しToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.払い出しToolStripMenuItem.Text = "払い出し";
            // 
            // 発注複写ToolStripMenuItem
            // 
            this.発注複写ToolStripMenuItem.Name = "発注複写ToolStripMenuItem";
            this.発注複写ToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.発注複写ToolStripMenuItem.Text = "発注複写";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Image = global::WMS1._0.Properties.Resources.Print_11009;
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(91, 46);
            this.toolStripLabel3.Text = "印刷（F5）";
            this.toolStripLabel3.Click += new System.EventHandler(this.toolStripLabel3_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Image = global::WMS1._0.Properties.Resources.Delete;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(91, 46);
            this.toolStripLabel4.Text = "検索（F6）";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Image = global::WMS1._0.Properties.Resources.ser2;
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(91, 46);
            this.toolStripLabel5.Text = "参照（F8）";
            this.toolStripLabel5.Click += new System.EventHandler(this.toolStripLabel5_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Image = global::WMS1._0.Properties.Resources.PrintPreviewDialogControl_699_24;
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(91, 46);
            this.toolStripLabel6.Text = "削除（F9）";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Image = global::WMS1._0.Properties.Resources.Save_6530;
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(97, 46);
            this.toolStripLabel7.Text = "登録（F12）";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 46);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 783);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(928, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // JutyuEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.ClientSize = new System.Drawing.Size(928, 805);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(944, 844);
            this.Name = "JutyuEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "受注伝票入力";
            this.Load += new System.EventHandler(this.JutyuEntry_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private GrapeCity.Win.Editors.GcDate gcDate2;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton2;
        private GrapeCity.Win.Editors.GcShortcut gcShortcut1;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private TempJutyuEntry tempJutyuEntry1;
        private System.Windows.Forms.TextBox txtPDF;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label27;
      //  private AxAcroPDFLib.AxAcroPDF axAcroPDF1;
        private System.Windows.Forms.ToolStripButton toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripLabel3;
        private System.Windows.Forms.ToolStripButton toolStripLabel4;
        private System.Windows.Forms.ToolStripButton toolStripLabel5;
        private System.Windows.Forms.ToolStripButton toolStripLabel6;
        private System.Windows.Forms.ToolStripButton toolStripLabel7;
        private System.Windows.Forms.ToolStripMenuItem 伝票複写ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 払い出しToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 発注複写ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        public System.Windows.Forms.TextBox txtlblStatus;
        public GrapeCity.Win.Editors.GcDate gcDate1;
        public System.Windows.Forms.TextBox txtUserCode;
        public System.Windows.Forms.TextBox txtDenpyoBango;
        public System.Windows.Forms.TextBox txtSokoName;
        public System.Windows.Forms.TextBox txtTantoName;
        public System.Windows.Forms.TextBox textBox24;
        public System.Windows.Forms.TextBox txtPricePercent;
        public System.Windows.Forms.TextBox txtlTaxImpName;
        public System.Windows.Forms.TextBox txtSokoCode;
        public System.Windows.Forms.TextBox txtTantoCode;
        public System.Windows.Forms.TextBox txtTaxImpCode;
        public System.Windows.Forms.TextBox textBox23;
        public System.Windows.Forms.TextBox txtUnitsPriceType;
        public System.Windows.Forms.TextBox txtTradeDivName;
        public System.Windows.Forms.TextBox txtTradeDivCode;
        public System.Windows.Forms.TextBox textBox18;
        public System.Windows.Forms.TextBox textBox17;
        public System.Windows.Forms.TextBox CostTotal;
        public System.Windows.Forms.TextBox AmtTotal;
        public System.Windows.Forms.TextBox AmtCostMinus;
        public System.Windows.Forms.TextBox TaxTotal;
        public System.Windows.Forms.TextBox TaxPercent;
        public System.Windows.Forms.TextBox AllTotal;
        public System.Windows.Forms.TextBox txtUserName;
        public GrapeCity.Win.MultiRow.GcMultiRow gcMultiRow1;
        public System.Windows.Forms.StatusStrip statusStrip1;
    }
}