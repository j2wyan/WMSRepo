﻿namespace WMS_V1.UI
{
    partial class TokuiSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn12 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ComboSearch = new System.Windows.Forms.ComboBox();
            this.LabelSearch = new System.Windows.Forms.Label();
            this.TextSearch = new System.Windows.Forms.TextBox();
            this.ListView = new System.Windows.Forms.ListView();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn12
            // 
            this.btn12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn12.Location = new System.Drawing.Point(627, 20);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(57, 33);
            this.btn12.TabIndex = 0;
            this.btn12.Text = "123...行";
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // btn11
            // 
            this.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn11.Location = new System.Drawing.Point(571, 20);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(57, 33);
            this.btn11.TabIndex = 0;
            this.btn11.Text = "ABC...行";
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // btn10
            // 
            this.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10.Location = new System.Drawing.Point(515, 20);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(57, 33);
            this.btn10.TabIndex = 0;
            this.btn10.Text = "ワ行";
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn9
            // 
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Location = new System.Drawing.Point(459, 20);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(57, 33);
            this.btn9.TabIndex = 0;
            this.btn9.Text = "ラ行";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Location = new System.Drawing.Point(403, 20);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(57, 33);
            this.btn8.TabIndex = 0;
            this.btn8.Text = "ヤ行";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn7
            // 
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Location = new System.Drawing.Point(347, 20);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(57, 33);
            this.btn7.TabIndex = 0;
            this.btn7.Text = "マ行";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn6
            // 
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Location = new System.Drawing.Point(291, 20);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(57, 33);
            this.btn6.TabIndex = 0;
            this.btn6.Text = "ハ行";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn5
            // 
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Location = new System.Drawing.Point(235, 20);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(57, 33);
            this.btn5.TabIndex = 0;
            this.btn5.Text = "ナ行";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn12);
            this.groupBox1.Controls.Add(this.btn11);
            this.groupBox1.Controls.Add(this.btn10);
            this.groupBox1.Controls.Add(this.btn9);
            this.groupBox1.Controls.Add(this.btn8);
            this.groupBox1.Controls.Add(this.btn7);
            this.groupBox1.Controls.Add(this.btn6);
            this.groupBox1.Controls.Add(this.btn5);
            this.groupBox1.Controls.Add(this.btn4);
            this.groupBox1.Controls.Add(this.btn3);
            this.groupBox1.Controls.Add(this.btn2);
            this.groupBox1.Controls.Add(this.btn1);
            this.groupBox1.Location = new System.Drawing.Point(14, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(711, 69);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "読み";
            // 
            // btn4
            // 
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Location = new System.Drawing.Point(179, 20);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(57, 33);
            this.btn4.TabIndex = 0;
            this.btn4.Text = "タ行";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Location = new System.Drawing.Point(123, 20);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(57, 33);
            this.btn3.TabIndex = 0;
            this.btn3.Text = "サ行";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Location = new System.Drawing.Point(67, 20);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(57, 33);
            this.btn2.TabIndex = 0;
            this.btn2.Text = "カ行";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn1
            // 
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Location = new System.Drawing.Point(11, 20);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(57, 33);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "ア行";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(756, 119);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(125, 35);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(764, 457);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(117, 34);
            this.button2.TabIndex = 13;
            this.button2.Text = "キャンセル";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(624, 457);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 34);
            this.button1.TabIndex = 14;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ComboSearch
            // 
            this.ComboSearch.BackColor = System.Drawing.SystemColors.Window;
            this.ComboSearch.Cursor = System.Windows.Forms.Cursors.Default;
            this.ComboSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboSearch.ForeColor = System.Drawing.SystemColors.WindowText;
            this.ComboSearch.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.ComboSearch.Location = new System.Drawing.Point(72, 119);
            this.ComboSearch.Name = "ComboSearch";
            this.ComboSearch.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ComboSearch.Size = new System.Drawing.Size(178, 21);
            this.ComboSearch.TabIndex = 22;
            // 
            // LabelSearch
            // 
            this.LabelSearch.AutoSize = true;
            this.LabelSearch.BackColor = System.Drawing.SystemColors.Control;
            this.LabelSearch.Cursor = System.Windows.Forms.Cursors.Default;
            this.LabelSearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.LabelSearch.Location = new System.Drawing.Point(22, 122);
            this.LabelSearch.Name = "LabelSearch";
            this.LabelSearch.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LabelSearch.Size = new System.Drawing.Size(31, 13);
            this.LabelSearch.TabIndex = 21;
            this.LabelSearch.Text = "検索";
            // 
            // TextSearch
            // 
            this.TextSearch.AcceptsReturn = true;
            this.TextSearch.BackColor = System.Drawing.SystemColors.Window;
            this.TextSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextSearch.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TextSearch.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
            this.TextSearch.Location = new System.Drawing.Point(277, 120);
            this.TextSearch.MaxLength = 0;
            this.TextSearch.Name = "TextSearch";
            this.TextSearch.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TextSearch.Size = new System.Drawing.Size(233, 20);
            this.TextSearch.TabIndex = 24;
            // 
            // ListView
            // 
            this.ListView.BackColor = System.Drawing.SystemColors.Window;
            this.ListView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ListView.ForeColor = System.Drawing.SystemColors.WindowText;
            this.ListView.FullRowSelect = true;
            this.ListView.LabelEdit = true;
            this.ListView.Location = new System.Drawing.Point(27, 160);
            this.ListView.Name = "ListView";
            this.ListView.Size = new System.Drawing.Size(854, 291);
            this.ListView.TabIndex = 26;
            this.ListView.UseCompatibleStateImageBehavior = false;
            this.ListView.View = System.Windows.Forms.View.Details;
            this.ListView.DoubleClick += new System.EventHandler(this.ListView_DoubleClick);
            // 
            // TokuiSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 514);
            this.Controls.Add(this.ListView);
            this.Controls.Add(this.TextSearch);
            this.Controls.Add(this.ComboSearch);
            this.Controls.Add(this.LabelSearch);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "TokuiSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "得意先検索";
            this.Load += new System.EventHandler(this.TokuiSearch_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.ComboBox ComboSearch;
        public System.Windows.Forms.Label LabelSearch;
        public System.Windows.Forms.TextBox TextSearch;
        public System.Windows.Forms.ListView ListView;
    }
}