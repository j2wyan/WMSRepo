﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WMS_V1.UI
{
    public partial class ProductMototyo : Form
    {
        public ProductMototyo()
        {
            InitializeComponent();
        }

        private void gcTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
