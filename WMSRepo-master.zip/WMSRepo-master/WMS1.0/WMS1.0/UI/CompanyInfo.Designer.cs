﻿namespace WMS_V1
{
    partial class CompanyInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.gcTextBox1 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcShortcut1 = new GrapeCity.Win.Editors.GcShortcut(this.components);
            this.gcTextBox2 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox3 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox4 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox5 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox6 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox7 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.gcTextBox8 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox9 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox10 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox11 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox12 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox13 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox14 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcLabel1 = new GrapeCity.Win.Buttons.GcLabel();
            this.gcLabel2 = new GrapeCity.Win.Buttons.GcLabel();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox14)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(436, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(436, 113);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 29);
            this.button2.TabIndex = 0;
            this.button2.Text = "キャンセル";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "会社名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "フリガナ：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "郵便番号：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "住所１：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "住所２：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 12);
            this.label6.TabIndex = 1;
            this.label6.Text = "TEL：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(239, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "FAX：";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(436, 10);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 29);
            this.button3.TabIndex = 0;
            this.button3.Text = "弥生情報取込";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(437, 160);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(105, 29);
            this.button4.TabIndex = 0;
            this.button4.Text = "情報";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // gcTextBox1
            // 
            this.gcTextBox1.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox1.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox1.Location = new System.Drawing.Point(92, 33);
            this.gcTextBox1.Name = "gcTextBox1";
            this.gcShortcut1.SetShortcuts(this.gcTextBox1, new GrapeCity.Win.Editors.ShortcutCollection(new System.Windows.Forms.Keys[] {
                System.Windows.Forms.Keys.F2}, new object[] {
                ((object)(this.gcTextBox1))}, new string[] {
                "ShortcutClear"}));
            this.gcTextBox1.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox1.TabIndex = 2;
            // 
            // gcTextBox2
            // 
            this.gcTextBox2.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox2.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox2.Location = new System.Drawing.Point(92, 52);
            this.gcTextBox2.Name = "gcTextBox2";
            this.gcTextBox2.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox2.TabIndex = 2;
            // 
            // gcTextBox3
            // 
            this.gcTextBox3.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox3.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox3.Location = new System.Drawing.Point(92, 71);
            this.gcTextBox3.Name = "gcTextBox3";
            this.gcTextBox3.Size = new System.Drawing.Size(82, 20);
            this.gcTextBox3.TabIndex = 2;
            // 
            // gcTextBox4
            // 
            this.gcTextBox4.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox4.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox4.Location = new System.Drawing.Point(92, 91);
            this.gcTextBox4.Name = "gcTextBox4";
            this.gcTextBox4.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox4.TabIndex = 2;
            // 
            // gcTextBox5
            // 
            this.gcTextBox5.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox5.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox5.Location = new System.Drawing.Point(92, 111);
            this.gcTextBox5.Name = "gcTextBox5";
            this.gcTextBox5.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox5.TabIndex = 2;
            // 
            // gcTextBox6
            // 
            this.gcTextBox6.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox6.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox6.Location = new System.Drawing.Point(92, 131);
            this.gcTextBox6.Name = "gcTextBox6";
            this.gcTextBox6.Size = new System.Drawing.Size(132, 20);
            this.gcTextBox6.TabIndex = 2;
            // 
            // gcTextBox7
            // 
            this.gcTextBox7.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox7.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox7.Location = new System.Drawing.Point(278, 131);
            this.gcTextBox7.Name = "gcTextBox7";
            this.gcTextBox7.Size = new System.Drawing.Size(132, 20);
            this.gcTextBox7.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "会社名：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "フリガナ：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 230);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "郵便番号：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(43, 250);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "住所１：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(43, 270);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 12);
            this.label12.TabIndex = 1;
            this.label12.Text = "住所２：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(55, 290);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "TEL：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(239, 290);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 12);
            this.label14.TabIndex = 1;
            this.label14.Text = "FAX：";
            // 
            // gcTextBox8
            // 
            this.gcTextBox8.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox8.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox8.Location = new System.Drawing.Point(92, 188);
            this.gcTextBox8.Name = "gcTextBox8";
            this.gcTextBox8.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox8.TabIndex = 2;
            // 
            // gcTextBox9
            // 
            this.gcTextBox9.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox9.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox9.Location = new System.Drawing.Point(92, 207);
            this.gcTextBox9.Name = "gcTextBox9";
            this.gcTextBox9.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox9.TabIndex = 2;
            // 
            // gcTextBox10
            // 
            this.gcTextBox10.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox10.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox10.Location = new System.Drawing.Point(92, 226);
            this.gcTextBox10.Name = "gcTextBox10";
            this.gcTextBox10.Size = new System.Drawing.Size(82, 20);
            this.gcTextBox10.TabIndex = 2;
            // 
            // gcTextBox11
            // 
            this.gcTextBox11.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox11.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox11.Location = new System.Drawing.Point(92, 246);
            this.gcTextBox11.Name = "gcTextBox11";
            this.gcTextBox11.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox11.TabIndex = 2;
            // 
            // gcTextBox12
            // 
            this.gcTextBox12.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox12.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox12.Location = new System.Drawing.Point(92, 266);
            this.gcTextBox12.Name = "gcTextBox12";
            this.gcTextBox12.Size = new System.Drawing.Size(318, 20);
            this.gcTextBox12.TabIndex = 2;
            // 
            // gcTextBox13
            // 
            this.gcTextBox13.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox13.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox13.Location = new System.Drawing.Point(92, 286);
            this.gcTextBox13.Name = "gcTextBox13";
            this.gcTextBox13.Size = new System.Drawing.Size(132, 20);
            this.gcTextBox13.TabIndex = 2;
            // 
            // gcTextBox14
            // 
            this.gcTextBox14.DropDownEditor.ContentAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gcTextBox14.FlatStyle = GrapeCity.Win.Editors.FlatStyleEx.Flat;
            this.gcTextBox14.Location = new System.Drawing.Point(278, 286);
            this.gcTextBox14.Name = "gcTextBox14";
            this.gcTextBox14.Size = new System.Drawing.Size(132, 20);
            this.gcTextBox14.TabIndex = 2;
            // 
            // gcLabel1
            // 
            this.gcLabel1.AutoSize = true;
            this.gcLabel1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcLabel1.Location = new System.Drawing.Point(9, 7);
            this.gcLabel1.Name = "gcLabel1";
            this.gcLabel1.Size = new System.Drawing.Size(65, 16);
            this.gcLabel1.TabIndex = 3;
            this.gcLabel1.Text = "会社情報１";
            this.gcLabel1.TextVAlign = GrapeCity.Win.Common.TextVAlign.Middle;
            // 
            // gcLabel2
            // 
            this.gcLabel2.AutoSize = true;
            this.gcLabel2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcLabel2.Location = new System.Drawing.Point(9, 160);
            this.gcLabel2.Name = "gcLabel2";
            this.gcLabel2.Size = new System.Drawing.Size(65, 16);
            this.gcLabel2.TabIndex = 3;
            this.gcLabel2.Text = "会社情報２";
            this.gcLabel2.TextVAlign = GrapeCity.Win.Common.TextVAlign.Middle;
            // 
            // CompanyInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 320);
            this.ControlBox = false;
            this.Controls.Add(this.gcLabel2);
            this.Controls.Add(this.gcLabel1);
            this.Controls.Add(this.gcTextBox14);
            this.Controls.Add(this.gcTextBox13);
            this.Controls.Add(this.gcTextBox7);
            this.Controls.Add(this.gcTextBox12);
            this.Controls.Add(this.gcTextBox6);
            this.Controls.Add(this.gcTextBox11);
            this.Controls.Add(this.gcTextBox5);
            this.Controls.Add(this.gcTextBox10);
            this.Controls.Add(this.gcTextBox4);
            this.Controls.Add(this.gcTextBox9);
            this.Controls.Add(this.gcTextBox3);
            this.Controls.Add(this.gcTextBox8);
            this.Controls.Add(this.gcTextBox2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.gcTextBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "CompanyInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "会社情報";
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox14)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox1;
        private GrapeCity.Win.Editors.GcShortcut gcShortcut1;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox2;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox3;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox4;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox5;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox6;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox8;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox9;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox10;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox11;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox12;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox13;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox14;
        private GrapeCity.Win.Buttons.GcLabel gcLabel1;
        private GrapeCity.Win.Buttons.GcLabel gcLabel2;
    }
}