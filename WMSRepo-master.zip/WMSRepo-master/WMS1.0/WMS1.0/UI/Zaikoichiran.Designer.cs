﻿namespace WMS_V1.UI
{
    partial class Zaikoichiran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            GrapeCity.Win.Editors.Fields.DateYearField dateYearField1 = new GrapeCity.Win.Editors.Fields.DateYearField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField1 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateMonthField dateMonthField1 = new GrapeCity.Win.Editors.Fields.DateMonthField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField2 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateDayField dateDayField1 = new GrapeCity.Win.Editors.Fields.DateDayField();
            this.label1 = new System.Windows.Forms.Label();
            this.gcDate1 = new GrapeCity.Win.Editors.GcDate(this.components);
            this.dropDownButton1 = new GrapeCity.Win.Editors.DropDownButton();
            this.gcShortcut1 = new GrapeCity.Win.Editors.GcShortcut(this.components);
            this.gcComboBox1 = new GrapeCity.Win.Editors.GcComboBox(this.components);
            this.dropDownButton2 = new GrapeCity.Win.Editors.DropDownButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.gcComboBox2 = new GrapeCity.Win.Editors.GcComboBox(this.components);
            this.dropDownButton3 = new GrapeCity.Win.Editors.DropDownButton();
            this.gcFunctionKey1 = new GrapeCity.Win.Bars.GcFunctionKey();
            this.functionKeyButton1 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton2 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton3 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton4 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton5 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton6 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton7 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton8 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton9 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton10 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton11 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton12 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.label4 = new System.Windows.Forms.Label();
            this.gcComboBox3 = new GrapeCity.Win.Editors.GcComboBox(this.components);
            this.dropDownButton4 = new GrapeCity.Win.Editors.DropDownButton();
            this.gcMultiRow1 = new GrapeCity.Win.MultiRow.GcMultiRow();
            this.tempZaikoichiran1 = new WMS_V1.UI.TempZaikoichiran();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcComboBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "在庫日付：";
            // 
            // gcDate1
            // 
            dateLiteralField1.Text = "/";
            dateLiteralField2.Text = "/";
            this.gcDate1.Fields.AddRange(new GrapeCity.Win.Editors.Fields.DateField[] {
            dateYearField1,
            dateLiteralField1,
            dateMonthField1,
            dateLiteralField2,
            dateDayField1});
            this.gcDate1.Location = new System.Drawing.Point(77, 82);
            this.gcDate1.Name = "gcDate1";
            this.gcShortcut1.SetShortcuts(this.gcDate1, new GrapeCity.Win.Editors.ShortcutCollection(new System.Windows.Forms.Keys[] {
                System.Windows.Forms.Keys.F2,
                System.Windows.Forms.Keys.F5,
                ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Return)))}, new object[] {
                ((object)(this.gcDate1)),
                ((object)(this.gcDate1)),
                ((object)(this.gcDate1))}, new string[] {
                "ShortcutClear",
                "SetNow",
                "ApplyRecommendedValue"}));
            this.gcDate1.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton1});
            this.gcDate1.Size = new System.Drawing.Size(120, 20);
            this.gcDate1.TabIndex = 2;
            this.gcDate1.Value = new System.DateTime(2017, 8, 23, 0, 0, 0, 0);
            // 
            // dropDownButton1
            // 
            this.dropDownButton1.Name = "dropDownButton1";
            // 
            // gcComboBox1
            // 
            this.gcComboBox1.ListHeaderPane.Height = 19;
            this.gcComboBox1.Location = new System.Drawing.Point(77, 58);
            this.gcComboBox1.Name = "gcComboBox1";
            this.gcShortcut1.SetShortcuts(this.gcComboBox1, new GrapeCity.Win.Editors.ShortcutCollection(new System.Windows.Forms.Keys[] {
                System.Windows.Forms.Keys.F2,
                ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Return)))}, new object[] {
                ((object)(this.gcComboBox1)),
                ((object)(this.gcComboBox1))}, new string[] {
                "ShortcutClear",
                "ApplyRecommendedValue"}));
            this.gcComboBox1.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton2});
            this.gcComboBox1.Size = new System.Drawing.Size(251, 20);
            this.gcComboBox1.TabIndex = 3;
            // 
            // dropDownButton2
            // 
            this.dropDownButton2.Name = "dropDownButton2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "分類：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(334, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "～";
            // 
            // gcComboBox2
            // 
            this.gcComboBox2.ListHeaderPane.Height = 19;
            this.gcComboBox2.Location = new System.Drawing.Point(357, 59);
            this.gcComboBox2.Name = "gcComboBox2";
            this.gcComboBox2.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton3});
            this.gcComboBox2.Size = new System.Drawing.Size(251, 20);
            this.gcComboBox2.TabIndex = 3;
            // 
            // dropDownButton3
            // 
            this.dropDownButton3.Name = "dropDownButton3";
            // 
            // gcFunctionKey1
            // 
            this.gcFunctionKey1.Dock = System.Windows.Forms.DockStyle.Top;
            this.gcFunctionKey1.FunctionKeyButtons.AddRange(new GrapeCity.Win.Bars.FunctionKeyButton[] {
            this.functionKeyButton1,
            this.functionKeyButton2,
            this.functionKeyButton3,
            this.functionKeyButton4,
            this.functionKeyButton5,
            this.functionKeyButton6,
            this.functionKeyButton7,
            this.functionKeyButton8,
            this.functionKeyButton9,
            this.functionKeyButton10,
            this.functionKeyButton11,
            this.functionKeyButton12});
            this.gcFunctionKey1.Location = new System.Drawing.Point(0, 0);
            this.gcFunctionKey1.Name = "gcFunctionKey1";
            this.gcFunctionKey1.Size = new System.Drawing.Size(840, 25);
            this.gcFunctionKey1.TabIndex = 4;
            this.gcFunctionKey1.Text = "gcFunctionKey1";
            // 
            // functionKeyButton1
            // 
            this.functionKeyButton1.FunctionKey = System.Windows.Forms.Keys.F1;
            this.functionKeyButton1.Name = "functionKeyButton1";
            this.functionKeyButton1.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton1.Text = "Function1";
            // 
            // functionKeyButton2
            // 
            this.functionKeyButton2.FunctionKey = System.Windows.Forms.Keys.F2;
            this.functionKeyButton2.Name = "functionKeyButton2";
            this.functionKeyButton2.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton2.Text = "Function2";
            // 
            // functionKeyButton3
            // 
            this.functionKeyButton3.FunctionKey = System.Windows.Forms.Keys.F3;
            this.functionKeyButton3.Name = "functionKeyButton3";
            this.functionKeyButton3.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton3.Text = "Function3";
            // 
            // functionKeyButton4
            // 
            this.functionKeyButton4.FunctionKey = System.Windows.Forms.Keys.F4;
            this.functionKeyButton4.Name = "functionKeyButton4";
            this.functionKeyButton4.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton4.Text = "Function4";
            // 
            // functionKeyButton5
            // 
            this.functionKeyButton5.FunctionKey = System.Windows.Forms.Keys.F5;
            this.functionKeyButton5.Name = "functionKeyButton5";
            this.functionKeyButton5.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton5.Text = "Function5";
            // 
            // functionKeyButton6
            // 
            this.functionKeyButton6.FunctionKey = System.Windows.Forms.Keys.F6;
            this.functionKeyButton6.Name = "functionKeyButton6";
            this.functionKeyButton6.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton6.Text = "Function6";
            // 
            // functionKeyButton7
            // 
            this.functionKeyButton7.FunctionKey = System.Windows.Forms.Keys.F7;
            this.functionKeyButton7.Name = "functionKeyButton7";
            this.functionKeyButton7.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton7.Text = "Function7";
            // 
            // functionKeyButton8
            // 
            this.functionKeyButton8.FunctionKey = System.Windows.Forms.Keys.F8;
            this.functionKeyButton8.Name = "functionKeyButton8";
            this.functionKeyButton8.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton8.Text = "Function8";
            // 
            // functionKeyButton9
            // 
            this.functionKeyButton9.FunctionKey = System.Windows.Forms.Keys.F9;
            this.functionKeyButton9.Name = "functionKeyButton9";
            this.functionKeyButton9.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton9.Text = "Function9";
            // 
            // functionKeyButton10
            // 
            this.functionKeyButton10.FunctionKey = System.Windows.Forms.Keys.F10;
            this.functionKeyButton10.Name = "functionKeyButton10";
            this.functionKeyButton10.Size = new System.Drawing.Size(23, 23);
            this.functionKeyButton10.Text = "Function10";
            // 
            // functionKeyButton11
            // 
            this.functionKeyButton11.FunctionKey = System.Windows.Forms.Keys.F11;
            this.functionKeyButton11.Name = "functionKeyButton11";
            this.functionKeyButton11.Size = new System.Drawing.Size(23, 23);
            this.functionKeyButton11.Text = "Function11";
            // 
            // functionKeyButton12
            // 
            this.functionKeyButton12.FunctionKey = System.Windows.Forms.Keys.F12;
            this.functionKeyButton12.Name = "functionKeyButton12";
            this.functionKeyButton12.Size = new System.Drawing.Size(23, 23);
            this.functionKeyButton12.Text = "Function12";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "倉庫：";
            // 
            // gcComboBox3
            // 
            this.gcComboBox3.ListHeaderPane.Height = 19;
            this.gcComboBox3.Location = new System.Drawing.Point(77, 32);
            this.gcComboBox3.Name = "gcComboBox3";
            this.gcComboBox3.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton4});
            this.gcComboBox3.Size = new System.Drawing.Size(251, 20);
            this.gcComboBox3.TabIndex = 3;
            // 
            // dropDownButton4
            // 
            this.dropDownButton4.Name = "dropDownButton4";
            // 
            // gcMultiRow1
            // 
            this.gcMultiRow1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gcMultiRow1.Location = new System.Drawing.Point(12, 108);
            this.gcMultiRow1.Name = "gcMultiRow1";
            this.gcMultiRow1.Size = new System.Drawing.Size(816, 662);
            this.gcMultiRow1.TabIndex = 0;
            this.gcMultiRow1.Template = this.tempZaikoichiran1;
            this.gcMultiRow1.Text = "gcMultiRow1";
            // 
            // Zaikoichiran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.ClientSize = new System.Drawing.Size(840, 782);
            this.Controls.Add(this.gcFunctionKey1);
            this.Controls.Add(this.gcComboBox2);
            this.Controls.Add(this.gcComboBox3);
            this.Controls.Add(this.gcComboBox1);
            this.Controls.Add(this.gcDate1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gcMultiRow1);
            this.Name = "Zaikoichiran";
            this.Text = "在庫一覧";
            this.Load += new System.EventHandler(this.Zaikoichiran_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gcDate1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcComboBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GrapeCity.Win.MultiRow.GcMultiRow gcMultiRow1;
        private TempZaikoichiran tempZaikoichiran1;
        private System.Windows.Forms.Label label1;
        private GrapeCity.Win.Editors.GcDate gcDate1;
        private GrapeCity.Win.Editors.GcShortcut gcShortcut1;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton1;
        private System.Windows.Forms.Label label2;
        private GrapeCity.Win.Editors.GcComboBox gcComboBox1;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton2;
        private System.Windows.Forms.Label label3;
        private GrapeCity.Win.Editors.GcComboBox gcComboBox2;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton3;
        private GrapeCity.Win.Bars.GcFunctionKey gcFunctionKey1;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton1;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton2;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton3;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton4;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton5;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton6;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton7;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton8;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton9;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton10;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton11;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton12;
        private System.Windows.Forms.Label label4;
        private GrapeCity.Win.Editors.GcComboBox gcComboBox3;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton4;
    }
}