﻿namespace WMS_V1
{
    partial class Navigation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gcShortcut1 = new GrapeCity.Win.Editors.GcShortcut(this.components);
            this.gcTabControl1 = new GrapeCity.Win.Containers.GcTabControl();
            this.gcTabPage1 = new GrapeCity.Win.Containers.GcTabPage();
            this.gcButton2 = new GrapeCity.Win.Buttons.GcButton();
            this.gcTabPage2 = new GrapeCity.Win.Containers.GcTabPage();
            this.gcTabPage3 = new GrapeCity.Win.Containers.GcTabPage();
            this.gcTabPage4 = new GrapeCity.Win.Containers.GcTabPage();
            this.gcTabPage5 = new GrapeCity.Win.Containers.GcTabPage();
            this.gcButton1 = new GrapeCity.Win.Buttons.GcButton();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gcTabControl1)).BeginInit();
            this.gcTabControl1.SuspendLayout();
            this.gcTabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gcTabControl1
            // 
            this.gcTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.gcTabControl1.Appearance = GrapeCity.Win.Containers.TabAppearance.Rounded;
            this.gcTabControl1.Flat = true;
            this.gcTabControl1.Location = new System.Drawing.Point(3, 47);
            this.gcTabControl1.Name = "gcTabControl1";
            this.gcTabControl1.Size = new System.Drawing.Size(890, 368);
            this.gcTabControl1.SizeMode = GrapeCity.Win.Containers.TabSizeMode.Fixed;
            this.gcTabControl1.TabIndex = 0;
            this.gcTabControl1.TabPages.Add(this.gcTabPage1);
            this.gcTabControl1.TabPages.Add(this.gcTabPage2);
            this.gcTabControl1.TabPages.Add(this.gcTabPage3);
            this.gcTabControl1.TabPages.Add(this.gcTabPage4);
            this.gcTabControl1.TabPages.Add(this.gcTabPage5);
            this.gcTabControl1.TextOrientation = GrapeCity.Win.Common.TextOrientation.VerticalFarEast;
            // 
            // gcTabPage1
            // 
            this.gcTabPage1.Controls.Add(this.gcButton2);
            this.gcTabPage1.GradientEffect = new GrapeCity.Win.Common.GradientEffect(GrapeCity.Win.Common.GradientStyle.Horizontal, GrapeCity.Win.Common.GradientDirection.NotSet, System.Drawing.Color.FloralWhite, System.Drawing.Color.White);
            this.gcTabPage1.Location = new System.Drawing.Point(53, 4);
            this.gcTabPage1.Name = "gcTabPage1";
            this.gcTabPage1.Size = new System.Drawing.Size(833, 360);
            this.gcTabPage1.TabIndex = 0;
            this.gcTabPage1.TabStyle = new GrapeCity.Win.Containers.TabStyle(System.Drawing.Color.Empty, System.Drawing.Color.Empty, System.Drawing.Color.Empty, null, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Common.TextHAlign.NotSet, GrapeCity.Win.Common.TextVAlign.NotSet, GrapeCity.Win.Common.ImageAlign.NotSet, GrapeCity.Win.Common.TextWrapMode.NotSet, GrapeCity.Win.Common.EllipsisMode.None, null, null, new GrapeCity.Win.Common.Margins(0, 0, 0, 0), new System.Drawing.Size(100, 50), new System.Drawing.Size(0, 0));
            this.gcTabPage1.Text = "出荷";
            this.gcTabPage1.UseVisualStyleBackColor = true;
            // 
            // gcButton2
            // 
            this.gcButton2.BackColor = System.Drawing.Color.White;
            this.gcButton2.FlatAppearance.BorderColor = System.Drawing.Color.Sienna;
            this.gcButton2.FlatStyle = GrapeCity.Win.Common.FlatStyleEx.Flat;
            this.gcButton2.ForeColor = System.Drawing.Color.Firebrick;
            this.gcButton2.GradientEffect = new GrapeCity.Win.Common.GradientEffect(GrapeCity.Win.Common.GradientStyle.Horizontal, GrapeCity.Win.Common.GradientDirection.NotSet, System.Drawing.Color.Azure, System.Drawing.Color.White);
            this.gcButton2.Location = new System.Drawing.Point(36, 33);
            this.gcButton2.Name = "gcButton2";
            this.gcButton2.Size = new System.Drawing.Size(207, 46);
            this.gcButton2.TabIndex = 0;
            this.gcButton2.Text = "受注伝票";
            this.gcButton2.TextAppearance = new GrapeCity.Win.Buttons.OrientationTextAppearance(GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Common.TextOrientation.NotSet, GrapeCity.Win.Buttons.TextAdjustment.None);
            this.gcButton2.UseVisualStyleBackColor = false;
            // 
            // gcTabPage2
            // 
            this.gcTabPage2.Location = new System.Drawing.Point(53, 4);
            this.gcTabPage2.Name = "gcTabPage2";
            this.gcTabPage2.Size = new System.Drawing.Size(833, 360);
            this.gcTabPage2.TabIndex = 1;
            this.gcTabPage2.TabStyle = new GrapeCity.Win.Containers.TabStyle(System.Drawing.Color.Empty, System.Drawing.Color.Empty, System.Drawing.Color.Empty, null, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Common.TextHAlign.NotSet, GrapeCity.Win.Common.TextVAlign.NotSet, GrapeCity.Win.Common.ImageAlign.NotSet, GrapeCity.Win.Common.TextWrapMode.NotSet, GrapeCity.Win.Common.EllipsisMode.None, null, null, new GrapeCity.Win.Common.Margins(0, 0, 0, 0), new System.Drawing.Size(100, 50), new System.Drawing.Size(0, 0));
            this.gcTabPage2.Text = "入荷";
            this.gcTabPage2.UseVisualStyleBackColor = true;
            // 
            // gcTabPage3
            // 
            this.gcTabPage3.Location = new System.Drawing.Point(53, 4);
            this.gcTabPage3.Name = "gcTabPage3";
            this.gcTabPage3.Size = new System.Drawing.Size(833, 360);
            this.gcTabPage3.TabIndex = 2;
            this.gcTabPage3.TabStyle = new GrapeCity.Win.Containers.TabStyle(System.Drawing.Color.Empty, System.Drawing.Color.Empty, System.Drawing.Color.Empty, null, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Common.TextHAlign.NotSet, GrapeCity.Win.Common.TextVAlign.NotSet, GrapeCity.Win.Common.ImageAlign.NotSet, GrapeCity.Win.Common.TextWrapMode.NotSet, GrapeCity.Win.Common.EllipsisMode.None, null, null, new GrapeCity.Win.Common.Margins(0, 0, 0, 0), new System.Drawing.Size(100, 50), new System.Drawing.Size(0, 0));
            this.gcTabPage3.Text = "在庫";
            this.gcTabPage3.UseVisualStyleBackColor = true;
            // 
            // gcTabPage4
            // 
            this.gcTabPage4.Location = new System.Drawing.Point(53, 4);
            this.gcTabPage4.Name = "gcTabPage4";
            this.gcTabPage4.Size = new System.Drawing.Size(833, 360);
            this.gcTabPage4.TabIndex = 3;
            this.gcTabPage4.TabStyle = new GrapeCity.Win.Containers.TabStyle(System.Drawing.Color.Empty, System.Drawing.Color.Empty, System.Drawing.Color.Empty, null, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Common.TextHAlign.NotSet, GrapeCity.Win.Common.TextVAlign.NotSet, GrapeCity.Win.Common.ImageAlign.NotSet, GrapeCity.Win.Common.TextWrapMode.NotSet, GrapeCity.Win.Common.EllipsisMode.None, null, null, new GrapeCity.Win.Common.Margins(0, 0, 0, 0), new System.Drawing.Size(100, 50), new System.Drawing.Size(0, 0));
            this.gcTabPage4.Text = "レポート";
            this.gcTabPage4.UseVisualStyleBackColor = true;
            // 
            // gcTabPage5
            // 
            this.gcTabPage5.Location = new System.Drawing.Point(53, 4);
            this.gcTabPage5.Name = "gcTabPage5";
            this.gcTabPage5.Size = new System.Drawing.Size(833, 360);
            this.gcTabPage5.TabIndex = 4;
            this.gcTabPage5.TabStyle = new GrapeCity.Win.Containers.TabStyle(System.Drawing.Color.Empty, System.Drawing.Color.Empty, System.Drawing.Color.Empty, null, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Common.TextHAlign.NotSet, GrapeCity.Win.Common.TextVAlign.NotSet, GrapeCity.Win.Common.ImageAlign.NotSet, GrapeCity.Win.Common.TextWrapMode.NotSet, GrapeCity.Win.Common.EllipsisMode.None, null, null, new GrapeCity.Win.Common.Margins(0, 0, 0, 0), new System.Drawing.Size(100, 50), new System.Drawing.Size(0, 0));
            this.gcTabPage5.Text = "設定";
            this.gcTabPage5.UseVisualStyleBackColor = true;
            // 
            // gcButton1
            // 
            this.gcButton1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gcButton1.Font = new System.Drawing.Font("メイリオ", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gcButton1.ForeColor = System.Drawing.Color.Navy;
            this.gcButton1.GradientEffect = new GrapeCity.Win.Common.GradientEffect(GrapeCity.Win.Common.GradientStyle.Horizontal, GrapeCity.Win.Common.GradientDirection.Forward, System.Drawing.Color.Silver, System.Drawing.Color.LightGray);
            this.gcButton1.Location = new System.Drawing.Point(790, 425);
            this.gcButton1.Name = "gcButton1";
            this.gcButton1.Size = new System.Drawing.Size(103, 52);
            this.gcButton1.TabIndex = 1;
            this.gcButton1.Text = "閉じる";
            this.gcButton1.UseVisualStyleBackColor = true;
            this.gcButton1.Click += new System.EventHandler(this.gcButton1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.richTextBox1.Location = new System.Drawing.Point(3, 421);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(780, 61);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // Navigation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(900, 485);
            this.ControlBox = false;
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.gcButton1);
            this.Controls.Add(this.gcTabControl1);
            this.MaximizeBox = false;
            this.Name = "Navigation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ナビゲーション";
            ((System.ComponentModel.ISupportInitialize)(this.gcTabControl1)).EndInit();
            this.gcTabControl1.ResumeLayout(false);
            this.gcTabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private GrapeCity.Win.Editors.GcShortcut gcShortcut1;
        private GrapeCity.Win.Containers.GcTabControl gcTabControl1;
        private GrapeCity.Win.Containers.GcTabPage gcTabPage1;
        private GrapeCity.Win.Containers.GcTabPage gcTabPage2;
        private GrapeCity.Win.Containers.GcTabPage gcTabPage3;
        private GrapeCity.Win.Containers.GcTabPage gcTabPage4;
        private GrapeCity.Win.Containers.GcTabPage gcTabPage5;
        private GrapeCity.Win.Buttons.GcButton gcButton1;
        private GrapeCity.Win.Buttons.GcButton gcButton2;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}