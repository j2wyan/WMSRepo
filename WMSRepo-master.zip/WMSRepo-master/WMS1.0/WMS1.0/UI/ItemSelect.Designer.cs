﻿namespace WMS_V1
{
    partial class ItemSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gcButton5 = new GrapeCity.Win.Buttons.GcButton();
            this.gcButton4 = new GrapeCity.Win.Buttons.GcButton();
            this.gcButton3 = new GrapeCity.Win.Buttons.GcButton();
            this.gcButton2 = new GrapeCity.Win.Buttons.GcButton();
            this.gcButton1 = new GrapeCity.Win.Buttons.GcButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(75, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(378, 19);
            this.textBox1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "商品コード：";
            // 
            // gcButton5
            // 
            this.gcButton5.Location = new System.Drawing.Point(660, 44);
            this.gcButton5.Name = "gcButton5";
            this.gcButton5.Size = new System.Drawing.Size(62, 38);
            this.gcButton5.TabIndex = 7;
            this.gcButton5.Text = "分類5";
            this.gcButton5.UseVisualStyleBackColor = true;
            // 
            // gcButton4
            // 
            this.gcButton4.Location = new System.Drawing.Point(579, 44);
            this.gcButton4.Name = "gcButton4";
            this.gcButton4.Size = new System.Drawing.Size(62, 38);
            this.gcButton4.TabIndex = 7;
            this.gcButton4.Text = "分類4";
            this.gcButton4.UseVisualStyleBackColor = true;
            // 
            // gcButton3
            // 
            this.gcButton3.Location = new System.Drawing.Point(734, 2);
            this.gcButton3.Name = "gcButton3";
            this.gcButton3.Size = new System.Drawing.Size(62, 38);
            this.gcButton3.TabIndex = 7;
            this.gcButton3.Text = "分類3";
            this.gcButton3.UseVisualStyleBackColor = true;
            // 
            // gcButton2
            // 
            this.gcButton2.Location = new System.Drawing.Point(660, 2);
            this.gcButton2.Name = "gcButton2";
            this.gcButton2.Size = new System.Drawing.Size(62, 38);
            this.gcButton2.TabIndex = 7;
            this.gcButton2.Text = "分類2";
            this.gcButton2.UseVisualStyleBackColor = true;
            // 
            // gcButton1
            // 
            this.gcButton1.Location = new System.Drawing.Point(579, 2);
            this.gcButton1.Name = "gcButton1";
            this.gcButton1.Size = new System.Drawing.Size(62, 38);
            this.gcButton1.TabIndex = 7;
            this.gcButton1.Text = "分類1";
            this.gcButton1.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(579, 86);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(240, 304);
            this.listBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(75, 58);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(378, 19);
            this.textBox2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "商品名称：";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(469, 46);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 34);
            this.button3.TabIndex = 4;
            this.button3.Text = "検索";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(12, 86);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(548, 341);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(734, 398);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 29);
            this.button2.TabIndex = 1;
            this.button2.Text = "キャンセル";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(627, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ItemSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(833, 439);
            this.ControlBox = false;
            this.Controls.Add(this.gcButton5);
            this.Controls.Add(this.gcButton4);
            this.Controls.Add(this.gcButton3);
            this.Controls.Add(this.gcButton2);
            this.Controls.Add(this.gcButton1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "ItemSelect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "商品参照[Item Select]";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private GrapeCity.Win.Buttons.GcButton gcButton5;
        private GrapeCity.Win.Buttons.GcButton gcButton4;
        private GrapeCity.Win.Buttons.GcButton gcButton3;
        private GrapeCity.Win.Buttons.GcButton gcButton2;
        private GrapeCity.Win.Buttons.GcButton gcButton1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}