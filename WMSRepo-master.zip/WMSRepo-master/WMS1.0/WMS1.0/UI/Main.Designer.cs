﻿namespace WMS_V1
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.開くToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.開くToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.基本情報ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.事業所情報ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ユーザー管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.バックアップToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.復元ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.終了ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.台帳ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品台帳ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品リストToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品価格表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品元帳ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出荷処理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.受注伝票ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.受注一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.売上一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.入荷処理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.発注伝票ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.在庫管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.委託伝票ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.委託伝票一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.委託棚卸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.在庫一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.棚卸処理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.生産管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生産伝票ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.集計ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出荷実績一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品出荷実績推移表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ウィンドウToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ヘルプToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ナビゲーターToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.マニュアルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.バージョンToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.デザイナーToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.発注伝票ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.生産管理表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.債権管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.売掛残高一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.入金一括登録ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルToolStripMenuItem,
            this.台帳ToolStripMenuItem,
            this.出荷処理ToolStripMenuItem,
            this.入荷処理ToolStripMenuItem,
            this.在庫管理ToolStripMenuItem,
            this.集計ToolStripMenuItem,
            this.ウィンドウToolStripMenuItem,
            this.ヘルプToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(829, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルToolStripMenuItem
            // 
            this.ファイルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.開くToolStripMenuItem,
            this.開くToolStripMenuItem1,
            this.toolStripSeparator5,
            this.基本情報ToolStripMenuItem,
            this.toolStripSeparator1,
            this.バックアップToolStripMenuItem,
            this.復元ToolStripMenuItem,
            this.toolStripSeparator2,
            this.終了ToolStripMenuItem});
            this.ファイルToolStripMenuItem.Name = "ファイルToolStripMenuItem";
            this.ファイルToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.ファイルToolStripMenuItem.Text = "ファイル";
            // 
            // 開くToolStripMenuItem
            // 
            this.開くToolStripMenuItem.Name = "開くToolStripMenuItem";
            this.開くToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.開くToolStripMenuItem.Text = "新規";
            // 
            // 開くToolStripMenuItem1
            // 
            this.開くToolStripMenuItem1.Name = "開くToolStripMenuItem1";
            this.開くToolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
            this.開くToolStripMenuItem1.Text = "開く";
            this.開くToolStripMenuItem1.Click += new System.EventHandler(this.開くToolStripMenuItem1_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(124, 6);
            // 
            // 基本情報ToolStripMenuItem
            // 
            this.基本情報ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.事業所情報ToolStripMenuItem,
            this.ユーザー管理ToolStripMenuItem});
            this.基本情報ToolStripMenuItem.Name = "基本情報ToolStripMenuItem";
            this.基本情報ToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.基本情報ToolStripMenuItem.Text = "基本情報";
            // 
            // 事業所情報ToolStripMenuItem
            // 
            this.事業所情報ToolStripMenuItem.Name = "事業所情報ToolStripMenuItem";
            this.事業所情報ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.事業所情報ToolStripMenuItem.Text = "事業所情報";
            this.事業所情報ToolStripMenuItem.Click += new System.EventHandler(this.事業所情報ToolStripMenuItem_Click);
            // 
            // ユーザー管理ToolStripMenuItem
            // 
            this.ユーザー管理ToolStripMenuItem.Name = "ユーザー管理ToolStripMenuItem";
            this.ユーザー管理ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.ユーザー管理ToolStripMenuItem.Text = "ユーザー管理";
            this.ユーザー管理ToolStripMenuItem.Click += new System.EventHandler(this.ユーザー管理ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(124, 6);
            // 
            // バックアップToolStripMenuItem
            // 
            this.バックアップToolStripMenuItem.Name = "バックアップToolStripMenuItem";
            this.バックアップToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.バックアップToolStripMenuItem.Text = "バックアップ";
            // 
            // 復元ToolStripMenuItem
            // 
            this.復元ToolStripMenuItem.Name = "復元ToolStripMenuItem";
            this.復元ToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.復元ToolStripMenuItem.Text = "復元";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(124, 6);
            // 
            // 終了ToolStripMenuItem
            // 
            this.終了ToolStripMenuItem.Name = "終了ToolStripMenuItem";
            this.終了ToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.終了ToolStripMenuItem.Text = "終了";
            this.終了ToolStripMenuItem.Click += new System.EventHandler(this.終了ToolStripMenuItem_Click);
            // 
            // 台帳ToolStripMenuItem
            // 
            this.台帳ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.商品台帳ToolStripMenuItem,
            this.商品リストToolStripMenuItem,
            this.商品価格表ToolStripMenuItem,
            this.商品元帳ToolStripMenuItem,
            this.toolStripSeparator7,
            this.デザイナーToolStripMenuItem});
            this.台帳ToolStripMenuItem.Name = "台帳ToolStripMenuItem";
            this.台帳ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.台帳ToolStripMenuItem.Text = "台帳";
            // 
            // 商品台帳ToolStripMenuItem
            // 
            this.商品台帳ToolStripMenuItem.Name = "商品台帳ToolStripMenuItem";
            this.商品台帳ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.商品台帳ToolStripMenuItem.Text = "商品台帳";
            this.商品台帳ToolStripMenuItem.Click += new System.EventHandler(this.商品台帳ToolStripMenuItem_Click);
            // 
            // 商品リストToolStripMenuItem
            // 
            this.商品リストToolStripMenuItem.Name = "商品リストToolStripMenuItem";
            this.商品リストToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.商品リストToolStripMenuItem.Text = "商品リスト";
            this.商品リストToolStripMenuItem.Click += new System.EventHandler(this.商品リストToolStripMenuItem_Click);
            // 
            // 商品価格表ToolStripMenuItem
            // 
            this.商品価格表ToolStripMenuItem.Name = "商品価格表ToolStripMenuItem";
            this.商品価格表ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.商品価格表ToolStripMenuItem.Text = "商品価格表";
            this.商品価格表ToolStripMenuItem.Click += new System.EventHandler(this.商品価格表ToolStripMenuItem_Click);
            // 
            // 商品元帳ToolStripMenuItem
            // 
            this.商品元帳ToolStripMenuItem.Name = "商品元帳ToolStripMenuItem";
            this.商品元帳ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.商品元帳ToolStripMenuItem.Text = "商品元帳";
            this.商品元帳ToolStripMenuItem.Click += new System.EventHandler(this.商品元帳ToolStripMenuItem_Click);
            // 
            // 出荷処理ToolStripMenuItem
            // 
            this.出荷処理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.受注伝票ToolStripMenuItem,
            this.受注一覧ToolStripMenuItem,
            this.toolStripSeparator4,
            this.toolStripMenuItem1,
            this.売上一覧ToolStripMenuItem,
            this.toolStripSeparator9,
            this.債権管理ToolStripMenuItem});
            this.出荷処理ToolStripMenuItem.Name = "出荷処理ToolStripMenuItem";
            this.出荷処理ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.出荷処理ToolStripMenuItem.Text = "出荷処理";
            // 
            // 受注伝票ToolStripMenuItem
            // 
            this.受注伝票ToolStripMenuItem.Name = "受注伝票ToolStripMenuItem";
            this.受注伝票ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.受注伝票ToolStripMenuItem.Text = "受注伝票";
            this.受注伝票ToolStripMenuItem.Click += new System.EventHandler(this.受注伝票ToolStripMenuItem_Click);
            // 
            // 受注一覧ToolStripMenuItem
            // 
            this.受注一覧ToolStripMenuItem.Name = "受注一覧ToolStripMenuItem";
            this.受注一覧ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.受注一覧ToolStripMenuItem.Text = "受注一覧";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(119, 6);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 22);
            this.toolStripMenuItem1.Text = "売上伝票";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // 売上一覧ToolStripMenuItem
            // 
            this.売上一覧ToolStripMenuItem.Name = "売上一覧ToolStripMenuItem";
            this.売上一覧ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.売上一覧ToolStripMenuItem.Text = "売上一覧";
            // 
            // 入荷処理ToolStripMenuItem
            // 
            this.入荷処理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.発注伝票ToolStripMenuItem});
            this.入荷処理ToolStripMenuItem.Name = "入荷処理ToolStripMenuItem";
            this.入荷処理ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.入荷処理ToolStripMenuItem.Text = "入荷処理";
            // 
            // 発注伝票ToolStripMenuItem
            // 
            this.発注伝票ToolStripMenuItem.Name = "発注伝票ToolStripMenuItem";
            this.発注伝票ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.発注伝票ToolStripMenuItem.Text = "発注伝票";
            // 
            // 在庫管理ToolStripMenuItem
            // 
            this.在庫管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.委託伝票ToolStripMenuItem,
            this.委託伝票一覧ToolStripMenuItem,
            this.toolStripMenuItem3,
            this.委託棚卸ToolStripMenuItem,
            this.toolStripSeparator3,
            this.在庫一覧ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.棚卸処理ToolStripMenuItem,
            this.toolStripSeparator6,
            this.生産管理ToolStripMenuItem});
            this.在庫管理ToolStripMenuItem.Name = "在庫管理ToolStripMenuItem";
            this.在庫管理ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.在庫管理ToolStripMenuItem.Text = "在庫管理";
            // 
            // 委託伝票ToolStripMenuItem
            // 
            this.委託伝票ToolStripMenuItem.Name = "委託伝票ToolStripMenuItem";
            this.委託伝票ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.委託伝票ToolStripMenuItem.Text = "委託伝票";
            this.委託伝票ToolStripMenuItem.Click += new System.EventHandler(this.委託伝票ToolStripMenuItem_Click);
            // 
            // 委託伝票一覧ToolStripMenuItem
            // 
            this.委託伝票一覧ToolStripMenuItem.Name = "委託伝票一覧ToolStripMenuItem";
            this.委託伝票一覧ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.委託伝票一覧ToolStripMenuItem.Text = "委託伝票一覧";
            // 
            // 委託棚卸ToolStripMenuItem
            // 
            this.委託棚卸ToolStripMenuItem.Name = "委託棚卸ToolStripMenuItem";
            this.委託棚卸ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.委託棚卸ToolStripMenuItem.Text = "委託棚卸";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(143, 6);
            // 
            // 在庫一覧ToolStripMenuItem
            // 
            this.在庫一覧ToolStripMenuItem.Name = "在庫一覧ToolStripMenuItem";
            this.在庫一覧ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.在庫一覧ToolStripMenuItem.Text = "在庫一覧";
            this.在庫一覧ToolStripMenuItem.Click += new System.EventHandler(this.在庫一覧ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(146, 22);
            this.toolStripMenuItem2.Text = "在庫推移表";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // 棚卸処理ToolStripMenuItem
            // 
            this.棚卸処理ToolStripMenuItem.Name = "棚卸処理ToolStripMenuItem";
            this.棚卸処理ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.棚卸処理ToolStripMenuItem.Text = "棚卸処理";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(143, 6);
            // 
            // 生産管理ToolStripMenuItem
            // 
            this.生産管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.生産伝票ToolStripMenuItem,
            this.toolStripSeparator8,
            this.発注伝票ToolStripMenuItem1,
            this.生産管理表ToolStripMenuItem});
            this.生産管理ToolStripMenuItem.Name = "生産管理ToolStripMenuItem";
            this.生産管理ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.生産管理ToolStripMenuItem.Text = "生産管理";
            // 
            // 生産伝票ToolStripMenuItem
            // 
            this.生産伝票ToolStripMenuItem.Name = "生産伝票ToolStripMenuItem";
            this.生産伝票ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.生産伝票ToolStripMenuItem.Text = "生産伝票";
            // 
            // 集計ToolStripMenuItem
            // 
            this.集計ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.出荷実績一覧ToolStripMenuItem,
            this.商品出荷実績推移表ToolStripMenuItem});
            this.集計ToolStripMenuItem.Name = "集計ToolStripMenuItem";
            this.集計ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.集計ToolStripMenuItem.Text = "集計";
            // 
            // 出荷実績一覧ToolStripMenuItem
            // 
            this.出荷実績一覧ToolStripMenuItem.Name = "出荷実績一覧ToolStripMenuItem";
            this.出荷実績一覧ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.出荷実績一覧ToolStripMenuItem.Text = "出荷実績一覧";
            // 
            // 商品出荷実績推移表ToolStripMenuItem
            // 
            this.商品出荷実績推移表ToolStripMenuItem.Name = "商品出荷実績推移表ToolStripMenuItem";
            this.商品出荷実績推移表ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.商品出荷実績推移表ToolStripMenuItem.Text = "商品出荷実績推移表";
            // 
            // ウィンドウToolStripMenuItem
            // 
            this.ウィンドウToolStripMenuItem.Name = "ウィンドウToolStripMenuItem";
            this.ウィンドウToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.ウィンドウToolStripMenuItem.Text = "ウィンドウ";
            // 
            // ヘルプToolStripMenuItem
            // 
            this.ヘルプToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ナビゲーターToolStripMenuItem,
            this.マニュアルToolStripMenuItem,
            this.バージョンToolStripMenuItem});
            this.ヘルプToolStripMenuItem.Name = "ヘルプToolStripMenuItem";
            this.ヘルプToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.ヘルプToolStripMenuItem.Text = "ヘルプ";
            // 
            // ナビゲーターToolStripMenuItem
            // 
            this.ナビゲーターToolStripMenuItem.Name = "ナビゲーターToolStripMenuItem";
            this.ナビゲーターToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.ナビゲーターToolStripMenuItem.Text = "ナビゲーター";
            this.ナビゲーターToolStripMenuItem.Click += new System.EventHandler(this.ナビゲーターToolStripMenuItem_Click);
            // 
            // マニュアルToolStripMenuItem
            // 
            this.マニュアルToolStripMenuItem.Name = "マニュアルToolStripMenuItem";
            this.マニュアルToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.マニュアルToolStripMenuItem.Text = "マニュアル";
            // 
            // バージョンToolStripMenuItem
            // 
            this.バージョンToolStripMenuItem.Name = "バージョンToolStripMenuItem";
            this.バージョンToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.バージョンToolStripMenuItem.Text = "バージョン";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(149, 6);
            // 
            // デザイナーToolStripMenuItem
            // 
            this.デザイナーToolStripMenuItem.Name = "デザイナーToolStripMenuItem";
            this.デザイナーToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.デザイナーToolStripMenuItem.Text = "デザイナー";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem3.Text = "委託納品書一括発行";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(149, 6);
            // 
            // 発注伝票ToolStripMenuItem1
            // 
            this.発注伝票ToolStripMenuItem1.Name = "発注伝票ToolStripMenuItem1";
            this.発注伝票ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.発注伝票ToolStripMenuItem1.Text = "発注伝票";
            // 
            // 生産管理表ToolStripMenuItem
            // 
            this.生産管理表ToolStripMenuItem.Name = "生産管理表ToolStripMenuItem";
            this.生産管理表ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.生産管理表ToolStripMenuItem.Text = "生産管理表";
            this.生産管理表ToolStripMenuItem.Click += new System.EventHandler(this.生産管理表ToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(149, 6);
            // 
            // 債権管理ToolStripMenuItem
            // 
            this.債権管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.売掛残高一覧ToolStripMenuItem,
            this.入金一括登録ToolStripMenuItem});
            this.債権管理ToolStripMenuItem.Name = "債権管理ToolStripMenuItem";
            this.債権管理ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.債権管理ToolStripMenuItem.Text = "債権管理";
            // 
            // 売掛残高一覧ToolStripMenuItem
            // 
            this.売掛残高一覧ToolStripMenuItem.Name = "売掛残高一覧ToolStripMenuItem";
            this.売掛残高一覧ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.売掛残高一覧ToolStripMenuItem.Text = "売掛残高一覧";
            // 
            // 入金一括登録ToolStripMenuItem
            // 
            this.入金一括登録ToolStripMenuItem.Name = "入金一括登録ToolStripMenuItem";
            this.入金一括登録ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.入金一括登録ToolStripMenuItem.Text = "入金一括登録";
            this.入金一括登録ToolStripMenuItem.Click += new System.EventHandler(this.入金一括登録ToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(829, 534);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "＝WMS＝";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_Load_1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 台帳ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出荷処理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 入荷処理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 在庫管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 集計ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ウィンドウToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ヘルプToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 開くToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 開くToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 基本情報ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem バックアップToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 復元ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 終了ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品台帳ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品リストToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 受注伝票ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 受注一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品価格表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 発注伝票ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 委託伝票ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 委託伝票一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 委託棚卸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem 在庫一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 棚卸処理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出荷実績一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ナビゲーターToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem マニュアルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem バージョンToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 売上一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 事業所情報ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ユーザー管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem 商品元帳ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem 生産管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品出荷実績推移表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 生産伝票ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem デザイナーToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem 発注伝票ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 生産管理表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem 債権管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 売掛残高一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 入金一括登録ToolStripMenuItem;
    }
}