﻿namespace WMS_V1.UI
{
    partial class SeisanKanri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gcFunctionKey1 = new GrapeCity.Win.Bars.GcFunctionKey();
            this.functionKeyButton1 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton2 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton3 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton4 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton5 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton6 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton7 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton8 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton9 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton10 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton11 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.functionKeyButton12 = new GrapeCity.Win.Bars.FunctionKeyButton();
            this.gcMultiRow1 = new GrapeCity.Win.MultiRow.GcMultiRow();
            this.tempSeisankanri1 = new WMS_V1.UI.TempSeisankanri();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).BeginInit();
            this.SuspendLayout();
            // 
            // gcFunctionKey1
            // 
            this.gcFunctionKey1.Dock = System.Windows.Forms.DockStyle.Top;
            this.gcFunctionKey1.FunctionKeyButtons.AddRange(new GrapeCity.Win.Bars.FunctionKeyButton[] {
            this.functionKeyButton1,
            this.functionKeyButton2,
            this.functionKeyButton3,
            this.functionKeyButton4,
            this.functionKeyButton5,
            this.functionKeyButton6,
            this.functionKeyButton7,
            this.functionKeyButton8,
            this.functionKeyButton9,
            this.functionKeyButton10,
            this.functionKeyButton11,
            this.functionKeyButton12});
            this.gcFunctionKey1.Location = new System.Drawing.Point(0, 0);
            this.gcFunctionKey1.Name = "gcFunctionKey1";
            this.gcFunctionKey1.Size = new System.Drawing.Size(1033, 25);
            this.gcFunctionKey1.TabIndex = 0;
            this.gcFunctionKey1.Text = "gcFunctionKey1";
            // 
            // functionKeyButton1
            // 
            this.functionKeyButton1.FunctionKey = System.Windows.Forms.Keys.F1;
            this.functionKeyButton1.Name = "functionKeyButton1";
            this.functionKeyButton1.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton1.Text = "Function1";
            // 
            // functionKeyButton2
            // 
            this.functionKeyButton2.FunctionKey = System.Windows.Forms.Keys.F2;
            this.functionKeyButton2.Name = "functionKeyButton2";
            this.functionKeyButton2.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton2.Text = "Function2";
            // 
            // functionKeyButton3
            // 
            this.functionKeyButton3.FunctionKey = System.Windows.Forms.Keys.F3;
            this.functionKeyButton3.Name = "functionKeyButton3";
            this.functionKeyButton3.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton3.Text = "Function3";
            // 
            // functionKeyButton4
            // 
            this.functionKeyButton4.FunctionKey = System.Windows.Forms.Keys.F4;
            this.functionKeyButton4.Name = "functionKeyButton4";
            this.functionKeyButton4.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton4.Text = "Function4";
            // 
            // functionKeyButton5
            // 
            this.functionKeyButton5.FunctionKey = System.Windows.Forms.Keys.F5;
            this.functionKeyButton5.Name = "functionKeyButton5";
            this.functionKeyButton5.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton5.Text = "Function5";
            // 
            // functionKeyButton6
            // 
            this.functionKeyButton6.FunctionKey = System.Windows.Forms.Keys.F6;
            this.functionKeyButton6.Name = "functionKeyButton6";
            this.functionKeyButton6.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton6.Text = "Function6";
            // 
            // functionKeyButton7
            // 
            this.functionKeyButton7.FunctionKey = System.Windows.Forms.Keys.F7;
            this.functionKeyButton7.Name = "functionKeyButton7";
            this.functionKeyButton7.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton7.Text = "Function7";
            // 
            // functionKeyButton8
            // 
            this.functionKeyButton8.FunctionKey = System.Windows.Forms.Keys.F8;
            this.functionKeyButton8.Name = "functionKeyButton8";
            this.functionKeyButton8.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton8.Text = "Function8";
            // 
            // functionKeyButton9
            // 
            this.functionKeyButton9.FunctionKey = System.Windows.Forms.Keys.F9;
            this.functionKeyButton9.Name = "functionKeyButton9";
            this.functionKeyButton9.Size = new System.Drawing.Size(84, 22);
            this.functionKeyButton9.Text = "Function9";
            // 
            // functionKeyButton10
            // 
            this.functionKeyButton10.FunctionKey = System.Windows.Forms.Keys.F10;
            this.functionKeyButton10.Name = "functionKeyButton10";
            this.functionKeyButton10.Size = new System.Drawing.Size(96, 22);
            this.functionKeyButton10.Text = "Function10";
            // 
            // functionKeyButton11
            // 
            this.functionKeyButton11.FunctionKey = System.Windows.Forms.Keys.F11;
            this.functionKeyButton11.Name = "functionKeyButton11";
            this.functionKeyButton11.Size = new System.Drawing.Size(96, 22);
            this.functionKeyButton11.Text = "Function11";
            // 
            // functionKeyButton12
            // 
            this.functionKeyButton12.FunctionKey = System.Windows.Forms.Keys.F12;
            this.functionKeyButton12.Name = "functionKeyButton12";
            this.functionKeyButton12.Size = new System.Drawing.Size(23, 23);
            this.functionKeyButton12.Text = "Function12";
            // 
            // gcMultiRow1
            // 
            this.gcMultiRow1.Location = new System.Drawing.Point(12, 40);
            this.gcMultiRow1.Name = "gcMultiRow1";
            this.gcMultiRow1.Size = new System.Drawing.Size(1009, 758);
            this.gcMultiRow1.TabIndex = 1;
            this.gcMultiRow1.Template = this.tempSeisankanri1;
            this.gcMultiRow1.Text = "gcMultiRow1";
            // 
            // SeisanKanri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.ClientSize = new System.Drawing.Size(1033, 810);
            this.Controls.Add(this.gcMultiRow1);
            this.Controls.Add(this.gcFunctionKey1);
            this.Name = "SeisanKanri";
            this.Text = "生産管理表";
            this.Load += new System.EventHandler(this.SeisanKanri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GrapeCity.Win.Bars.GcFunctionKey gcFunctionKey1;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton1;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton2;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton3;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton4;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton5;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton6;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton7;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton8;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton9;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton10;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton11;
        private GrapeCity.Win.Bars.FunctionKeyButton functionKeyButton12;
        private GrapeCity.Win.MultiRow.GcMultiRow gcMultiRow1;
        private TempSeisankanri tempSeisankanri1;
    }
}