﻿namespace WMS_V1.UI
{
    partial class ProductMototyo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            GrapeCity.Win.Editors.Fields.DateYearField dateYearField1 = new GrapeCity.Win.Editors.Fields.DateYearField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField1 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateMonthField dateMonthField1 = new GrapeCity.Win.Editors.Fields.DateMonthField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField2 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateDayField dateDayField1 = new GrapeCity.Win.Editors.Fields.DateDayField();
            GrapeCity.Win.Editors.Fields.DateYearField dateYearField2 = new GrapeCity.Win.Editors.Fields.DateYearField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField3 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateMonthField dateMonthField2 = new GrapeCity.Win.Editors.Fields.DateMonthField();
            GrapeCity.Win.Editors.Fields.DateLiteralField dateLiteralField4 = new GrapeCity.Win.Editors.Fields.DateLiteralField();
            GrapeCity.Win.Editors.Fields.DateDayField dateDayField2 = new GrapeCity.Win.Editors.Fields.DateDayField();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.gcMultiRow1 = new GrapeCity.Win.MultiRow.GcMultiRow();
            this.tempProductMototyo1 = new WMS_V1.UI.TempProductMototyo();
            this.gcTextBox2 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcTextBox1 = new GrapeCity.Win.Editors.GcTextBox(this.components);
            this.gcDate2 = new GrapeCity.Win.Editors.GcDate(this.components);
            this.dropDownButton2 = new GrapeCity.Win.Editors.DropDownButton();
            this.gcDate1 = new GrapeCity.Win.Editors.GcDate(this.components);
            this.dropDownButton1 = new GrapeCity.Win.Editors.DropDownButton();
            this.gcLabel2 = new GrapeCity.Win.Buttons.GcLabel();
            this.gcLabel1 = new GrapeCity.Win.Buttons.GcLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.gcShortcut1 = new GrapeCity.Win.Editors.GcShortcut(this.components);
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(781, 35);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            //this.toolStripButton1.Image = global::WMS_V1.Properties.Resources.Close;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(100, 32);
            this.toolStripButton1.Text = "閉じる（ESC）";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 35);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(237)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.gcMultiRow1);
            this.panel1.Controls.Add(this.gcTextBox2);
            this.panel1.Controls.Add(this.gcTextBox1);
            this.panel1.Controls.Add(this.gcDate2);
            this.panel1.Controls.Add(this.gcDate1);
            this.panel1.Controls.Add(this.gcLabel2);
            this.panel1.Controls.Add(this.gcLabel1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(781, 523);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(199, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "～";
            // 
            // gcMultiRow1
            // 
            this.gcMultiRow1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gcMultiRow1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gcMultiRow1.Location = new System.Drawing.Point(15, 83);
            this.gcMultiRow1.Name = "gcMultiRow1";
            this.gcMultiRow1.Size = new System.Drawing.Size(742, 427);
            this.gcMultiRow1.TabIndex = 7;
            this.gcMultiRow1.Template = this.tempProductMototyo1;
            this.gcMultiRow1.Text = "gcMultiRow1";
            // 
            // gcTextBox2
            // 
            this.gcTextBox2.Location = new System.Drawing.Point(192, 35);
            this.gcTextBox2.Name = "gcTextBox2";
            this.gcTextBox2.Size = new System.Drawing.Size(406, 20);
            this.gcTextBox2.TabIndex = 6;
            this.gcTextBox2.TextChanged += new System.EventHandler(this.gcTextBox1_TextChanged);
            // 
            // gcTextBox1
            // 
            this.gcTextBox1.Location = new System.Drawing.Point(73, 35);
            this.gcTextBox1.Name = "gcTextBox1";
            this.gcShortcut1.SetShortcuts(this.gcTextBox1, new GrapeCity.Win.Editors.ShortcutCollection(new System.Windows.Forms.Keys[] {
                System.Windows.Forms.Keys.F2}, new object[] {
                ((object)(this.gcTextBox1))}, new string[] {
                "ShortcutClear"}));
            this.gcTextBox1.Size = new System.Drawing.Size(120, 20);
            this.gcTextBox1.TabIndex = 6;
            this.gcTextBox1.TextChanged += new System.EventHandler(this.gcTextBox1_TextChanged);
            // 
            // gcDate2
            // 
            dateLiteralField1.Text = "/";
            dateLiteralField2.Text = "/";
            this.gcDate2.Fields.AddRange(new GrapeCity.Win.Editors.Fields.DateField[] {
            dateYearField1,
            dateLiteralField1,
            dateMonthField1,
            dateLiteralField2,
            dateDayField1});
            this.gcDate2.Location = new System.Drawing.Point(222, 57);
            this.gcDate2.Name = "gcDate2";
            this.gcDate2.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton2});
            this.gcDate2.Size = new System.Drawing.Size(120, 20);
            this.gcDate2.TabIndex = 5;
            this.gcDate2.Value = new System.DateTime(2017, 5, 11, 0, 0, 0, 0);
            // 
            // dropDownButton2
            // 
            this.dropDownButton2.Name = "dropDownButton2";
            // 
            // gcDate1
            // 
            dateLiteralField3.Text = "/";
            dateLiteralField4.Text = "/";
            this.gcDate1.Fields.AddRange(new GrapeCity.Win.Editors.Fields.DateField[] {
            dateYearField2,
            dateLiteralField3,
            dateMonthField2,
            dateLiteralField4,
            dateDayField2});
            this.gcDate1.Location = new System.Drawing.Point(73, 57);
            this.gcDate1.Name = "gcDate1";
            this.gcShortcut1.SetShortcuts(this.gcDate1, new GrapeCity.Win.Editors.ShortcutCollection(new System.Windows.Forms.Keys[] {
                System.Windows.Forms.Keys.F2,
                System.Windows.Forms.Keys.F5,
                ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Return)))}, new object[] {
                ((object)(this.gcDate1)),
                ((object)(this.gcDate1)),
                ((object)(this.gcDate1))}, new string[] {
                "ShortcutClear",
                "SetNow",
                "ApplyRecommendedValue"}));
            this.gcDate1.SideButtons.AddRange(new GrapeCity.Win.Editors.SideButtonBase[] {
            this.dropDownButton1});
            this.gcDate1.Size = new System.Drawing.Size(120, 20);
            this.gcDate1.TabIndex = 5;
            this.gcDate1.Value = new System.DateTime(2017, 5, 11, 0, 0, 0, 0);
            // 
            // dropDownButton1
            // 
            this.dropDownButton1.Name = "dropDownButton1";
            // 
            // gcLabel2
            // 
            this.gcLabel2.AutoSize = true;
            this.gcLabel2.Location = new System.Drawing.Point(15, 60);
            this.gcLabel2.Name = "gcLabel2";
            this.gcLabel2.Size = new System.Drawing.Size(46, 16);
            this.gcLabel2.TabIndex = 4;
            this.gcLabel2.Text = "期　間：";
            // 
            // gcLabel1
            // 
            this.gcLabel1.AutoSize = true;
            this.gcLabel1.Location = new System.Drawing.Point(15, 37);
            this.gcLabel1.Name = "gcLabel1";
            this.gcLabel1.Size = new System.Drawing.Size(46, 16);
            this.gcLabel1.TabIndex = 4;
            this.gcLabel1.Text = "商　品：";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(106)))), ((int)(((byte)(101)))));
            this.label1.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(746, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "商品元帳";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProductMototyo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 558);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "ProductMototyo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "商品元帳";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcMultiRow1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcTextBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcDate1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox1;
        private GrapeCity.Win.Editors.GcShortcut gcShortcut1;
        private GrapeCity.Win.Editors.GcDate gcDate2;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton2;
        private GrapeCity.Win.Editors.GcDate gcDate1;
        private GrapeCity.Win.Editors.DropDownButton dropDownButton1;
        private GrapeCity.Win.Buttons.GcLabel gcLabel2;
        private GrapeCity.Win.Buttons.GcLabel gcLabel1;
        private GrapeCity.Win.MultiRow.GcMultiRow gcMultiRow1;
        private TempProductMototyo tempProductMototyo1;
        private GrapeCity.Win.Editors.GcTextBox gcTextBox2;
        private System.Windows.Forms.Label label2;
    }
}